# SuperAdmin Collections Access, Checkout Payment Visibility & Subscription Period Plan

This plan resolves four critical operational issues across SuperAdmin collection account security, marketplace checkout payment account visibility, Root Mandate subscription plan creation, and exact subscription day calculations from approval date, alongside full system debugging.

## User Review & Confirmed Decisions

> [!IMPORTANT]
> All four product and workflow decisions below were confirmed during clarification and govern the implementation.

- **Decision 1 — SuperAdmin Collections Account Scope**: Restrict **SuperAdmin Collections Account** payments strictly to **registered customer accounts paying approved stores** (blocking unapproved/demo/expired stores and requiring buyers to be signed in or creating/activating a registered customer account before completing payment via SuperAdmin collection accounts).
- **Decision 2 — Checkout Payment Account Visibility**: Display all **saved payment account numbers upfront** inside the checkout payment section before order placement—including partially configured mobile money or bank accounts—without hiding saved numbers behind secondary tabs or showing fake fallback accounts.
- **Decision 3 — Subscription Period Calculation**: Calculate every subscription period using the selected plan's **exact number of days counted from the SuperAdmin approval date** (e.g., a 30-day plan starts on the approval date and shows exactly 30 days remaining), automatically prefilled so SuperAdmin does not have to re-enter the duration manually.
- **Decision 4 — Root Mandate Add Plan Behavior**: Automatically default **Commission % to 0%** when creating a **Direct** plan, activate immediate plan creation with clear inline validation messages on missing or invalid inputs, and show toast confirmation on save.

---

## 1. Overview & Core Concept

- **What It Does**:
  1. **Registered-Only SuperAdmin Collections**: Enforces buyer account registration/sign-in and store approval verification whenever a customer pays using SuperAdmin platform collection accounts, preventing guest-only or unapproved-store collection submissions while allowing buyers to sign in or register inline without losing their cart.
  2. **Upfront Checkout Account Cards**: Surfaces every saved active payment account (partial or complete—M-Pesa, Tigo Pesa, Airtel Money, HaloPesa, Lipa Namba, and Bank Name/Account/Holder) directly in the main checkout payment area with one-tap copy controls and clear instructions.
  3. **Active Root Mandate Add Plan Flow**: Fixes silent form rejection in the Root Mandate Subscription Plans tab by handling Direct plans with 0% commission, validating required fields with explicit inline feedback, and persisting new plans reliably.
  4. **Exact Day-Based Subscription Periods**: Replaces calendar-month approximations and off-by-one ceiling date math with exact day counts anchored to the approval timestamp so a 30-day subscription activates with 30 exact days rather than 31 or 32 days.
  5. **System-Wide Debug & Warning Sweep**: Verifies and resolves any console errors, React warnings, TypeScript lint issues, or API validation issues across registration, checkout, and SuperAdmin panels.
- **Target Audience**: SuperAdmins (Root Mandate & Subscriptions Control), approved Sellers/Store Owners, and Marketplace Buyers.
- **Key Value**: Eliminates checkout payment drop-offs caused by hidden or partial payment numbers, protects SuperAdmin escrow/collection routing, activates plan creation, and guarantees exact billing periods.

---

## 2. User Experience & Visual Design

- **Key User Flows**:
  1. **SuperAdmin Collections Account Gate at Checkout**:
     - When a buyer checks out from an approved store routed through SuperAdmin Collection Accounts, the checkout checks whether the buyer has a registered customer session or has opted into creating/signing into a customer account.
     - Registered customers immediately see the SuperAdmin Collection Account numbers and proceed normally; unregistered guests see a clean inline sign-in / account-creation card right inside Checkout (preserving their cart) before submitting a SuperAdmin collection payment.
     - Unapproved, pending, rejected, demo, or expired stores are blocked from initiating SuperAdmin collection payments.
  2. **Upfront Saved Payment Accounts During Checkout**:
     - In the Payment Method section at checkout, an upfront **Payment Accounts** summary card automatically renders every saved active account for that checkout (all populated platform mobile money / bank numbers for Commission stores, or the store's own saved active payment methods for Direct stores).
     - Even if only one account or a partial set (for example, only a Bank account or only M-Pesa) was saved, that saved account appears immediately with network/bank label, account number, account holder name, copy button, and payment instructions—never concealed behind a secondary toggle and never padded with hardcoded dummy numbers when real accounts exist.
  3. **Root Mandate — Adding a Subscription Plan**:
     - Selecting **Direct (Pay Seller)** automatically sets Commission % to `0` and disables manual commission entry so it never blocks creation.
     - Clicking **Add Plan** validates Plan Name, Price, Duration Days, Max Products, and (for Commission plans) Commission %, highlighting any missing or invalid field with clear inline feedback and auto-resolving slug collisions cleanly.
     - Newly created plans immediately appear in the plans list, persist across reloads, and show on the company registration page.
  4. **Exact 30-Day (or Plan-Defined) Subscription Approval**:
     - When a user registers or renews on a 30-day plan and SuperAdmin opens the approval dialog (from either Subscriptions & Payments Control or Root Mandate Subscriptions), the modal automatically reads the subscribed plan's exact **Duration Days** (e.g., `30 days`), previews `Start Date = Today` and `Expiry Date = Today + 30 days`, and activates for exactly 30 days remaining without requiring SuperAdmin to re-configure the duration.
- **Visual Identity & Interface Discipline**:
  - Single-elevation flat cards with crisp `1px` neutral borders, tabular monospace figures (`font-mono tabular-nums`) for account numbers, amounts, and day counts, and minimum `40px` interactive targets on Copy, Sign In, Add Plan, and Approve buttons.
  - Clear inline validation banners and concise status chips with zero cluttered badge stacks or blocked browser dialogs.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Dual Client + Handler Enforcement for Registered Collection Payments**:
  - *Chosen Approach*: Enforce registered customer + approved store checks both in the Checkout UI (with inline sign-in / account upgrade so buyers never lose their cart) and inside the order/collection submission handlers.
  - *Why*: UI-only checks can be bypassed, while backend/state-only rejections without an inline sign-in path frustrate buyers mid-checkout.
- **Decision 2 — Merge Real Saved Accounts Without Hardcoded Ghost Fallbacks**:
  - *Chosen Approach*: Combine active configured collection networks with any populated SuperAdmin pay numbers (or company-saved payment methods for Direct stores) and display them upfront whenever at least one real account field is saved. Only if zero accounts exist anywhere does the UI clearly indicate that no payment account has been configured yet (instead of silently displaying unrelated default numbers).
  - *Why*: Solves the "partial account saved" issue directly—if an admin saved only M-Pesa or only a Bank account, customers see that exact account immediately rather than missing it or seeing unverified fallback numbers.
- **Decision 3 — Calendar-Day Precision Replacing Month Offsets & Midnight Ceiling Drift**:
  - *Chosen Approach*: Pass exact days (`durationDays`) through all approval paths (defaulting to the selected plan's `durationDays`), anchor `subscriptionStart` / `startsAt` to the approval timestamp, add exact days (`+30` days), and compute remaining days using exact whole-day date differences from today's date rather than `23:59:59` ceiling rounding or `setMonth(+1)`.
  - *Why*: Eliminates both the 31-day month drift and the `+1 day` ceiling inflation (`30.77` rounding to `31`) that forced SuperAdmins to manually adjust periods.
- **Decision 4 — Explicit Form Feedback & Direct 0% Auto-Fill in Root Mandate Plans**:
  - *Chosen Approach*: Keep the **Add Plan** button clickable at all times with explicit validation messages and auto-sync `commissionPercent = 0` whenever `type === 'direct'`.
  - *Why*: A silent `return` makes the button look broken/dead; explicit validation + Direct defaulting makes plan creation immediate and predictable.

---

## 4. Technical Architecture & Data Strategy

```
┌───────────────────────────────────────────────────────────────────────────┐
│                      Marketplace & Enterprise UI                          │
├─────────────────────────┬─────────────────────────┬───────────────────────┤
│   Marketplace Checkout  │  Root Mandate Plans     │  Subscription Control │
│                         │                         │                       │
│ • Upfront Saved Account │ • Direct = 0% auto-fill │ • Auto-reads plan     │
│   Cards (partial OK)    │ • Inline field errors   │   durationDays (e.g.  │
│ • Registered Customer   │ • Unique slug guard &   │   30 days) on open    │
│   gate + inline sign-in │   instant persistence   │ • Start = Approval    │
│   for SuperAdmin Escrow │                         │   Date; Exact Days    │
└───────────┬─────────────┴────────────┬────────────┴──────────┬────────────┘
            │                          │                       │
            ▼                          ▼                       ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                 Application Validation & State Layer                      │
│  • Collection Eligibility: Approved Active Store + Registered Customer    │
│  • Payment Source Resolver: Commission -> Admin Accounts | Direct -> Shop │
│  • Date Engine: Approval Date + Exact Plan Days (whole-day remaining math)│
└────────────────────────────────────┬──────────────────────────────────────┘
                                     │
                                     ▼
┌───────────────────────────────────────────────────────────────────────────┐
│                 Express Server & Persistent Application Data              │
│  • Preserves subscriptionPlans, payNumbers, collectionSettings & orders  │
│  • Consistent ID matching across companies, plans, and customer sessions  │
└───────────────────────────────────────────────────────────────────────────┘
```

- **Data Model & State**:
  - **Subscription Plans**: Stored with explicit `type` (`direct` | `commission`), `commissionPercent` (`0` enforced for `direct`), `basePriceTZS`, `maxProducts`, `durationDays` (canonical integer days), and `isActive`.
  - **Company Subscription & Approval Records**: Store `planId`, `planName`, `durationDays` snapshot, `startsAt` (set to SuperAdmin approval timestamp), and `endsAt` / `subscriptionEnd` (computed as exact `approvalDate + durationDays`).
  - **Payment Account Resolution**:
    - Commission / Platform Collection stores resolve accounts from active SuperAdmin network collection settings plus all populated SuperAdmin pay number fields (mobile networks and bank details), gated to approved active stores and registered customer accounts.
    - Direct stores resolve accounts from the store's active saved company payment methods.
- **Verification Scope**:
  - Automated unit tests (`npm test`), TypeScript typechecking and lint validation (`lint_applet`), full production build (`compile_applet`), and live end-to-end headless browser checks covering checkout (guest vs registered customer, partial saved accounts), Root Mandate Add Plan, exact 30-day approval/remaining-days display, and zero console/HTTP errors.
