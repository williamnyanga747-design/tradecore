export function getUtcDateStr(date: Date = new Date()): string {
  return date.toISOString().split('T')[0];
}

export function addExactDaysToDateStr(baseDateStr: string, days: number): string {
  const safeDays = Math.max(1, Math.round(days || 1));
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(baseDateStr || '').trim());
  const baseMs = match
    ? Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]))
    : (() => {
        const now = new Date();
        return Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
      })();
  return new Date(baseMs + safeDays * 86400000).toISOString().split('T')[0];
}

export function addExactDaysFromToday(days: number): {
  startIso: string;
  startDateStr: string;
  endDateStr: string;
  durationDays: number;
} {
  const now = new Date();
  const startIso = now.toISOString();
  const startDateStr = startIso.split('T')[0];
  const durationDays = Math.max(1, Math.round(days || 1));
  const endDateStr = addExactDaysToDateStr(startDateStr, durationDays);
  return { startIso, startDateStr, endDateStr, durationDays };
}

export function getExactDaysRemaining(endDateStr?: string | null, todayOverride?: string): number | null {
  if (!endDateStr) return null;
  const match = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(endDateStr).trim());
  let endMs: number;
  if (match) {
    endMs = Date.UTC(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  } else {
    const parsed = new Date(endDateStr);
    if (isNaN(parsed.getTime())) return null;
    endMs = Date.UTC(parsed.getUTCFullYear(), parsed.getUTCMonth(), parsed.getUTCDate());
  }
  const todayStr = todayOverride || getUtcDateStr();
  const tMatch = /^(\d{4})-(\d{2})-(\d{2})$/.exec(todayStr);
  const todayMs = tMatch
    ? Date.UTC(Number(tMatch[1]), Number(tMatch[2]) - 1, Number(tMatch[3]))
    : Date.now();
  return Math.round((endMs - todayMs) / 86400000);
}

export function normalizePhoneDigits(phone?: string): string {
  const digits = String(phone || '').replace(/\D/g, '');
  if (!digits) return '';
  if (digits.startsWith('0') && digits.length >= 9) {
    return '255' + digits.slice(1);
  }
  return digits;
}
