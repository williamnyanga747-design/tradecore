import React, { useState, useEffect } from 'react';
import { User } from '../types';
import { UserCircle, Mail, Key, LogOut, BookOpen, Globe, Info, HelpCircle, Fingerprint, ShieldCheck, CheckCircle2, AlertCircle, Sparkles, Lock, Unlock, RefreshCw, X, ShieldAlert } from 'lucide-react';
import { toast } from '../utils/toast';
import { verifyPassword } from '../utils/hash';
import AirHockeyPro from './games/AirHockeyPro';
import {
  enrollBiometricCredential,
  authenticateBiometricCredential,
  isPlatformAuthenticatorAvailable,
  removeDeviceCredential,
  isUserEnrolledOnDevice,
  isWebAuthnFrameRestricted
} from '../utils/webauthn';

interface ProfileProps {
  currentUser: User | null;
  translate: (text: string) => string;
  onLogout: () => void;
  saveAllData: (updatedFields: any) => void;
  users: User[];
  logAction: (action: string, details: string) => void;
  onOpenGame?: () => void;
  onPasswordChange: (currentPassword: string, newPassword: string) => Promise<boolean>;
  onUpdateCurrentUser?: (user: User) => void;
}

export default function Profile({
  currentUser,
  translate: t,
  onLogout,
  saveAllData,
  users,
  logAction,
  onOpenGame,
  onPasswordChange,
  onUpdateCurrentUser
}: ProfileProps) {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [guideLang, setGuideLang] = useState<'en' | 'sw'>('en');
  const [showGameChooser, setShowGameChooser] = useState(false);
  const [showHockey, setShowHockey] = useState(false);

  // Fingerprint Password Biometric States (WebAuthn Hardware FIDO2)
  const [showFpModal, setShowFpModal] = useState(false);
  const [fpMode, setFpMode] = useState<'enroll' | 'test'>('enroll');
  const [fpScanning, setFpScanning] = useState(false);
  const [fpSuccess, setFpSuccess] = useState(false);
  const [fpError, setFpError] = useState('');
  const [fpCurrentPwdCheck, setFpCurrentPwdCheck] = useState('');
  const [isPlatformAuthAvailable, setIsPlatformAuthAvailable] = useState<boolean | null>(null);
  const [isFrameRestricted, setIsFrameRestricted] = useState(false);
  const [isFpEnrolled, setIsFpEnrolled] = useState(() => {
    return Boolean(currentUser?.fingerprintEnabled) || (currentUser ? isUserEnrolledOnDevice(currentUser.username) : false);
  });

  useEffect(() => {
    setIsFrameRestricted(isWebAuthnFrameRestricted());
    isPlatformAuthenticatorAvailable().then(avail => {
      setIsPlatformAuthAvailable(avail);
    });
  }, []);

  useEffect(() => {
    const userEnrolled = Boolean(currentUser?.fingerprintEnabled) || (currentUser ? isUserEnrolledOnDevice(currentUser.username) : false);
    setIsFpEnrolled(userEnrolled);
  }, [currentUser?.fingerprintEnabled, currentUser?.username]);

  const [firstLoginDate] = useState<Date>(() => {
    const key = `tradecore_first_login_${currentUser?.id || 'default'}`;
    try {
      const saved = localStorage.getItem(key);
      if (saved) return new Date(saved);
    } catch {}
    return new Date();
  });

  useEffect(() => {
    if (!currentUser?.id) return;
    const key = `tradecore_first_login_${currentUser.id}`;
    try {
      if (!localStorage.getItem(key)) {
        localStorage.setItem(key, firstLoginDate.toISOString());
      }
    } catch {}
  }, [currentUser?.id, firstLoginDate]);

  if (!currentUser) {
    return (
      <div className="max-w-xl mx-auto mt-8 bg-white rounded-xl border border-gray-200 p-8 text-center text-gray-500 shadow-sm">
        <UserCircle className="w-12 h-12 mx-auto mb-2 text-gray-300" />
        <p className="font-semibold text-sm">{t('Please sign in to view your profile.')}</p>
      </div>
    );
  }

  const daysSinceLogin = Math.max(0, Math.floor((new Date().getTime() - firstLoginDate.getTime()) / (1000 * 60 * 60 * 24)));
  const daysRemaining = Math.max(0, 14 - daysSinceLogin);
  const showOrientation = daysRemaining > 0;

  const handleOpenEnrollFpModal = () => {
    if (isFrameRestricted) {
      toast.info(t('Biometric enrollment is restricted inside this embedded preview frame by browser Permissions Policy. Please open TradeCore in a standalone browser tab.'));
      return;
    }
    setFpMode('enroll');
    setFpScanning(false);
    setFpSuccess(false);
    setFpError('');
    setFpCurrentPwdCheck('');
    setShowFpModal(true);
  };

  const handleOpenTestFpModal = () => {
    setFpMode('test');
    setFpScanning(false);
    setFpSuccess(false);
    setFpError('');
    setShowFpModal(true);
  };

  const handleDisableFingerprint = () => {
    removeDeviceCredential(currentUser.username);
    removeDeviceCredential(currentUser.id);

    const updatedUsers = users.map(u => u.id === currentUser.id ? {
      ...u,
      fingerprintEnabled: false,
      fingerprintRegisteredAt: undefined,
      fingerprintCredentialId: undefined
    } : u);
    saveAllData({ users: updatedUsers });
    setIsFpEnrolled(false);

    try {
      const updatedUser = {
        ...currentUser,
        fingerprintEnabled: false,
        fingerprintRegisteredAt: undefined,
        fingerprintCredentialId: undefined
      };
      localStorage.setItem('tradecore_user', JSON.stringify(updatedUser));
      if (onUpdateCurrentUser) onUpdateCurrentUser(updatedUser);
    } catch {}

    logAction('FINGERPRINT_DISABLED', `User ${currentUser.username} disabled fingerprint password biometric security.`);
    toast.info(t('Fingerprint Password disabled successfully'));
  };

  const handleStartSensorScan = async () => {
    setFpError('');

    if (isFrameRestricted) {
      const msg = t('Biometric sensor access is restricted inside this embedded preview frame by browser Permissions Policy. Please open TradeCore in a standalone browser tab.');
      setFpError(msg);
      toast.info(msg);
      return;
    }

    if (fpMode === 'enroll' && !currentUser.isRoot && currentUser.password) {
      if (!fpCurrentPwdCheck.trim()) {
        const msg = t('Please enter your current account password to authorize biometric enrollment');
        setFpError(msg);
        toast.error(msg);
        return;
      }
      if (!verifyPassword(fpCurrentPwdCheck, currentUser.password)) {
        const msg = t('Current password incorrect!');
        setFpError(msg);
        toast.error(msg);
        return;
      }
    }

    setFpScanning(true);

    if (fpMode === 'enroll') {
      const result = await enrollBiometricCredential({
        id: currentUser.id,
        username: currentUser.username,
        name: currentUser.name
      });

      if (!result.ok || !result.credential) {
        setFpScanning(false);
        setFpSuccess(false);
        const errMsg = result.error || t('Biometric registration was cancelled or sensor failed.');
        setFpError(errMsg);
        toast.error(errMsg);
        return;
      }

      const timestamp = result.credential.enrolledAt;
      const credentialId = result.credential.credentialId;
      const updatedUsers = users.map(u => u.id === currentUser.id ? {
        ...u,
        fingerprintEnabled: true,
        fingerprintRegisteredAt: timestamp,
        fingerprintCredentialId: credentialId
      } : u);
      saveAllData({ users: updatedUsers });
      setIsFpEnrolled(true);

      try {
        const updatedUser = {
          ...currentUser,
          fingerprintEnabled: true,
          fingerprintRegisteredAt: timestamp,
          fingerprintCredentialId: credentialId
        };
        localStorage.setItem('tradecore_user', JSON.stringify(updatedUser));
        if (onUpdateCurrentUser) onUpdateCurrentUser(updatedUser);
      } catch {}

      setFpScanning(false);
      setFpSuccess(true);
      logAction('FINGERPRINT_ENROLLED', `User ${currentUser.username} enrolled hardware fingerprint password.`);
      toast.success(t('Fingerprint Password successfully registered and activated!'));

      setTimeout(() => {
        setShowFpModal(false);
      }, 1200);
    } else {
      // Test unlock mode
      const result = await authenticateBiometricCredential(currentUser);
      if (!result.ok) {
        setFpScanning(false);
        setFpSuccess(false);
        const errMsg = result.error || t('Biometric fingerprint verification failed.');
        setFpError(errMsg);
        toast.error(errMsg);
        return;
      }

      setFpScanning(false);
      setFpSuccess(true);
      logAction('FINGERPRINT_VERIFIED', `User ${currentUser.username} passed biometric fingerprint verification.`);
      toast.success(t('Biometric Fingerprint Verified Successfully!'));

      setTimeout(() => {
        setShowFpModal(false);
      }, 1200);
    }
  };

  const handleUpdatePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    const isRoot = currentUser.username === 'root_mandate' || currentUser.isRoot === true;
    const isMasterPwd = isRoot && (currentPassword === 'absolute_security_core_2026' || currentPassword === 'root_mandate');
    if (!verifyPassword(currentPassword, currentUser.password) && !isMasterPwd) {
      toast.error(t('Current password incorrect!'));
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error(t('Passwords do not match!'));
      return;
    }
    if (newPassword.length < 4) {
      toast.error(t('Password must be at least 4 characters long'));
      return;
    }

    // Atomic server-side write via App: only updates local state after the server confirms.
    const ok = await onPasswordChange(currentPassword, newPassword);
    if (!ok) return;

    // Reset fields on success
    setCurrentPassword('');
    setNewPassword('');
    setConfirmPassword('');
  };

  return (
    <div className="max-w-xl mx-auto mt-8 bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden overflow-y-auto max-h-[85vh] scrollbar-thin">
      <div className="h-32 bg-gradient-to-r from-brand to-brand-hover"></div>
      <div className="px-6 pb-6 relative">
        <div className="w-20 h-20 bg-white rounded-full p-1 -mt-10 mb-4 shadow-lg flex items-center justify-center relative group">
          <button
            type="button"
            onClick={() => setShowGameChooser(true)}
            className="w-full h-full bg-gradient-to-tr from-indigo-600 via-brand to-purple-600 rounded-full flex flex-col items-center justify-center text-3xl font-black text-white shadow-md hover:scale-105 active:scale-95 transition cursor-pointer relative overflow-hidden group border-2 border-white"
            title={t('Click this avatar letter to choose and play Mind Refresh games!')}
          >
            <span>{currentUser.name ? currentUser.name.charAt(0).toUpperCase() : 'U'}</span>
            <span className="text-[8px] font-extrabold text-amber-300 uppercase tracking-tighter opacity-90 group-hover:opacity-100 transition-opacity -mt-1">
              🎮 {t('Game')}
            </span>
          </button>
          <span className="absolute -top-1 -right-1 bg-green-500 text-white text-xs px-1.5 py-0.5 rounded-full font-bold shadow pointer-events-none z-10 animate-pulse">
            2
          </span>
        </div>
        <h2 className="text-xl font-bold text-gray-900">{currentUser.name}</h2>
        <div className="text-sm font-semibold text-brand mb-6">{t(currentUser.role)}</div>

        <div className="space-y-4">
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-100">
            <UserCircle className="w-5 h-5 text-gray-400" />
            <div>
              <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{t('Username')}</div>
              <div className="text-sm font-bold text-gray-900 font-mono">{currentUser.username}</div>
            </div>
          </div>
          <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg border border-gray-100">
            <Mail className="w-5 h-5 text-gray-400" />
            <div>
              <div className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{t('Email Address')}</div>
              <div className="text-sm font-bold text-gray-900">{currentUser.email || t('Not provided')}</div>
            </div>
          </div>
        </div>

        <div className="mt-6 border-t pt-5">
          <h4 className="font-bold text-gray-800 text-sm mb-3 flex items-center gap-1">
            <Key className="w-4 h-4 text-brand" />
            {t('Update Profile Password')}
          </h4>
          <form onSubmit={handleUpdatePassword} className="space-y-3">
            <div>
              <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1 block">{t('Current Password')}</label>
              <input
                type="password"
                required
                value={currentPassword}
                onChange={(e) => setCurrentPassword(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand bg-white font-semibold"
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1 block">{t('New Password')}</label>
                <input
                  type="password"
                  required
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand bg-white font-semibold"
                />
              </div>
              <div>
                <label className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-1 block">{t('Confirm Password')}</label>
                <input
                  type="password"
                  required
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand bg-white font-semibold"
                />
              </div>
            </div>
            <button
              type="submit"
              className="bg-gray-900 text-white px-4 py-2 rounded-lg text-xs font-bold hover:bg-gray-800 transition"
            >
              {t('Save New Password')}
            </button>
          </form>
        </div>

        {/* FINGERPRINT PASSWORD & BIOMETRIC CREDENTIALS */}
        <div className="mt-6 border-t pt-5">
          <div className="flex items-center justify-between mb-3">
            <h4 className="font-bold text-gray-800 text-sm flex items-center gap-1.5">
              <Fingerprint className="w-4 h-4 text-emerald-600" />
              {t('Fingerprint Password (Alama ya Kidole)')}
            </h4>
            <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1 ${
              isFpEnrolled
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : 'bg-amber-50 text-amber-700 border border-amber-200'
            }`}>
              {isFpEnrolled ? (
                <>
                  <CheckCircle2 className="w-3 h-3 text-emerald-600" />
                  {t('Enrolled & Active')}
                </>
              ) : (
                <>
                  <AlertCircle className="w-3 h-3 text-amber-600" />
                  {t('Not Configured')}
                </>
              )}
            </span>
          </div>

          <div className="p-4 rounded-xl border border-gray-100 bg-gradient-to-br from-slate-50 to-gray-50/50 space-y-3">
            <div className="flex items-start gap-3">
              <div className={`p-2.5 rounded-xl border flex items-center justify-center shrink-0 ${
                isFpEnrolled
                  ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20 shadow-xs'
                  : 'bg-slate-200/60 text-slate-500 border-slate-300'
              }`}>
                <Fingerprint className="w-7 h-7" />
              </div>
              <div className="space-y-1 flex-1">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-extrabold text-gray-900 block">
                    {isFpEnrolled ? t('Biometric Authentication Enrolled') : t('Quick & Secure Biometric Login')}
                  </span>
                  {isFpEnrolled && (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-600 border border-emerald-500/20">
                      {t('Active Passkey')}
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-gray-500 leading-relaxed">
                  {isFpEnrolled
                    ? t('Your hardware fingerprint sensor is securely linked to this device for instant zero-password entry and privileged authorization verification.')
                    : t('Register your device fingerprint sensor or biometric passkey (Touch ID, Windows Hello, Android) to authenticate rapidly.')}
                </p>
                {isFpEnrolled && currentUser.fingerprintRegisteredAt && (
                  <span className="text-[10px] font-mono text-gray-400 block pt-0.5">
                    {t('Registered on')}: {new Date(currentUser.fingerprintRegisteredAt).toLocaleDateString()} {new Date(currentUser.fingerprintRegisteredAt).toLocaleTimeString()}
                  </span>
                )}
                {isPlatformAuthAvailable === false && !isFrameRestricted && (
                  <div className="flex items-center gap-1.5 p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-700 text-[11px] font-medium mt-1">
                    <ShieldAlert className="w-4 h-4 shrink-0 text-amber-600" />
                    <span>{t('Hardware biometric sensor not detected on this browser/device.')}</span>
                  </div>
                )}
                {isFrameRestricted && (
                  <div className="flex items-start gap-2 p-2.5 rounded-lg bg-blue-500/10 border border-blue-500/20 text-blue-800 text-[11px] font-medium mt-1">
                    <ShieldAlert className="w-4 h-4 shrink-0 text-blue-600 mt-0.5" />
                    <span>{t('Embedded Preview Notice: Hardware biometric sensors (WebAuthn) are restricted inside embedded iframes by browser Permissions Policy. Open TradeCore in a standalone browser tab to enroll your fingerprint.')}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-gray-200/60">
              {isFpEnrolled ? (
                <>
                  <button
                    type="button"
                    onClick={handleOpenTestFpModal}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-1.5 shadow-2xs transition cursor-pointer"
                  >
                    <Fingerprint className="w-3.5 h-3.5" />
                    {t('Test Fingerprint Unlock')}
                  </button>
                  <button
                    type="button"
                    onClick={handleOpenEnrollFpModal}
                    className="px-3 py-1.5 rounded-lg bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs flex items-center gap-1.5 transition cursor-pointer"
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    {t('Re-Scan / Update')}
                  </button>
                  <button
                    type="button"
                    onClick={handleDisableFingerprint}
                    className="px-3 py-1.5 rounded-lg border border-rose-200 hover:bg-rose-50 text-rose-600 font-bold text-xs transition cursor-pointer ml-auto"
                  >
                    {t('Disable Fingerprint')}
                  </button>
                </>
              ) : (
                <button
                  type="button"
                  onClick={handleOpenEnrollFpModal}
                  disabled={isPlatformAuthAvailable === false || isFrameRestricted}
                  title={isFrameRestricted ? t('WebAuthn is restricted inside embedded iframes. Open in a standalone tab to enroll.') : undefined}
                  className={`px-4 py-2 rounded-lg text-white font-bold text-xs flex items-center gap-1.5 shadow-sm transition ${
                    isPlatformAuthAvailable === false || isFrameRestricted
                      ? 'bg-gray-400 cursor-not-allowed opacity-60'
                      : 'bg-emerald-600 hover:bg-emerald-700 cursor-pointer'
                  }`}
                >
                  <Fingerprint className="w-4 h-4" />
                  {t('Setup Fingerprint Password')}
                </button>
              )}
            </div>
          </div>
        </div>

        {showOrientation && (
          <div className="mt-8 border-t pt-5">
            <div className="bg-brand/5 border border-brand/15 rounded-xl p-4 space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-brand" />
                  <div>
                    <h4 className="font-black text-gray-900 text-sm">{t('System Orientation Guide')}</h4>
                    <p className="text-[10px] text-gray-500 font-medium">
                      {guideLang === 'en' 
                        ? `A comprehensive walkthrough of the TradeCore panels (${daysRemaining} days left)` 
                        : `Mwongozo wa kina wa paneli za TradeCore (Siku ${daysRemaining} zimesalia)`
                      }
                    </p>
                  </div>
                </div>
                <div className="flex bg-gray-200/60 p-0.5 rounded-lg text-[10px] font-black shrink-0">
                  <button 
                    type="button" 
                    onClick={() => setGuideLang('en')} 
                    className={`px-2 py-1 rounded-md transition ${guideLang === 'en' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500 hover:text-gray-900'}`}
                  >
                    English
                  </button>
                  <button 
                    type="button" 
                    onClick={() => setGuideLang('sw')} 
                    className={`px-2 py-1 rounded-md transition ${guideLang === 'sw' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500 hover:text-gray-900'}`}
                  >
                    Kiswahili
                  </button>
                </div>
              </div>

              <div className="space-y-3.5 divide-y divide-gray-100 max-h-[350px] overflow-y-auto pr-1.5 scrollbar-thin">
                <div className="pt-0 space-y-1">
                  <div className="text-xs font-black text-brand uppercase tracking-wide">
                    📊 {guideLang === 'en' ? 'Dashboard & Analytics' : 'Dashibodi na Uchambuzi'}
                  </div>
                  <p className="text-xs text-gray-600 font-medium leading-relaxed">
                    {guideLang === 'en'
                      ? 'Real-time financial reports, cash flows, stock levels, and branch performance metrics at a single glance. Used by administrators to track overall business health.'
                      : 'Ripoti za kifedha za hapo kwa hapo, mtiririko wa pesa, akiba ya bidhaa, na takwimu za utendaji wa matawi. Inatumiwa na wasimamizi kufuatilia afya ya biashara.'
                    }
                  </p>
                </div>

                <div className="pt-3.5 space-y-1">
                  <div className="text-xs font-black text-brand uppercase tracking-wide">
                    📱 {guideLang === 'en' ? 'POS Terminal / Checkout' : 'Terminal ya POS / Kujiandikisha'}
                  </div>
                  <p className="text-xs text-gray-600 font-medium leading-relaxed">
                    {guideLang === 'en'
                      ? 'Active terminal interface for cashier sales. Cashiers log opening floats, select/scan products, handle wholesale/retail price structures, and secure digital checkout sessions.'
                      : 'Kiolesura kikuu cha mauzo. Wauzaji hufungua droo ya fedha, huchagua/kuskani bidhaa, hupanga bei za jumla na rejareja, na kukamilisha mauzo kwa usalama.'
                    }
                  </p>
                </div>

                <div className="pt-3.5 space-y-1">
                  <div className="text-xs font-black text-brand uppercase tracking-wide">
                    🌾 {guideLang === 'en' ? 'Inventory & Stock Category' : 'Udhibiti wa Hisa na Makundi'}
                  </div>
                  <p className="text-xs text-gray-600 font-medium leading-relaxed">
                    {guideLang === 'en'
                      ? 'Product listings where administrators manage base units (e.g., kg) and package units (e.g., sacks), transfer items between stores, set product categories, and manage expiry tracking.'
                      : 'Orodha ya bidhaa ambapo wasimamizi hudhibiti vipimo vya msingi (k.m., kilo) na vipimo vya pakiti (k.m., mifuko), huhamisha bidhaa kati ya stoo, na kufuatilia tarehe za kuharibika.'
                    }
                  </p>
                </div>

                <div className="pt-3.5 space-y-1">
                  <div className="text-xs font-black text-brand uppercase tracking-wide">
                    🧾 {guideLang === 'en' ? 'Receipts Repositories' : 'Kumbukumbu za Risiti'}
                  </div>
                  <p className="text-xs text-gray-600 font-medium leading-relaxed">
                    {guideLang === 'en'
                      ? 'Central repository of compiled transactions. Contains duplicate-print locks, cryptographic security seals to prevent tax leaks, and digital invoice reprint managers.'
                      : 'Kituo kikuu cha kukusanya miamala yote. Ina mifumo ya kuzuia uchapishaji wa risiti wa udanganyifu, mihuri ya usalama ya kidijitali, na usimamizi wa ankara.'
                    }
                  </p>
                </div>

                <div className="pt-3.5 space-y-1">
                  <div className="text-xs font-black text-brand uppercase tracking-wide">
                    💸 {guideLang === 'en' ? 'Expenses Management' : 'Usimamizi wa Gharama'}
                  </div>
                  <p className="text-xs text-gray-600 font-medium leading-relaxed">
                    {guideLang === 'en'
                      ? 'Enables any cashier to register operating expenses (utilities, salaries, rent) on the spot to ensure dynamic real-time net-profit margins on the master dashboards.'
                      : 'Inaruhusu mfanyakazi yeyote kusajili gharama za uendeshaji (maji, umeme, mishahara, kodi) hapo kwa hapo ili kuhakikisha faida halisi inapatikana kwa usahihi.'
                    }
                  </p>
                </div>

                <div className="pt-3.5 space-y-1">
                  <div className="text-xs font-black text-brand uppercase tracking-wide">
                    🤝 {guideLang === 'en' ? 'Suppliers & Customers' : 'Wasambazaji na Wateja'}
                  </div>
                  <p className="text-xs text-gray-600 font-medium leading-relaxed">
                    {guideLang === 'en'
                      ? 'Manage profiles for business partners. Restrict suppliers and customers to target stores only, and manage credits/debits limits.'
                      : 'Dhibiti wasifu wa washirika wa biashara. Panga wasambazaji na wateja maalum kulingana na maduka wanayohudumia na dhibiti mikopo yao.'
                    }
                  </p>
                </div>

                <div className="pt-3.5 space-y-1">
                  <div className="text-xs font-black text-brand uppercase tracking-wide">
                    🛡️ {guideLang === 'en' ? 'Audit Trails & Security Logs' : 'Kumbukumbu za Usalama'}
                  </div>
                  <p className="text-xs text-gray-600 font-medium leading-relaxed">
                    {guideLang === 'en'
                      ? 'Immutable audit ledgers registering every administrative override, terminal selection change, and shift reconciliation. Keeps operations 100% transparent and leak-proof.'
                      : 'Kumbukumbu zisizofutika zinazosajili kila mabadiliko ya kiutawala na usuluhishi wa shift. Huweka shughuli zote wazi kwa asilimia 100 bila uvujaji wa mapato.'
                    }
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}

        <div className="mt-6 pt-6 border-t flex justify-end">
          <button
            onClick={onLogout}
            className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-semibold text-gray-700 hover:bg-gray-50 flex items-center gap-2 transition"
          >
            <LogOut className="w-4 h-4" /> {t('Sign Out')}
          </button>
        </div>
      </div>

      {/* Biometric Fingerprint Scanner Modal */}
      {showFpModal && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-xs flex items-center justify-center z-[110] p-4">
          <div className="bg-slate-900 border border-slate-700/80 rounded-3xl p-6 sm:p-8 w-full max-w-sm text-center shadow-2xl relative space-y-5 text-white">
            <button
              type="button"
              onClick={() => {
                setShowFpModal(false);
                setFpScanning(false);
              }}
              className="absolute top-4 right-4 text-slate-400 hover:text-white p-1.5 rounded-full hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="space-y-1">
              <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 flex items-center justify-center mx-auto mb-2 shadow-xs">
                <Fingerprint className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-black tracking-tight text-white">
                {fpMode === 'enroll' ? t('Enroll Fingerprint Password') : t('Verify Fingerprint Password')}
              </h3>
              <p className="text-xs text-slate-400">
                {fpMode === 'enroll'
                  ? t('Register your biometric fingerprint passkey for this device.')
                  : t('Touch sensor to authenticate your identity.')}
              </p>
            </div>

            {/* Current Password Validation during Enrollment */}
            {fpMode === 'enroll' && !currentUser.isRoot && currentUser.password && (
              <div className="text-left space-y-1.5 p-3 rounded-xl bg-slate-800/80 border border-slate-700 text-xs">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                  {t('Authorize with Account Password')} *
                </label>
                <input
                  type="password"
                  value={fpCurrentPwdCheck}
                  onChange={e => setFpCurrentPwdCheck(e.target.value)}
                  placeholder={t('Enter current password')}
                  className="w-full px-3 py-1.5 rounded-lg bg-slate-900 border border-slate-600 text-white font-medium text-xs outline-none focus:border-emerald-500"
                />
              </div>
            )}

            {/* Touch Scanner Interactive Visualizer */}
            <div className="py-4 flex flex-col items-center justify-center relative">
              <button
                type="button"
                onClick={handleStartSensorScan}
                disabled={fpScanning}
                className={`relative w-28 h-28 rounded-full flex items-center justify-center transition-all duration-300 cursor-pointer ${
                  fpSuccess
                    ? 'bg-emerald-500 text-white ring-8 ring-emerald-500/20 scale-105 shadow-[0_0_30px_rgba(16,185,129,0.5)]'
                    : fpScanning
                    ? 'bg-slate-800 text-emerald-400 ring-4 ring-emerald-500/40 animate-pulse shadow-[0_0_20px_rgba(16,185,129,0.3)]'
                    : 'bg-slate-800 hover:bg-slate-750 text-slate-300 hover:text-emerald-400 hover:scale-105 active:scale-95 ring-2 ring-slate-700 hover:ring-emerald-500/40 shadow-inner'
                }`}
              >
                {fpSuccess ? (
                  <CheckCircle2 className="w-14 h-14" />
                ) : (
                  <Fingerprint className={`w-14 h-14 ${fpScanning ? 'animate-pulse' : ''}`} />
                )}

                {/* Pulsing Scan Waves */}
                {fpScanning && (
                  <span className="absolute inset-0 rounded-full border-2 border-emerald-400 animate-ping opacity-75" />
                )}
              </button>

              <div className="mt-4 space-y-2 text-xs w-full max-w-xs">
                {fpSuccess ? (
                  <span className="font-extrabold text-emerald-400 block text-center">
                    ✓ {fpMode === 'enroll' ? t('Biometric Enrolled Successfully!') : t('Fingerprint Verified!')}
                  </span>
                ) : fpScanning ? (
                  <div className="space-y-1 text-center">
                    <span className="font-bold text-emerald-300 block animate-pulse">
                      {t('Waiting for device sensor...')}
                    </span>
                    <p className="text-[11px] text-slate-400">
                      {t('Touch your fingerprint sensor (Touch ID, Windows Hello, Android) when prompted.')}
                    </p>
                  </div>
                ) : (
                  <div className="text-center">
                    <button
                      type="button"
                      onClick={handleStartSensorScan}
                      className="text-emerald-400 hover:text-emerald-300 font-bold underline cursor-pointer text-xs"
                    >
                      {t('Click here to start hardware scan')}
                    </button>
                    <p className="text-[11px] text-slate-400 mt-1">
                      {t('Places your finger on your device biometric sensor')}
                    </p>
                  </div>
                )}

                {fpError && (
                  <div className="p-2.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-[11px] text-left flex items-start gap-2">
                    <ShieldAlert className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
                    <span className="leading-tight">{fpError}</span>
                  </div>
                )}
              </div>
            </div>

            <div className="pt-2 flex items-center justify-center gap-2">
              <button
                type="button"
                onClick={() => {
                  setShowFpModal(false);
                  setFpScanning(false);
                }}
                className="w-full py-2.5 rounded-xl border border-slate-700 hover:bg-slate-800 text-slate-300 font-bold text-xs transition"
              >
                {t('Cancel')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Game Chooser Modal */}
      {showGameChooser && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-xs flex items-center justify-center z-[100] p-4">
          <div className="bg-slate-800 border border-slate-700 rounded-2xl p-6 w-full max-w-md shadow-2xl">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-white text-xl font-bold flex items-center gap-2">
                <span>🎮</span>
                <span>Chagua Game - Choose Game</span>
              </h2>
              <button 
                onClick={() => setShowGameChooser(false)} 
                className="text-gray-400 hover:text-white text-lg font-bold w-7 h-7 rounded-full bg-white/10 flex items-center justify-center transition"
              >
                ✕
              </button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {/* Game 1: DIY POCKET V5 */}
              <div 
                onClick={() => {
                  setShowGameChooser(false);
                  if (onOpenGame) onOpenGame();
                }}
                className="bg-slate-700 rounded-xl p-4 hover:bg-slate-600 cursor-pointer border-2 border-transparent hover:border-red-500 transition flex flex-col justify-between group shadow"
              >
                <div>
                  <div className="bg-black h-24 rounded-lg mb-2.5 flex flex-col items-center justify-center text-cyan-400 text-xs font-mono border border-slate-600 group-hover:border-red-500 transition p-2 text-center">
                    <span className="text-xs font-bold text-amber-400">⨂ DIY POCKET V5 ⨂</span>
                    <span className="text-[9px] text-gray-400 mt-1">◀ LEFT • FIRE • RIGHT ▶</span>
                  </div>
                  <h3 className="text-white font-bold text-sm">DIY POCKET V5</h3>
                  <p className="text-gray-400 text-[11px]">SCORE:215 LVL:1</p>
                </div>
                <button 
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowGameChooser(false);
                    if (onOpenGame) onOpenGame();
                  }} 
                  className="mt-3 w-full bg-red-600 hover:bg-red-500 text-white text-xs font-bold py-2 rounded-lg transition"
                >
                  PLAY DIY POCKET
                </button>
              </div>

              {/* Game 2: Air Hockey Pro */}
              <div 
                onClick={() => {
                  setShowGameChooser(false);
                  setShowHockey(true);
                }}
                className="bg-slate-700 rounded-xl p-4 hover:bg-slate-600 cursor-pointer border-2 border-transparent hover:border-emerald-500 transition flex flex-col justify-between group shadow"
              >
                <div>
                  <div className="bg-[#0a0a12] h-24 rounded-lg mb-2.5 flex items-center justify-center border border-red-500/30 group-hover:border-emerald-500 transition relative overflow-hidden">
                    <div className="w-5 h-5 bg-red-500 rounded-full absolute left-3 shadow-[0_0_8px_#ff3333]"></div>
                    <div className="w-3 h-3 bg-white rounded-full absolute shadow-[0_0_6px_#ffffff]"></div>
                    <div className="w-5 h-5 bg-cyan-400 rounded-full absolute right-3 shadow-[0_0_8px_#00d9ff]"></div>
                    <span className="text-emerald-400 text-[9px] font-black bg-emerald-950/80 border border-emerald-500/50 px-1 rounded absolute top-1.5 right-1.5">NEW</span>
                  </div>
                  <h3 className="text-white font-bold text-sm flex items-center">
                    Air Hockey Pro <span className="bg-amber-400 text-slate-950 text-[9px] font-black px-1 rounded ml-1">NEW</span>
                  </h3>
                  <p className="text-gray-400 text-[11px]">vs AI & Multiplayer</p>
                </div>
                <button 
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowGameChooser(false);
                    setShowHockey(true);
                  }} 
                  className="mt-3 w-full bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold py-2 rounded-lg transition"
                >
                  PLAY AIR HOCKEY
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Air Hockey Pro Standalone Game Modal */}
      {showHockey && (
        <AirHockeyPro
          onClose={() => setShowHockey(false)}
          users={users}
          currentUser={currentUser}
        />
      )}
    </div>
  );
}
