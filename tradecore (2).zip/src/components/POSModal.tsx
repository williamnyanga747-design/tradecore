import React, { useState, useMemo, useEffect, useRef } from 'react';
import { Customer, StockItem, SalesOrder, Store, Settings, SOItem, PosShift, Expense } from '../types';
import { X, Search, Plus, Minus, Trash2, ShoppingBag, ShoppingCart, AlertTriangle, CheckCircle, Info, Printer, TrendingUp, Calculator, Lock, Share2, Mail, Check, Clock, Layers, ArrowDownRight, DollarSign, Receipt, Barcode, Tag, Download } from 'lucide-react';
import { formatMoney } from '../utils/format';
import { ConfirmActionModal } from './ConfirmActionModal';
import { handlePrintWithFallback } from '../utils/printHelper';
import { safeLower } from '../utils/stateHelpers';
import { toast } from '../utils/toast';
import { cleanCategoryName } from '../utils/categoryHelper';
import { calculateFIFOCost, getFIFOBatchBreakdown, getDaysUntilExpiry, getExpiryStatus } from '../utils/fifo';
import { connectBluetoothPrinter, isBluetoothPrinterConnected, sendEscPosBytes, buildReceiptEscPosBuffer } from '../utils/escposPrinter';
import { enqueueOfflineSale } from '../utils/offlinePersistence';
import { SmartMessagingModal } from './SmartMessagingModal';
import { sameId } from '../utils/idUtils';
import { encodeCode128B, generateBarcodeSvgString, CustomerPriceTier } from '../utils/barcodeUtils';

interface POSModalProps {
  isOpen: boolean;
  onClose: () => void;
  customers: Customer[];
  stockItems: StockItem[];
  salesOrders: SalesOrder[];
  currentStoreId: string | number | null;
  stores: Store[];
  saveAllData: (updatedFields: Partial<{
    salesOrders: SalesOrder[];
    stockItems: StockItem[];
    customers: Customer[];
    auditTrails: any[];
    posShifts: PosShift[];
    expenses: Expense[];
    settings: Settings;
  }>) => void;
  logAction: (action: string, details: string) => void;
  settings: Settings;
  t: (text: string) => string;
  currentUser: any;
  posShifts: PosShift[];
  expenses?: Expense[];
  currency?: string;
  exchangeRate?: number;
}

export default function POSModal({
  isOpen,
  onClose,
  customers,
  stockItems,
  salesOrders,
  currentStoreId,
  stores,
  saveAllData,
  logAction,
  settings,
  t,
  currentUser,
  posShifts = [],
  expenses = [],
  currency,
  exchangeRate
}: POSModalProps) {
  const activeCurrency = currency || settings.currency || 'USD';
  const activeExchangeRate = exchangeRate || settings.exchangeRate || 1;
  const activeCustomersForStore = useMemo(() => {
    return customers.filter(c => !c.storeId || sameId(c.storeId, currentStoreId));
  }, [customers, currentStoreId]);

  const [selectedCustomerId, setSelectedCustomerId] = useState<number>(activeCustomersForStore[0]?.id || 1);

  useEffect(() => {
    if (activeCustomersForStore.length > 0 && !activeCustomersForStore.some(c => c.id === selectedCustomerId)) {
      setSelectedCustomerId(activeCustomersForStore[0].id);
    }
  }, [activeCustomersForStore, selectedCustomerId]);

  const activeStores = useMemo(() => {
    const rawActive = stores.filter(s => !s.isDeleted);
    if (currentUser && currentUser.storeId) {
      return rawActive.filter(s => sameId(s.id, currentUser.storeId));
    }
    return rawActive;
  }, [stores, currentUser]);
  const [selectedStoreId, setSelectedStoreId] = useState<string | number | null>(currentStoreId || (activeStores[0]?.id ?? null));

  const prevIsOpenRef = useRef(isOpen);
  useEffect(() => {
    if (isOpen && !prevIsOpenRef.current && currentStoreId) {
      setSelectedStoreId(currentStoreId);
    }
    prevIsOpenRef.current = isOpen;
  }, [currentStoreId, isOpen]);
  const [priceType, setPriceType] = useState<'Retail' | 'Wholesale' | 'Preferred'>('Retail');
  const [searchQuery, setSearchQuery] = useState('');
  const [cart, setCart] = useState<{ productId: number; qty: number; price: number; cost: number }[]>([]);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [completedOrder, setCompletedOrder] = useState<SalesOrder | null>(null);
  const [activeTab, setActiveTab] = useState<'catalog' | 'cart'>('catalog');

  // Barcode Studio & Shelf Label Generator States
  const [showBarcodeModal, setShowBarcodeModal] = useState<boolean>(false);
  const [barcodeSelectedProduct, setBarcodeSelectedProduct] = useState<StockItem | null>(null);
  const [barcodePriceTier, setBarcodePriceTier] = useState<CustomerPriceTier>('Retail');
  const [barcodeLabelQty, setBarcodeLabelQty] = useState<number>(1);
  const [barcodeSearchTerm, setBarcodeSearchTerm] = useState<string>('');
  const [barcodePrintLayout, setBarcodePrintLayout] = useState<'thermal' | 'shelf' | 'sheet'>('thermal');

  const handleOpenBarcodeStudio = (product?: StockItem) => {
    if (product) {
      setBarcodeSelectedProduct(product);
    } else if (stockItems.length > 0 && !barcodeSelectedProduct) {
      setBarcodeSelectedProduct(stockItems[0]);
    }
    if (selectedCustomer?.type) {
      setBarcodePriceTier(selectedCustomer.type as CustomerPriceTier);
    } else {
      setBarcodePriceTier(priceType as CustomerPriceTier);
    }
    setShowBarcodeModal(true);
  };

  const handleDownloadBarcodeSvg = (sku: string, name: string) => {
    try {
      const svgStr = generateBarcodeSvgString(sku, 50, 2);
      const blob = new Blob([svgStr], { type: 'image/svg+xml' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `barcode-${sku.toLowerCase().replace(/[^a-z0-9]/g, '_')}.svg`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
      toast.success(`${t('Barcode SVG downloaded for')} ${name}`);
    } catch (err: any) {
      toast.error('Could not download SVG file');
    }
  };

  // Negative Stock and Held Carts features
  const [allowNegativeStock, setAllowNegativeStock] = useState<boolean>(false);
  const [suspendedCarts, setSuspendedCarts] = useState<{ id: number; customerId: number; cart: any[]; priceType: 'Retail' | 'Wholesale' | 'Preferred'; timestamp: string; note: string }[]>(() => {
    try {
      const saved = localStorage.getItem('pos_suspended_carts');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [pendingResumeCartId, setPendingResumeCartId] = useState<number | null>(null);

  useEffect(() => {
    localStorage.setItem('pos_suspended_carts', JSON.stringify(suspendedCarts));
  }, [suspendedCarts]);

  // Checkout & Payment states
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Bank' | 'Mobile Money' | 'Split'>('Cash');
  const [paymentStatus, setPaymentStatus] = useState<'Paid' | 'Credit' | 'Partial'>('Paid');
  const [cashAmount, setCashAmount] = useState<number>(0);
  const [bankAmount, setBankAmount] = useState<number>(0);
  const [mobileAmount, setMobileAmount] = useState<number>(0);
  const [orderDiscountType, setOrderDiscountType] = useState<'Flat' | 'Percentage'>('Flat');
  const [orderDiscountValue, setOrderDiscountValue] = useState<number>(0);
  const [orderNote, setOrderNote] = useState<string>('');

  // Digital Invoice / WhatsApp states
  const [showWhatsAppInput, setShowWhatsAppInput] = useState(false);
  const [showEmailInput, setShowEmailInput] = useState(false);
  const [whatsappPhone, setWhatsappPhone] = useState('');
  const [customerEmail, setCustomerEmail] = useState('');

  useEffect(() => {
    if (completedOrder) {
      const cust = customers.find(c => c.id === completedOrder.customerId);
      if (cust) {
        setWhatsappPhone(cust.phone || '');
        setCustomerEmail(cust.email || '');
      }
    } else {
      setShowWhatsAppInput(false);
      setShowEmailInput(false);
    }
  }, [completedOrder, customers]);

  const submitWhatsAppShare = () => {
    if (!whatsappPhone.trim()) {
      toast.warning(t('Please enter a valid phone number'));
      return;
    }
    const cust = customers.find(c => c.id === completedOrder?.customerId);
    const storeObj = stores.find(s => sameId(s.id, completedOrder?.storeId));
    const companyName = storeObj?.name || 'Store';
    const totalDisplay = formatMoney(completedOrder?.total || 0, activeCurrency, activeExchangeRate);

    let itemsText = '';
    completedOrder?.items.forEach((item, index) => {
      const prod = stockItems.find(p => p.id === item.productId);
      const prodName = prod ? prod.name : 'Unknown Product';
      const itemPrice = formatMoney(item.price, activeCurrency, activeExchangeRate);
      itemsText += `${index + 1}. ${prodName} x ${item.qty} @ ${itemPrice}\n`;
    });

    const textReceipt = `*RECEIPT / RISITI - ${companyName}*\n` +
      `-------------------------------------\n` +
      `*Order No:* ${completedOrder?.soNumber}\n` +
      `*Date / Tarehe:* ${completedOrder?.date}\n` +
      `*Customer / Mteja:* ${cust?.name || 'Walk-in'}\n` +
      `-------------------------------------\n` +
      `*Items / Bidhaa:*\n${itemsText}` +
      `-------------------------------------\n` +
      `*TOTAL / JUMLA:* *${totalDisplay}*\n\n` +
      `Thank you for shopping with us!\nAsanteni kwa kufanya biashara nasi! 🙏✨`;

    // Try opening whatsapp
    const cleanPhone = whatsappPhone.replace(/\D/g, ''); // strip non-numeric
    const whatsappUrl = `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodeURIComponent(textReceipt)}`;
    
    // Copy to clipboard as robust fallback
    try {
      navigator.clipboard.writeText(textReceipt);
      toast.success(t('Receipt details copied to clipboard as fallback!'));
    } catch (err) {}

    window.open(whatsappUrl, '_blank');
    toast.success(t('Receipt dispatched to WhatsApp!'));
    setShowWhatsAppInput(false);
    if (logAction && completedOrder) {
      logAction('WhatsApp Receipt Shared', `Dispatched receipt for ${completedOrder.soNumber} to ${cleanPhone}`);
    }
  };

  const submitEmailInvoice = () => {
    if (!customerEmail.trim()) {
      toast.warning(t('Please enter a valid email address'));
      return;
    }
    toast.success(`${t('Professional PDF Invoice sent successfully to')} ${customerEmail}!`);
    setShowEmailInput(false);
    if (logAction && completedOrder) {
      logAction('Email Invoice Sent', `Sent digital invoice for ${completedOrder.soNumber} to ${customerEmail}`);
    }
  };

  // Drawer / Shift ledger states
  const [showProfitBreakdownModal, setShowProfitBreakdownModal] = useState(false);
  const [openingFloatStr, setOpeningFloatStr] = useState('100');
  const [openingNotes, setOpeningNotes] = useState('');
  const [closingCashActualStr, setClosingCashActualStr] = useState('');
  const [closingNotes, setClosingNotes] = useState('');
  const [showClosingModal, setShowClosingModal] = useState(false);
  const [reconciledShiftSummary, setReconciledShiftSummary] = useState<any | null>(null);

  // Physical Denomination Count States
  const [denomCounts, setDenomCounts] = useState<Record<string, number>>({});
  const [showDenomOpen, setShowDenomOpen] = useState(false);
  const [showDenomClose, setShowDenomClose] = useState(false);

  const handleApplyDenoms = (target: 'open' | 'close') => {
    const denoms = activeCurrency === 'USD'
      ? [100, 50, 20, 10, 5, 2, 1, 0.25, 0.10, 0.05, 0.01]
      : [10000, 5000, 2000, 1000, 500, 200, 100, 50];
    const total = denoms.reduce((sum, d) => sum + d * (denomCounts[d] || 0), 0);
    if (target === 'open') {
      setOpeningFloatStr(total.toFixed(2).replace(/\.00$/, ''));
      setShowDenomOpen(false);
    } else {
      setClosingCashActualStr(total.toFixed(2).replace(/\.00$/, ''));
      setShowDenomClose(false);
    }
  };

  const renderPhysicalDenominationCalculator = (target: 'open' | 'close') => {
    const denoms = activeCurrency === 'USD'
      ? [100, 50, 20, 10, 5, 2, 1, 0.25, 0.10, 0.05, 0.01]
      : [10000, 5000, 2000, 1000, 500, 200, 100, 50];
    const total = denoms.reduce((sum, d) => sum + d * (denomCounts[d] || 0), 0);

    return (
      <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 space-y-3">
        <div className="flex items-center justify-between border-b pb-2">
          <span className="font-bold text-gray-800 text-[10px] uppercase tracking-wider flex items-center gap-1.5">
            <Calculator className="w-3.5 h-3.5 text-brand" /> {t('Physical Denomination Calculator')}
          </span>
          <button
            type="button"
            onClick={() => setDenomCounts({})}
            className="text-[10px] text-red-600 hover:underline font-bold"
          >
            {t('Reset')}
          </button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {denoms.map(d => (
            <div key={d} className="flex items-center gap-1.5 justify-between">
              <span className="text-[10px] font-mono font-bold text-gray-500 w-12">
                {activeCurrency === 'USD' ? `$${d}` : `${d}`}
              </span>
              <span className="text-[10px] text-gray-400">×</span>
              <input
                type="number"
                min="0"
                value={Number.isFinite(denomCounts[d]) && denomCounts[d] ? denomCounts[d] : ''}
                onChange={(e) => {
                  const val = parseInt(e.target.value, 10) || 0;
                  setDenomCounts(prev => ({ ...prev, [d]: val }));
                }}
                className="w-16 px-2 py-1 border border-gray-200 rounded text-center text-xs font-bold"
                placeholder="0"
              />
              <span className="text-[10px] font-mono text-gray-600 w-16 text-right">
                = {formatMoney(d * (denomCounts[d] || 0), activeCurrency, activeExchangeRate)}
              </span>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between border-t pt-2 mt-2">
          <span className="text-xs font-bold text-slate-800">
            {t('Total Counted')}: <span className="font-mono text-brand font-black">{formatMoney(total, activeCurrency, activeExchangeRate)}</span>
          </span>
          <div className="flex gap-1.5">
            <button
              type="button"
              onClick={() => {
                if (target === 'open') setShowDenomOpen(false);
                else setShowDenomClose(false);
              }}
              className="px-2.5 py-1 border rounded text-[10px] font-bold text-gray-500 hover:bg-gray-100 transition"
            >
              {t('Hide')}
            </button>
            <button
              type="button"
              onClick={() => handleApplyDenoms(target)}
              className="px-3 py-1 bg-brand text-white rounded text-[10px] font-bold shadow-xs hover:bg-brand-hover transition"
            >
              {t('Apply Count')}
            </button>
          </div>
        </div>
      </div>
    );
  };

  const isAdminUser = useMemo(() => {
    return !!(currentUser && ['Super Admin', 'Admin', 'Store Admin', 'Branch Administrator'].includes(currentUser.role));
  }, [currentUser]);

  // Strict Company Administrator check: Only Company Admin (Super Admin / Admin / ROOT_MANDATE) can Close Cash Drawer & Reconcile
  const isCompanyAdmin = useMemo(() => {
    if (!currentUser) return false;
    const r = String(currentUser.role || '').trim().toLowerCase();
    return r === 'admin' || r === 'super admin' || r === 'superadmin' || r === 'root_mandate';
  }, [currentUser]);

  const activeShift = useMemo(() => {
    return (posShifts || []).find(
      s => s.status === 'Open' && sameId(s.storeId, selectedStoreId)
    );
  }, [posShifts, selectedStoreId]);

  // Auto-linked expenses for this active shift:
  // Dynamically aggregates all expenses linked directly by posShiftId,
  // or present in activeShift.expenseIds, or logged with paidFromDrawerFloat === true for this store during the shift!
  const linkedShiftExpenses = useMemo(() => {
    if (!activeShift) return [];
    return (expenses || []).filter(e => {
      if (e.isDeleted) return false;
      if (e.posShiftId != null && e.posShiftId === activeShift.id) return true;
      if (activeShift.expenseIds && activeShift.expenseIds.includes(e.id)) return true;
      if (e.paidFromDrawerFloat && sameId(e.storeId, activeShift.storeId)) {
        const shiftDate = activeShift.openTime ? activeShift.openTime.split('T')[0] : '';
        if (!shiftDate || e.date >= shiftDate) return true;
      }
      return false;
    });
  }, [expenses, activeShift]);

  // Total drawer cash expenses automatically computed from linkedShiftExpenses:
  const autoDrawerExpensesTotal = useMemo(() => {
    const sumLinked = linkedShiftExpenses.reduce((sum, e) => sum + (e.amount || 0), 0);
    return Math.max(sumLinked, activeShift?.drawerExpensesTotal || 0);
  }, [linkedShiftExpenses, activeShift]);

  // Confirm Modal state
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    description: '',
    onConfirm: () => {}
  });

  // Filter products by search query
  const filteredProducts = useMemo(() => {
    return stockItems.filter(item => {
      const nameMatch = safeLower(item.name).includes(searchQuery.toLowerCase());
      const codeMatch = safeLower(item.code).includes(searchQuery.toLowerCase());
      const categoryMatch = (item.category || 'Uncategorized').toLowerCase().includes(searchQuery.toLowerCase());
      return nameMatch || codeMatch || categoryMatch;
    });
  }, [stockItems, searchQuery]);

  // Scalable catalog pagination (caps rendered DOM elements to 48 for 60fps performance)
  const [catalogPage, setCatalogPage] = useState<number>(1);
  const POS_PAGE_SIZE = 48;

  useEffect(() => {
    setCatalogPage(1);
  }, [searchQuery]);

  const totalCatalogPages = Math.max(1, Math.ceil(filteredProducts.length / POS_PAGE_SIZE));
  const currentCatalogPage = Math.min(catalogPage, totalCatalogPages);
  const paginatedCatalogProducts = useMemo(() => {
    return filteredProducts.slice((currentCatalogPage - 1) * POS_PAGE_SIZE, currentCatalogPage * POS_PAGE_SIZE);
  }, [filteredProducts, currentCatalogPage]);

  // Selected customer object
  const selectedCustomer = useMemo(() => {
    return customers.find(c => c.id === selectedCustomerId);
  }, [customers, selectedCustomerId]);

  // Auto-apply customer pricing tier when customer changes
  useEffect(() => {
    if (selectedCustomer) {
      handlePriceTypeChange(selectedCustomer.type);
    }
  }, [selectedCustomerId, selectedCustomer]);

  // Helper to get active product price
  const getProductPrice = (item: StockItem, unitType: 'main' | 'sub' = 'main', activePriceType?: 'Retail' | 'Wholesale' | 'Preferred') => {
    const currentPriceType = activePriceType || priceType;
    if (unitType === 'sub') {
      let price = 0;
      if (currentPriceType === 'Wholesale') price = item.subUnitWholesalePrice ?? item.subUnitRetailPrice ?? 0;
      else if (currentPriceType === 'Preferred') price = item.subUnitPartnerPrice ?? item.subUnitRetailPrice ?? 0;
      else price = item.subUnitRetailPrice ?? 0;

      // If price is 0, calculate it proportionally from the wholesale package price
      if (price <= 0) {
        const parentPrice = currentPriceType === 'Wholesale' ? item.wholesalePrice : (currentPriceType === 'Preferred' ? (item.partnerPrice ?? item.retailPrice) : item.retailPrice);
        const conversion = item.subUnitConversion || 1;
        price = parentPrice / conversion;
      }
      return price;
    }
    if (currentPriceType === 'Wholesale') return item.wholesalePrice;
    if (currentPriceType === 'Preferred') return item.partnerPrice ?? item.retailPrice;
    return item.retailPrice;
  };

  // Helper to check stock in current store
  const getStockQty = (item: StockItem, storeId: string | number | null) => {
    return (item && item.stock ? item.stock[storeId as number] : 0) || 0;
  };

  const formatStockQty = (qty: number, item: StockItem) => {
    if (item.useSubUnitPricing && item.subUnitConversion && item.subUnitConversion > 1) {
      const mainUnits = Math.floor(qty / item.subUnitConversion);
      const subUnits = parseFloat((qty % item.subUnitConversion).toFixed(4));
      
      const mainLabel = item.unit || 'Pkg';
      const subLabel = item.subUnitName || 'pcs';
      
      if (mainUnits > 0 && subUnits > 0) {
        return `${mainUnits} ${mainLabel}, ${subUnits} ${subLabel}`;
      } else if (mainUnits > 0) {
        return `${mainUnits} ${mainLabel}`;
      } else {
        return `${subUnits} ${subLabel}`;
      }
    }
    return `${qty} ${item.unit || 'pcs'}`;
  };

  // Helper to calculate total of a product in the cart in terms of base units
  const getProductTotalInCartInBaseUnits = (productId: number, excludeUnitType?: 'main' | 'sub') => {
    let totalBaseUnits = 0;
    cart.forEach(c => {
      if (c.productId === productId && (excludeUnitType === undefined || (c.unitType || 'main') !== excludeUnitType)) {
        const item = stockItems.find(p => p.id === productId);
        if (item) {
          const conversion = (c.unitType || 'main') === 'main' ? (item.subUnitConversion || 1) : 1;
          totalBaseUnits += c.qty * conversion;
        }
      }
    });
    return totalBaseUnits;
  };

  // Add to Cart
  const handleAddToCart = (item: StockItem) => {
    setErrorMsg(null);
    const availableStock = getStockQty(item, selectedStoreId); // in base units
    if (availableStock <= 0 && !allowNegativeStock) {
      setErrorMsg(`${t('Product')} "${item.name}" ${t('is out of stock in this store!')}`);
      return;
    }

    const existingCartIndex = cart.findIndex(c => c.productId === item.id && (c.unitType || 'main') === 'main');
    const targetPrice = getProductPrice(item, 'main');

    const itemConversion = item.subUnitConversion || 1;
    if (existingCartIndex > -1) {
      const currentQtyInCart = cart[existingCartIndex].qty;
      const otherBaseUnits = getProductTotalInCartInBaseUnits(item.id, 'main');
      const totalRequiredBaseUnits = otherBaseUnits + (currentQtyInCart + 1) * itemConversion;
      if (totalRequiredBaseUnits > availableStock && !allowNegativeStock) {
        const availableInUnit = (availableStock - otherBaseUnits) / itemConversion;
        setErrorMsg(`${t('Requested')} ${currentQtyInCart + 1} ${item.unit || 'unit'} ${t('exceeds available stock of')} ${parseFloat(availableInUnit.toFixed(4))} ${item.unit || 'unit'}.`);
        return;
      }
      const updatedCart = [...cart];
      updatedCart[existingCartIndex].qty += 1;
      // Keep price updated just in case pricing mode changed
      updatedCart[existingCartIndex].price = targetPrice;
      setCart(updatedCart);
    } else {
      const otherBaseUnits = getProductTotalInCartInBaseUnits(item.id);
      const totalRequiredBaseUnits = otherBaseUnits + 1 * itemConversion;
      if (totalRequiredBaseUnits > availableStock && !allowNegativeStock) {
        const availableInUnit = (availableStock - otherBaseUnits) / itemConversion;
        setErrorMsg(`${t('Requested')} 1 ${item.unit || 'unit'} ${t('exceeds available stock of')} ${parseFloat(availableInUnit.toFixed(4))} ${item.unit || 'unit'}.`);
        return;
      }
      setCart([
        ...cart,
        {
          productId: item.id,
          qty: 1,
          price: targetPrice,
          cost: item.purchasePrice,
          unitType: 'main'
        }
      ]);
    }
  };

  const handleToggleCartUnit = (productId: number, unitType: 'main' | 'sub') => {
    const item = stockItems.find(p => p.id === productId);
    if (!item) return;
    setCart(cart.map(c => {
      if (c.productId === productId) {
        const nextPrice = getProductPrice(item, unitType);
        const nextCost = unitType === 'sub' ? item.purchasePrice / (item.subUnitConversion || 1) : item.purchasePrice;
        return {
          ...c,
          unitType,
          price: nextPrice,
          cost: nextCost
        };
      }
      return c;
    }));
  };

  // Update Cart Qty
  const handleUpdateQty = (productId: number, unitType: 'main' | 'sub', newQty: number) => {
    setErrorMsg(null);
    const item = stockItems.find(p => p.id === productId);
    if (!item) return;

    if (newQty <= 0) {
      handleRemoveItem(productId, unitType);
      return;
    }

    const availableStock = getStockQty(item, selectedStoreId); // in base units
    const conversion = unitType === 'main' ? (item.subUnitConversion || 1) : 1;
    const requestedBaseUnits = newQty * conversion;
    const otherBaseUnits = getProductTotalInCartInBaseUnits(productId, unitType);

    if (otherBaseUnits + requestedBaseUnits > availableStock && !allowNegativeStock) {
      const maxAllowedInThisUnit = (availableStock - otherBaseUnits) / conversion;
      const unitLabel = unitType === 'sub' ? (item.subUnitName || 'sub-unit') : (item.unit || 'unit');
      setErrorMsg(`${t('Requested')} ${newQty} ${unitLabel} ${t('exceeds available stock of')} ${parseFloat(maxAllowedInThisUnit.toFixed(4))} ${unitLabel}.`);
      return;
    }

    setCart(cart.map(c => {
      if (c.productId === productId && (c.unitType || 'main') === unitType) {
        return { ...c, qty: newQty };
      }
      return c;
    }));
  };

  // Remove from Cart
  const handleRemoveItem = (productId: number, unitType: 'main' | 'sub' = 'main') => {
    setCart(cart.filter(c => !(c.productId === productId && (c.unitType || 'main') === unitType)));
  };

  // Recalculate cart prices when pricing mode changes
  const handlePriceTypeChange = (newMode: 'Retail' | 'Wholesale' | 'Preferred') => {
    setPriceType(newMode);
    setCart(cart.map(c => {
      const item = stockItems.find(p => p.id === c.productId);
      if (item) {
        const price = getProductPrice(item, c.unitType || 'main', newMode);
        return {
          ...c,
          price
        };
      }
      return c;
    }));
  };

  // Totals calculations using FIFO cost evaluation
  const totals = useMemo(() => {
    let grossTotal = 0;
    let totalCost = 0;

    // Group cart items by productId to evaluate FIFO costs collectively
    const cartByProduct: { [productId: number]: number } = {};
    cart.forEach(c => {
      grossTotal += c.price * c.qty;
      const item = stockItems.find(p => p.id === c.productId);
      if (item) {
        const conversion = c.unitType === 'main' && item.useSubUnitPricing ? (item.subUnitConversion || 1) : 1;
        const requiredBaseUnits = c.qty * conversion;
        cartByProduct[c.productId] = (cartByProduct[c.productId] || 0) + requiredBaseUnits;
      } else {
        totalCost += c.cost * c.qty;
      }
    });

    Object.entries(cartByProduct).forEach(([pIdStr, requiredBaseUnits]) => {
      const productId = Number(pIdStr);
      const item = stockItems.find(p => p.id === productId);
      if (item) {
        const fifoResult = calculateFIFOCost(item, selectedStoreId as number, requiredBaseUnits);
        totalCost += fifoResult.totalCost;
      }
    });

    const discountAmount = orderDiscountType === 'Percentage'
      ? grossTotal * (orderDiscountValue / 100)
      : orderDiscountValue;
    const finalTotal = Math.max(0, grossTotal - discountAmount);
    return {
      gross: grossTotal,
      discount: discountAmount,
      total: finalTotal,
      cost: totalCost,
      profit: finalTotal - totalCost
    };
  }, [cart, stockItems, selectedStoreId, orderDiscountType, orderDiscountValue]);

  // Hold / Suspend current active cart
  const handleSuspendCart = () => {
    if (cart.length === 0) {
      toast.warning(t('Cannot hold an empty cart'));
      return;
    }
    const newSuspended = {
      id: Date.now(),
      customerId: selectedCustomerId,
      cart,
      priceType,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      note: orderNote || `${t('Draft')} - ${cart.length} ${t('items')}`
    };
    setSuspendedCarts([...suspendedCarts, newSuspended]);
    setCart([]);
    setOrderNote('');
    toast.success(t('Cart has been put on Hold (Suspended)'));
  };

  // Check customer credit limit validation
  const isCreditExceeded = useMemo(() => {
    if (!selectedCustomer || priceType !== 'Wholesale') return false;
    const currentBalance = selectedCustomer.balance || 0;
    const newTotal = totals.total;
    return (currentBalance + newTotal) > (selectedCustomer.creditLimit || 0);
  }, [selectedCustomer, priceType, totals.total]);

  // Active shift sales metrics & statistics for empty cart panel and audit
  const shiftOrders = useMemo(() => {
    return salesOrders.filter(so => {
      if (!sameId(so.storeId, selectedStoreId) || so.status === 'Voided') return false;
      if (activeShift && activeShift.startTime) {
        return new Date(so.date) >= new Date(activeShift.startTime);
      }
      return true;
    });
  }, [salesOrders, selectedStoreId, activeShift]);

  const shiftTotalRevenue = useMemo(() => {
    return shiftOrders.reduce((sum, so) => sum + (so.total || 0), 0);
  }, [shiftOrders]);

  const shiftProductsSoldVolume = useMemo(() => {
    return shiftOrders.reduce((sum, so) => {
      const itemsCount = so.items?.reduce((iSum, item) => iSum + (item.qty || 0), 0) || 0;
      return sum + itemsCount;
    }, 0);
  }, [shiftOrders]);

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
        e.preventDefault();
        handleCheckout();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, cart, activeShift, allowNegativeStock, stockItems, selectedStoreId, salesOrders, paymentMethod, paymentStatus, cashAmount, bankAmount, mobileAmount, totals, priceType, selectedCustomerId]);

  // Submit checkout order
  const handleCheckout = () => {
    if (cart.length === 0) {
      setErrorMsg(t('Please add at least one product to check out'));
      return;
    }

    if (!activeShift) {
      setErrorMsg(t('Please open register drawer session before checkout'));
      return;
    }

    // Double check stock validation
    if (!allowNegativeStock) {
      for (const cartItem of cart) {
        const item = stockItems.find(p => p.id === cartItem.productId);
        if (!item) continue;
        const currentStock = getStockQty(item, selectedStoreId); // in base units
        const conversion = cartItem.unitType === 'main' ? (item.subUnitConversion || 1) : 1;
        const requiredQtyInBaseUnits = cartItem.qty * conversion;
        if (requiredQtyInBaseUnits > currentStock) {
          const availableInUnit = currentStock / conversion;
          const unitLabel = cartItem.unitType === 'sub' ? (item.subUnitName || 'sub-unit') : (item.unit || 'unit');
          setErrorMsg(`${t('Requested')} ${cartItem.qty} ${unitLabel} ${t('exceeds available stock of')} ${parseFloat(availableInUnit.toFixed(4))} ${unitLabel}.`);
          return;
        }
      }
    }

    const maxId = salesOrders.length > 0 ? Math.max(...salesOrders.map(s => s.id)) : 0;
    
    // Determine actual cash portion received to track in register shift drawer
    let cashPaidPortion = 0;
    if (paymentMethod === 'Cash' && paymentStatus === 'Paid') {
      cashPaidPortion = totals.total;
    } else if (paymentMethod === 'Split') {
      cashPaidPortion = cashAmount;
    } else if (paymentMethod === 'Cash' && paymentStatus === 'Partial') {
      cashPaidPortion = cashAmount || (totals.total * 0.5); // Fallback to half if not specified
    }

    // Outstanding credit portion to add to customer balance
    let creditOutstanding = 0;
    if (paymentStatus === 'Credit') {
      creditOutstanding = totals.total;
    } else if (paymentStatus === 'Partial') {
      const totalPaid = paymentMethod === 'Split'
        ? (cashAmount + bankAmount + mobileAmount)
        : (paymentMethod === 'Cash' ? cashAmount : (paymentMethod === 'Bank' ? bankAmount : mobileAmount));
      creditOutstanding = Math.max(0, totals.total - totalPaid);
    } else if (priceType === 'Wholesale' && paymentStatus === 'Credit') {
      creditOutstanding = totals.total;
    }

    const storeObj = stores.find(s => sameId(s.id, selectedStoreId));
    const effectiveCompanyId = (storeObj as any)?.companyId ?? currentUser?.company_id ?? currentUser?.companyId ?? 1;

    const newSO: SalesOrder = {
      id: maxId + 1,
      soNumber: `SO-2024-${String(5004 + maxId).padStart(4, '0')}`,
      customerId: selectedCustomerId,
      storeId: selectedStoreId as number,
      companyId: effectiveCompanyId,
      date: new Date().toISOString().split('T')[0],
      priceType: priceType,
      items: cart.map(c => {
        const item = stockItems.find(p => p.id === c.productId);
        return {
          productId: c.productId,
          qty: c.qty,
          price: c.price,
          cost: c.cost,
          unitType: c.unitType || 'main',
          subUnitName: c.unitType === 'sub' ? item?.subUnitName : undefined
        };
      }),
      total: totals.total,
      profit: totals.profit,
      status: 'Completed',
      paymentMethod: paymentMethod,
      paymentStatus: paymentStatus,
      paymentSplit: paymentMethod === 'Split' ? { cash: cashAmount, bank: bankAmount, mobile: mobileAmount } : undefined
    };

    // Subtract stock quantities and deduct from FIFO batches
    const updatedStockItems = stockItems.map(p => {
      const matchingCartItems = cart.filter(c => c.productId === p.id);
      if (matchingCartItems.length > 0) {
        const nextStockObj = { ...p.stock };
        let totalDeductionInBaseUnits = 0;
        matchingCartItems.forEach(cartItem => {
          const conversion = cartItem.unitType === 'main' ? (p.subUnitConversion || 1) : 1;
          totalDeductionInBaseUnits += cartItem.qty * conversion;
        });

        // Deduct from FIFO batch queue
        const fifoResult = calculateFIFOCost(p, selectedStoreId as number, totalDeductionInBaseUnits);
        const updatedBatchesMap = { ...(p.batches || {}) };
        updatedBatchesMap[selectedStoreId as number] = fifoResult.updatedBatches;

        const currentStockVal = nextStockObj[selectedStoreId as number] || 0;
        nextStockObj[selectedStoreId as number] = allowNegativeStock ? (currentStockVal - totalDeductionInBaseUnits) : Math.max(0, currentStockVal - totalDeductionInBaseUnits);
        return { ...p, stock: nextStockObj, batches: updatedBatchesMap };
      }
      return p;
    });

    // Update customer outstanding balance
    const updatedCustomers = customers.map(c => {
      if (c.id === selectedCustomerId) {
        return {
          ...c,
          balance: (c.balance || 0) + creditOutstanding
        };
      }
      return c;
    });

    // Update POS active shift statistics
    const updatedShifts = posShifts.map(s => {
      if (s.id === activeShift.id) {
        return {
          ...s,
          salesOrderIds: [...(s.salesOrderIds || []), newSO.id],
          expectedCashSales: (s.expectedCashSales || 0) + cashPaidPortion
        };
      }
      return s;
    });

    saveAllData({
      salesOrders: [newSO, ...salesOrders],
      stockItems: updatedStockItems,
      customers: updatedCustomers,
      posShifts: updatedShifts
    });

    // OFFLINE-FIRST: if this device is disconnected, persist the sale into the durable
    // IndexedDB sync_queue (unified with categories/products/users/audit mutations) so it
    // is GUARANTEED to reach php_sync.php on the next `online`/boot drain even if the tab
    // closes. When online, the normal save_state pipeline covers it (no double-write).
    const isOfflineNow = typeof navigator !== 'undefined' && navigator.onLine === false;
    if (isOfflineNow) {
      const companyId = currentUser?.company_id ?? currentUser?.companyId ?? '';
      enqueueOfflineSale(
        { ...newSO, customerName: selectedCustomer?.name ?? '', storeName: activeStores.find(s => sameId(s.id, selectedStoreId))?.name ?? '' },
        companyId
      );
    }

    logAction('POS Checkout', `Created checkout invoice: ${newSO.soNumber} for customer ${selectedCustomer?.name || 'Unknown'}`);
    setCompletedOrder(newSO);
  };

  // Open POS register shift
  const handleOpenShift = () => {
    const floatAmount = parseFloat(openingFloatStr) || 0;
    const newShift: PosShift = {
      id: posShifts.length > 0 ? Math.max(...posShifts.map(s => s.id)) + 1 : 1,
      userId: currentUser?.id || 1,
      username: currentUser?.name || 'Cashier',
      storeId: selectedStoreId as number,
      openTime: new Date().toISOString(),
      openingFloat: floatAmount,
      expectedCashSales: 0,
      salesOrderIds: [],
      status: 'Open'
    };

    saveAllData({
      posShifts: [newShift, ...posShifts]
    });

    logAction('Open POS Shift', `Opened register shift for cashier ${currentUser?.name || 'Cashier'} with float amount ${floatAmount}`);
  };

  // Close POS register shift (strictly restricted to Company Admin)
  const handleCloseShift = () => {
    if (!activeShift) return;
    if (!isCompanyAdmin) {
      toast.error(t('Access Denied: Only a Company Administrator has permission to close the cash drawer and reconcile the shift.'));
      return;
    }
    const actualCash = parseFloat(closingCashActualStr) || 0;
    const drawerExpenses = autoDrawerExpensesTotal;
    const expectedTotal = activeShift.openingFloat + (activeShift.expectedCashSales || 0) - drawerExpenses;
    const variance = actualCash - expectedTotal;
    const allLinkedExpIds = Array.from(new Set([...(activeShift.expenseIds || []), ...linkedShiftExpenses.map(e => e.id)]));

    const updatedShifts = posShifts.map(s => {
      if (s.id === activeShift.id) {
        return {
          ...s,
          closeTime: new Date().toISOString(),
          closingCashActual: actualCash,
          drawerExpensesTotal: drawerExpenses,
          expenseIds: allLinkedExpIds,
          variance: variance,
          notes: closingNotes,
          status: 'Closed' as const
        };
      }
      return s;
    });

    const reconciledShift = {
      ...activeShift,
      closeTime: new Date().toISOString(),
      closingCashActual: actualCash,
      drawerExpensesTotal: drawerExpenses,
      expenseIds: allLinkedExpIds,
      linkedExpenses: linkedShiftExpenses,
      variance,
      notes: closingNotes,
      status: 'Closed' as const
    };

    saveAllData({
      posShifts: updatedShifts
    });

    logAction('Close POS Shift', `Closed register shift with variance: ${variance} (Deducted ${drawerExpenses} USD in auto-linked drawer expenses)`);
    setReconciledShiftSummary(reconciledShift);
    setShowClosingModal(false);
  };

  if (!isOpen) return null;

  // Render finalized shift summary slip
  if (reconciledShiftSummary) {
    const storeObj = stores.find(s => sameId(s.id, reconciledShiftSummary.storeId));
    const drawerExpTotal = reconciledShiftSummary.drawerExpensesTotal || 0;
    const expectedTotal = reconciledShiftSummary.openingFloat + (reconciledShiftSummary.expectedCashSales || 0) - drawerExpTotal;
    const varAmount = reconciledShiftSummary.variance || 0;
    
    return (
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[92vh]">
          <div className="px-5 py-4 border-b flex items-center justify-between bg-emerald-700 text-white">
            <span className="font-bold flex items-center gap-2 text-sm">
              <CheckCircle className="w-5 h-5 text-emerald-400" /> Shift Reconciled Successfully
            </span>
            <button 
              onClick={() => {
                setReconciledShiftSummary(null);
                onClose();
              }} 
              className="p-1 hover:bg-emerald-800 rounded text-emerald-200 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="p-6 space-y-4 overflow-y-auto max-h-[75vh]" id="shift-summary-print-area">
            <div className="text-center pb-4 border-b border-dashed">
              <h4 className="font-black text-gray-900 text-base">SINGIDA TRADECORE ERP</h4>
              <p className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Drawer Session Close Out Ledger</p>
              <p className="text-xs text-gray-500 font-semibold mt-1">Store Depot: {storeObj?.name || 'Store'}</p>
            </div>

            <div className="space-y-3.5 text-xs">
              <div className="flex justify-between font-semibold border-b pb-2">
                <span className="text-gray-400">Cashier Session</span>
                <span className="font-bold text-gray-900">{reconciledShiftSummary.username}</span>
              </div>
              <div className="flex justify-between font-semibold border-b pb-2">
                <span className="text-gray-400">Opened At</span>
                <span className="font-mono text-gray-900">{new Date(reconciledShiftSummary.openTime).toLocaleString()}</span>
              </div>
              <div className="flex justify-between font-semibold border-b pb-2">
                <span className="text-gray-400">Closed At</span>
                <span className="font-mono text-gray-900">{new Date(reconciledShiftSummary.closeTime).toLocaleString()}</span>
              </div>
              <div className="flex justify-between font-semibold border-b pb-2">
                <span className="text-gray-400">Opening Float</span>
                <span className="font-bold text-gray-900">{formatMoney(reconciledShiftSummary.openingFloat, activeCurrency, activeExchangeRate)}</span>
              </div>
              <div className="flex justify-between font-semibold border-b pb-2">
                <span className="text-gray-400">Expected Register Cash Sales</span>
                <span className="font-bold text-emerald-700">+{formatMoney(reconciledShiftSummary.expectedCashSales || 0, activeCurrency, activeExchangeRate)}</span>
              </div>
              {drawerExpTotal > 0 && (
                <div className="border-b pb-2 text-rose-700 space-y-1">
                  <div className="flex justify-between font-semibold">
                    <span className="text-rose-600 font-bold">{t('Drawer Expenses Paid Out')}</span>
                    <span className="font-bold">-{formatMoney(drawerExpTotal, activeCurrency, activeExchangeRate)}</span>
                  </div>
                  {reconciledShiftSummary.linkedExpenses && reconciledShiftSummary.linkedExpenses.length > 0 && (
                    <div className="bg-rose-50/60 p-2 rounded text-[10px] space-y-1 font-mono">
                      {reconciledShiftSummary.linkedExpenses.map((exp: any) => (
                        <div key={exp.id} className="flex justify-between text-gray-700">
                          <span className="truncate max-w-[240px]">• {exp.description}</span>
                          <span className="font-bold text-rose-600">-{formatMoney(exp.amount, activeCurrency, activeExchangeRate)}</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
              <div className="flex justify-between font-semibold border-b pb-2">
                <span className="text-gray-400">Theoretical Drawer Cash (Expected)</span>
                <span className="font-bold text-gray-900">{formatMoney(expectedTotal, activeCurrency, activeExchangeRate)}</span>
              </div>
              <div className="flex justify-between font-semibold border-b pb-2 bg-slate-50 p-2 rounded">
                <span className="text-slate-500 font-bold">Actual Counted Cash (Declared)</span>
                <span className="font-black text-slate-900">{formatMoney(reconciledShiftSummary.closingCashActual || 0, activeCurrency, activeExchangeRate)}</span>
              </div>
              
              <div className={`flex justify-between font-black border-b pb-2 p-2 rounded ${
                varAmount < 0 ? 'bg-red-50 text-red-700' : varAmount > 0 ? 'bg-amber-50 text-amber-700' : 'bg-green-50 text-green-700'
              }`}>
                <span>Cash Reconciliation Variance</span>
                <span>{varAmount > 0 ? '+' : ''}{formatMoney(varAmount, activeCurrency, activeExchangeRate)}</span>
              </div>
              
              {reconciledShiftSummary.notes && (
                <div className="bg-gray-50 p-2.5 rounded text-[11px] font-semibold text-gray-600">
                  <span className="font-bold block text-gray-400 uppercase tracking-wider text-[9px] mb-1">Cashier Closing Remarks:</span>
                  {reconciledShiftSummary.notes}
                </div>
              )}
            </div>

            <div className="flex gap-2 pt-2 no-print">
              <button
                onClick={() => {
                  window.print();
                }}
                className="flex-1 py-2 border border-gray-300 hover:bg-gray-50 text-gray-700 font-bold rounded-lg text-xs transition flex items-center justify-center gap-1.5"
              >
                <Printer className="w-3.5 h-3.5" /> Print Audit Slip
              </button>
              <button
                onClick={() => {
                  setReconciledShiftSummary(null);
                  onClose();
                }}
                className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs transition"
              >
                Complete Shift
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Render open register screen if session is closed
  if (!activeShift) {
    const storeObj = stores.find(s => sameId(s.id, selectedStoreId));

    if (!isAdminUser) {
      return (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col">
            {/* Header */}
            <div className="px-5 py-4 border-b flex items-center justify-between bg-red-900 text-white flex-shrink-0">
              <span className="font-bold flex items-center gap-2 text-sm">
                <Lock className="w-5 h-5 text-red-300" /> {t('Access Restricted')}
              </span>
              <button onClick={onClose} className="p-1 hover:bg-red-800 rounded text-red-200 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-6 text-center space-y-4">
              <div className="mx-auto w-12 h-12 rounded-full bg-red-100 flex items-center justify-center text-red-600 animate-pulse">
                <Lock className="w-6 h-6" />
              </div>
              <h3 className="text-sm font-black text-gray-900">{t('Cash Register Drawer Closed')}</h3>
              <p className="text-xs font-semibold text-gray-600 leading-relaxed">
                {t('The cash drawer for this store is currently closed. Only administrators or store administrators are authorized to open and register the cash drawer float.')}
              </p>
              <div className="p-3 bg-gray-50 rounded-lg text-[10px] font-bold text-gray-500 text-left space-y-1">
                <span className="block">{t('Selected Depot / Store')}: <strong className="text-gray-800">{storeObj?.name || 'Main Depot'}</strong></span>
                <span className="block">{t('Authorized Roles')}: <strong className="text-emerald-700">Super Admin, Admin, Store Admin, Branch Administrator</strong></span>
              </div>
              {activeStores.length > 1 && (
                <div className="space-y-1 text-left">
                  <label className="text-[10px] font-black uppercase tracking-wider text-gray-400 block">{t('Switch POS Depot / Store')}</label>
                  <select
                    value={selectedStoreId}
                    onChange={(e) => setSelectedStoreId(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg text-xs font-semibold outline-none bg-white"
                  >
                    {activeStores.map(s => (
                      <option key={s.id} value={s.id}>{s.name} - {s.location}</option>
                    ))}
                  </select>
                </div>
              )}
              <div className="pt-2">
                <button
                  onClick={onClose}
                  className="w-full py-2 bg-gray-900 hover:bg-gray-800 text-white font-bold rounded-lg text-xs transition"
                >
                  {t('Back to Dashboard')}
                </button>
              </div>
            </div>
          </div>
        </div>
      );
    }

    const getFloatPresets = () => {
      if (activeCurrency === 'TZS') {
        return [
          { label: t('Standard Day Float'), value: 100000 },
          { label: t('Weekend Float'), value: 250000 },
          { label: t('Minimum Backup Float'), value: 50000 },
          { label: t('Big Ledger Float'), value: 500000 },
        ];
      } else if (activeCurrency === 'KES') {
        return [
          { label: t('Standard Day Float'), value: 5000 },
          { label: t('Weekend Float'), value: 12000 },
          { label: t('Minimum Backup Float'), value: 2500 },
          { label: t('Big Ledger Float'), value: 25000 },
        ];
      } else {
        return [
          { label: t('Standard Day Float'), value: 100 },
          { label: t('Weekend Float'), value: 250 },
          { label: t('Minimum Backup Float'), value: 50 },
          { label: t('Big Ledger Float'), value: 500 },
        ];
      }
    };

    return (
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col">
          {/* Header */}
          <div className="px-5 py-4 border-b flex items-center justify-between bg-gray-900 text-white">
            <span className="font-bold flex items-center gap-2 text-sm">
              <AlertTriangle className="w-5 h-5 text-amber-500" /> {t('Register Drawer Closed')}
            </span>
            <button onClick={onClose} className="p-1 hover:bg-gray-800 rounded text-gray-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
          <div className="p-6 space-y-4">
            <p className="text-xs font-semibold text-gray-600">
              {t('To begin processing POS transactions, cashiers must declare their opening float and open a register session for reconciliation tracking.')}
            </p>
            
            {/* Store selector if multiple stores */}
            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase tracking-wider text-gray-400 block">{t('Select POS Depot / Store')}</label>
              <select
                value={selectedStoreId}
                onChange={(e) => setSelectedStoreId(e.target.value)}
                className="w-full px-3 py-2 border rounded-lg text-xs font-semibold outline-none bg-white"
              >
                {activeStores.map(s => (
                  <option key={s.id} value={s.id}>{s.name} - {s.location}</option>
                ))}
              </select>
            </div>

            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <label className="text-[10px] font-black uppercase tracking-wider text-gray-400 block">{t('Opening Float (Starting Drawer Cash)')}</label>
                <button
                  type="button"
                  onClick={() => { setShowDenomOpen(!showDenomOpen); setDenomCounts({}); }}
                  className="text-[10px] text-brand hover:underline font-bold flex items-center gap-1"
                >
                  <Calculator className="w-3 h-3" />
                  {showDenomOpen ? t('Hide Calculator') : t('Count Denominations')}
                </button>
              </div>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400">{activeCurrency}</span>
                <input
                  type="number"
                  value={openingFloatStr}
                  onChange={(e) => setOpeningFloatStr(e.target.value)}
                  className="w-full pl-12 pr-3 py-2 border rounded-lg text-xs font-black outline-none"
                  placeholder="e.g. 100"
                />
              </div>

              {/* Quick float presets */}
              <div className="mt-2 flex flex-wrap gap-1.5">
                {getFloatPresets().map((preset, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setOpeningFloatStr(String(preset.value));
                      setDenomCounts({});
                    }}
                    className="px-2 py-1 text-[10px] font-bold border border-gray-200 hover:border-brand/40 hover:bg-brand/5 text-gray-700 hover:text-brand rounded-lg transition-all"
                  >
                    ⚡ {preset.label}: {formatMoney(preset.value, activeCurrency, activeExchangeRate)}
                  </button>
                ))}
              </div>

              {showDenomOpen && (
                <div className="mt-2">
                  {renderPhysicalDenominationCalculator('open')}
                </div>
              )}
            </div>

            <div className="space-y-1">
              <label className="text-[10px] font-black uppercase tracking-wider text-gray-400 block">{t('Opening Notes / Description')}</label>
              <textarea
                value={openingNotes}
                onChange={(e) => setOpeningNotes(e.target.value)}
                className="w-full px-3 py-2 border rounded-lg text-xs font-semibold outline-none h-16 resize-none"
                placeholder={t('e.g. Morning Shift drawer opening float')}
              />
            </div>

            <div className="flex gap-2 pt-2">
              <button
                onClick={onClose}
                className="flex-1 py-2 border border-gray-300 hover:bg-gray-50 text-gray-700 font-bold rounded-lg text-xs transition"
              >
                {t('Cancel')}
              </button>
              <button
                onClick={handleOpenShift}
                className="flex-1 py-2 bg-brand hover:bg-brand-hover text-white font-bold rounded-lg text-xs transition shadow-sm"
              >
                {t('Open Register Session')}
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (completedOrder) {
    const cust = customers.find(c => c.id === completedOrder.customerId);
    const storeObj = stores.find(s => sameId(s.id, completedOrder.storeId));

    // Use store data directly (receipt branding from server)
    const companyName = storeObj?.name || 'Store';
    const companyBranch = storeObj?.location || '';
    const companyPhone = storeObj?.phone || '';
    const customLogo = localStorage.getItem('tradecore_receipt_custom_logo');

    return (
      <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-2xl w-full max-w-[320px] overflow-hidden flex flex-col max-h-[92vh]">
          {/* Success Title Header */}
          <div className="px-5 py-4 border-b flex items-center justify-between bg-emerald-600 text-white no-print">
            <span className="font-bold flex items-center gap-2 text-sm">
              <CheckCircle className="w-5 h-5 text-white animate-bounce" /> {t('Transaction Success')}
            </span>
            <button onClick={() => { setCompletedOrder(null); setCart([]); onClose(); }} className="p-1 hover:bg-emerald-700 rounded text-emerald-100 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Printable Receipt Body */}
          <div className="flex-1 overflow-y-auto p-6 bg-white font-mono text-xs text-gray-800 space-y-4 print-container">
            <div className="text-center space-y-1">
              {customLogo && (
                <div className="flex justify-center mb-2.5">
                  <img src={customLogo} alt="Logo" className="w-12 h-12 object-contain rounded-lg border border-gray-100 p-0.5" />
                </div>
              )}
              <h2 className="text-sm font-black uppercase tracking-wider text-gray-900">{companyName}</h2>
              <p className="text-[10px] text-gray-500">{companyBranch}</p>
              {companyPhone && <p className="text-[10px] text-gray-500">Tel: {companyPhone}</p>}
              <div className="border-b border-dashed border-gray-300 my-2"></div>
              <h3 className="text-[11px] font-bold uppercase tracking-widest text-gray-900">SALES RECEIPT</h3>
              <div className="border-b border-dashed border-gray-300 my-2"></div>
            </div>

            <div className="space-y-1 text-[10px]">
              <div className="flex justify-between">
                <span>BILL NO:</span>
                <span className="font-bold">{completedOrder.soNumber}</span>
              </div>
              <div className="flex justify-between">
                <span>STORE:</span>
                <span className="font-bold">{stores.find(s => sameId(s.id, completedOrder.storeId))?.name || 'Main Store'}</span>
              </div>
              <div className="flex justify-between">
                <span>DATE:</span>
                <span>{completedOrder.date}</span>
              </div>
              <div className="flex justify-between">
                <span>CUSTOMER:</span>
                <span className="uppercase">{cust?.name || 'Walk-in Customer'}</span>
              </div>
              <div className="flex justify-between">
                <span>PRICING TYPE:</span>
                <span className="font-bold uppercase text-red-600">{completedOrder.priceType}</span>
              </div>
            </div>

            <div className="border-b border-dashed border-gray-300 my-2"></div>

            {/* Receipt Items */}
            <table className="w-full text-left text-[11px] font-mono">
              <thead>
                <tr className="border-b border-dashed border-gray-300 text-gray-900 font-bold">
                  <th className="pb-1">ITEM</th>
                  <th className="pb-1 text-center">QTY</th>
                  <th className="pb-1 text-right">PRICE</th>
                  <th className="pb-1 text-right">TOTAL</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-dashed divide-gray-200">
                {(completedOrder.items || []).map((item, idx) => {
                  const product = stockItems.find(p => p.id === item.productId);
                  return (
                    <tr key={idx} className="text-gray-700">
                      <td className="py-1.5 max-w-[140px] truncate">{product?.name || `Product #${item.productId}`}</td>
                      <td className="py-1.5 text-center">{item.qty} {item.unitType === 'sub' ? (item.subUnitName || 'unit') : (product?.unit || 'Package')}</td>
                      <td className="py-1.5 text-right">{formatMoney(item.price, activeCurrency, activeExchangeRate)}</td>
                      <td className="py-1.5 text-right font-bold text-gray-900">{formatMoney(item.price * item.qty, activeCurrency, activeExchangeRate)}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            <div className="border-b border-dashed border-gray-300 my-2"></div>

            <div className="space-y-1.5 text-xs font-bold text-gray-900">
              <div className="flex justify-between">
                <span>SUBTOTAL</span>
                <span>{formatMoney(completedOrder.total, activeCurrency, activeExchangeRate)}</span>
              </div>
              <div className="flex justify-between text-sm font-black border-t border-dashed border-gray-300 pt-1.5">
                <span>TOTAL AMOUNT</span>
                <span className="text-brand">{formatMoney(completedOrder.total, activeCurrency, activeExchangeRate)}</span>
              </div>
            </div>

            <div className="border-b border-dashed border-gray-300 my-3"></div>

            <div className="text-center text-[10px] text-gray-500 space-y-1">
              <p className="font-bold uppercase tracking-wider text-gray-700">THANK YOU FOR YOUR PATRONAGE!</p>
              <p>Powered by TradeCore ERP</p>
              <p className="text-[8px] mt-2">Reprint Secure • Digital Audit Logged</p>
            </div>
          </div>

          {/* Digital Invoice / WhatsApp Receipt Panel */}
          <div className="p-4 border-t bg-gray-50/50 space-y-3 no-print text-xs">
            <span className="text-[10px] font-bold text-gray-400 block tracking-wider uppercase">{t('Digital Dispatch / Tuma Kidijitali')}</span>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => {
                  setShowWhatsAppInput(!showWhatsAppInput);
                  setShowEmailInput(false);
                }}
                className={`py-1.5 px-3 ${showWhatsAppInput ? 'bg-[#128C7E]' : 'bg-[#25D366]'} hover:bg-[#128C7E] text-white font-bold rounded-lg text-[11px] uppercase tracking-wide flex items-center justify-center gap-1.5 shadow-xs transition`}
              >
                <Share2 className="w-3.5 h-3.5" /> WhatsApp
              </button>
              <button
                onClick={() => {
                  setShowEmailInput(!showEmailInput);
                  setShowWhatsAppInput(false);
                }}
                className={`py-1.5 px-3 ${showEmailInput ? 'bg-indigo-700' : 'bg-indigo-600'} hover:bg-indigo-700 text-white font-bold rounded-lg text-[11px] uppercase tracking-wide flex items-center justify-center gap-1.5 shadow-xs transition`}
              >
                <Mail className="w-3.5 h-3.5" /> Email Invoice
              </button>
            </div>
            
            {showWhatsAppInput && (
              <div className="p-2.5 bg-white border rounded-lg space-y-2 animate-fade-in">
                <label className="text-[10px] font-bold text-gray-500 block">{t('WhatsApp Number / Namba ya WhatsApp')}:</label>
                <div className="flex gap-1.5">
                  <input
                    type="text"
                    value={whatsappPhone}
                    onChange={(e) => setWhatsappPhone(e.target.value)}
                    placeholder="e.g. 255712345678"
                    className="flex-1 px-2.5 py-1 border rounded-md text-xs font-semibold outline-none bg-white text-gray-800"
                  />
                  <button
                    onClick={submitWhatsAppShare}
                    className="px-3 py-1 bg-[#25D366] text-white font-bold rounded-md text-xs hover:bg-[#128C7E] transition shrink-0"
                  >
                    {t('Send')}
                  </button>
                </div>
              </div>
            )}

            {showEmailInput && (
              <div className="p-2.5 bg-white border rounded-lg space-y-2 animate-fade-in">
                <label className="text-[10px] font-bold text-gray-500 block">{t('Customer Email / Barua Pepe ya Mteja')}:</label>
                <div className="flex gap-1.5">
                  <input
                    type="email"
                    value={customerEmail}
                    onChange={(e) => setCustomerEmail(e.target.value)}
                    placeholder="customer@example.com"
                    className="flex-1 px-2.5 py-1 border rounded-md text-xs font-semibold outline-none bg-white text-gray-800"
                  />
                  <button
                    onClick={submitEmailInvoice}
                    className="px-3 py-1 bg-indigo-600 text-white font-bold rounded-md text-xs hover:bg-indigo-700 transition shrink-0"
                  >
                    {t('Send')}
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="p-4 bg-gray-50 border-t flex flex-wrap gap-2 no-print">
            <button
              onClick={async () => {
                try {
                  if (!isBluetoothPrinterConnected()) {
                    await connectBluetoothPrinter();
                  }
                  const storeObj = stores.find(s => sameId(s.id, completedOrder.storeId)) || { name: 'Store' };
                  const custObj = customers.find(c => c.id === completedOrder.customerId) || { name: 'Walk-in' };
                  const buffer = buildReceiptEscPosBuffer(completedOrder, storeObj, custObj, activeCurrency || '$');
                  await sendEscPosBytes(buffer);
                  toast.success('Receipt sent directly to Bluetooth ESC/POS printer!');
                } catch (err: any) {
                  toast.error(err.message || 'Bluetooth printer error. Falling back to browser print.');
                  handlePrintWithFallback((title, desc) => {
                    setConfirmModal({
                      isOpen: true,
                      title: t(title),
                      description: t(desc),
                      onConfirm: () => {}
                    });
                  });
                }
              }}
              className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-sm"
            >
              <Printer className="w-4 h-4" /> Direct Thermal ESC/POS
            </button>

            <button
              onClick={() => {
                handlePrintWithFallback((title, desc) => {
                  setConfirmModal({
                    isOpen: true,
                    title: t(title),
                    description: t(desc),
                    onConfirm: () => {}
                  });
                });
              }}
              className="flex-1 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs uppercase tracking-wider flex items-center justify-center gap-1.5"
            >
              <Printer className="w-4 h-4" /> {t('Browser Print')}
            </button>
            <button
              onClick={() => { setCompletedOrder(null); setCart([]); onClose(); }}
              className="flex-1 py-2 bg-gray-900 hover:bg-gray-800 text-white font-bold rounded-lg text-xs uppercase tracking-wider"
            >
              {t('Done / New Sale')}
            </button>
          </div>
        </div>
        
        <ConfirmActionModal
          isOpen={confirmModal.isOpen}
          onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
          onConfirm={confirmModal.onConfirm}
          title={confirmModal.title}
          description={confirmModal.description}
          confirmText={t('Got it')}
          cancelText={t('Close')}
        />
      </div>
    );
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-0 md:p-4">
      <div className="bg-white rounded-none md:rounded-2xl shadow-2xl w-full max-w-6xl h-full md:h-[92vh] max-h-screen md:max-h-[92vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b flex items-center justify-between bg-gray-900 text-white flex-shrink-0">
          <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4">
            <span className="font-bold flex items-center gap-2 text-sm">
              <ShoppingBag className="w-5 h-5 text-brand" /> POS Terminal - Active Checkout
            </span>
            {activeShift && (
              <span className="text-[10px] bg-brand/20 border border-brand/50 text-brand px-2 py-0.5 rounded-full font-black uppercase tracking-wider">
                Shift: {activeShift.username} | Float: {formatMoney(activeShift.openingFloat, activeCurrency, activeExchangeRate)} | Drawer: {formatMoney(activeShift.openingFloat + (activeShift.expectedCashSales || 0) - autoDrawerExpensesTotal, activeCurrency, activeExchangeRate)}
                {autoDrawerExpensesTotal > 0 && (
                  <span className="text-rose-300 ml-1 font-semibold" title={t(`Auto-linked from ${linkedShiftExpenses.length} expense(s)`)}>
                    (-{formatMoney(autoDrawerExpensesTotal, activeCurrency, activeExchangeRate)})
                  </span>
                )}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 sm:gap-3">
            {activeShift && isCompanyAdmin && (
              <button
                onClick={() => {
                  setClosingCashActualStr(String(activeShift.openingFloat + (activeShift.expectedCashSales || 0) - autoDrawerExpensesTotal));
                  setClosingNotes('');
                  setShowClosingModal(true);
                }}
                className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-lg text-xs font-black uppercase tracking-wider transition cursor-pointer"
              >
                {t('Close Drawer / Shift')}
              </button>
            )}
            <button
              type="button"
              onClick={() => window.dispatchEvent(new CustomEvent('tradecore:open_calculator'))}
              className="bg-indigo-600 hover:bg-indigo-700 text-white px-2.5 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 shadow-sm"
              title="Open Scientific & Retail Calculator (Ctrl+Alt+C)"
            >
              <Calculator className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{t('Calculator')}</span>
            </button>
            <button onClick={onClose} className="p-1 hover:bg-gray-800 rounded text-gray-400 hover:text-white">
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Mobile Tab Swapper */}
        <div className="flex border-b md:hidden bg-gray-50 flex-shrink-0">
          <button
            onClick={() => setActiveTab('catalog')}
            className={`flex-1 py-3 text-center text-xs font-bold border-b-2 transition-all ${
              activeTab === 'catalog' ? 'border-brand text-brand bg-white' : 'border-transparent text-gray-500'
            }`}
          >
            {t('Catalog')}
          </button>
          <button
            onClick={() => setActiveTab('cart')}
            className={`flex-1 py-3 text-center text-xs font-bold border-b-2 transition-all flex items-center justify-center gap-1.5 ${
              activeTab === 'cart' ? 'border-brand text-brand bg-white' : 'border-transparent text-gray-500'
            }`}
          >
            {t('Cart & Checkout')}
            {cart.length > 0 && (
              <span className="bg-brand text-white text-[10px] font-black px-2 py-0.5 rounded-full">
                {cart.reduce((sum, item) => sum + item.qty, 0)}
              </span>
            )}
          </button>
        </div>

        {/* Content Container Split Screen */}
        <div className="flex-1 overflow-hidden flex flex-col md:flex-row">
          
          {/* Left Panel: Catalog / Products Selector */}
          <div className={`flex-1 overflow-hidden flex flex-col p-5 border-r ${activeTab !== 'catalog' ? 'hidden md:flex' : 'flex'}`}>
            {/* Catalog search/filters header */}
            <div className="space-y-3 mb-4 flex-shrink-0">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-gray-50 p-3 rounded-xl border border-gray-100">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                  <input
                    type="text"
                    placeholder={t('Search products by name, category, or code...')}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter' && searchQuery.trim()) {
                        const q = searchQuery.trim().toLowerCase();
                        const exactMatch = stockItems.find(
                          p => safeLower(p.code) === q || safeLower(p.name) === q
                        );
                        if (exactMatch) {
                          const stockQty = getStockQty(exactMatch, selectedStoreId);
                          if (stockQty > 0 || allowNegativeStock) {
                            handleAddToCart(exactMatch);
                            setSearchQuery('');
                            const appliedPrice = getProductPrice(exactMatch, 'main');
                            const tierLabel = priceType === 'Wholesale' ? t('Wholesale') : priceType === 'Preferred' ? t('Preferred') : t('Retail');
                            const custNote = selectedCustomer ? ` (${selectedCustomer.name} - ${tierLabel})` : ` (${tierLabel})`;
                            toast.success(`⚡ [${exactMatch.code}] ${exactMatch.name} - ${formatMoney(appliedPrice, activeCurrency, activeExchangeRate)}${custNote}`);
                          } else {
                            setErrorMsg(`${exactMatch.name} is out of stock!`);
                          }
                        }
                      }
                    }}
                    className="w-full pl-9 pr-3 py-1.5 bg-white border border-gray-300 rounded-lg text-xs font-semibold outline-none focus:ring-2 focus:ring-brand/20 focus:border-brand"
                  />
                </div>

                <button
                  type="button"
                  onClick={() => handleOpenBarcodeStudio()}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white border border-gray-300 hover:border-brand hover:text-brand rounded-lg text-xs font-bold text-gray-700 transition shadow-2xs shrink-0 cursor-pointer"
                  title={t('Generate Barcode & Shelf Price Tags for Retailer, Wholesaler & Preferred Customers')}
                >
                  <Barcode className="w-3.5 h-3.5 text-brand" />
                  <span>{t('Barcode Studio')}</span>
                </button>
                
                <div className="flex flex-wrap items-center gap-3">
                  <div className="flex items-center gap-2 max-w-full overflow-x-auto whitespace-nowrap scrollbar-none py-1">
                    <span className="text-[10px] font-bold text-gray-400 uppercase shrink-0">{t('Store Depot')}:</span>
                    <div className="flex items-center gap-1.5 overflow-x-auto whitespace-nowrap scrollbar-none max-w-full">
                      {activeStores.map(st => (
                        <button
                          key={st.id}
                          type="button"
                          onClick={() => {
                            if (!sameId(selectedStoreId, st.id)) {
                              setSelectedStoreId(st.id);
                              setCart([]);
                            }
                          }}
                          className={`px-2.5 py-1 rounded-md text-[11px] font-bold transition shrink-0 border ${
                            sameId(selectedStoreId, st.id)
                              ? 'bg-brand text-white border-brand shadow-xs'
                              : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'
                          }`}
                        >
                          🏪 {st.name}
                        </button>
                      ))}
                    </div>
                  </div>

                  {isAdminUser ? (
                    <div className="flex items-center gap-1.5 border-l pl-3 border-gray-200">
                      <input
                        type="checkbox"
                        id="allowNegativeStock"
                        checked={allowNegativeStock}
                        onChange={(e) => {
                          const val = e.target.checked;
                          setAllowNegativeStock(val);
                          if (saveAllData && settings) {
                            saveAllData({ settings: { ...settings, allowNegativeStock: val } });
                          }
                        }}
                        className="rounded text-brand focus:ring-brand w-3.5 h-3.5 cursor-pointer accent-emerald-600"
                      />
                      <label htmlFor="allowNegativeStock" className="text-[10px] font-black text-gray-500 uppercase cursor-pointer select-none flex items-center gap-1">
                        ⚠️ {t('Allow Negative Stock')}
                      </label>
                    </div>
                  ) : (
                    allowNegativeStock && (
                      <div className="flex items-center gap-1 border-l pl-3 border-gray-200">
                        <span className="text-[10px] font-black text-amber-600 uppercase flex items-center gap-1">
                          ⚠️ {t('Negative Stock Allowed')}
                        </span>
                      </div>
                    )
                  )}
                </div>
              </div>

              {errorMsg && (
                <div className="bg-red-50 text-red-700 px-3 py-2 rounded-lg text-[11px] font-bold flex items-center gap-1.5 border border-red-100">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>{errorMsg}</span>
                </div>
              )}
            </div>

            {/* Catalog Items Grid */}
            <div className="flex-1 overflow-y-auto pr-1 scrollbar-thin">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3.5 pb-4">
                {paginatedCatalogProducts.map(item => {
                  const stockQty = getStockQty(item, selectedStoreId);
                  const currentPrice = getProductPrice(item);
                  const isOutOfStock = stockQty <= 0;

                  const isBlocked = isOutOfStock && !allowNegativeStock;

                  return (
                    <div
                      key={item.id}
                      onClick={() => !isBlocked && handleAddToCart(item)}
                      className={`group border border-gray-200/80 hover:border-brand rounded-xl overflow-hidden cursor-pointer transition-all duration-150 flex flex-col justify-between bg-white ${
                        isOutOfStock 
                          ? isBlocked 
                            ? 'opacity-55 cursor-not-allowed bg-gray-50' 
                            : 'opacity-85 hover:shadow-xs border-amber-200 bg-amber-50/5'
                          : 'hover:shadow-sm'
                      }`}
                    >
                      <div className="p-3">
                        <div className="h-28 bg-gray-50 rounded-lg overflow-hidden border border-gray-100 flex items-center justify-center relative">
                          {item.batches?.[selectedStoreId as number]?.some(b => b.qty > 0) && (
                            <span className="absolute top-2 left-2 text-[9px] px-1.5 py-0.5 rounded font-extrabold uppercase bg-purple-600 text-white flex items-center gap-1 shadow-2xs z-10" title={t('Uses FEFO / FIFO Batch Stocking')}>
                              <Layers className="w-2.5 h-2.5" />
                              FEFO ({item.batches[selectedStoreId as number].filter(b => b.qty > 0).length})
                            </span>
                          )}
                          {item.imageUrl ? (
                            <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover group-hover:scale-105 transition duration-300" referrerPolicy="no-referrer" />
                          ) : (
                            <span className="text-2xl font-black text-gray-200">ERP</span>
                          )}
                          <span className={`absolute top-2 right-2 text-[9px] px-1.5 py-0.5 rounded font-black uppercase ${
                            isOutOfStock 
                              ? isBlocked ? 'bg-red-600 text-white' : 'bg-amber-600 text-white'
                              : 'bg-gray-900 text-white'
                          }`}>
                            {isOutOfStock 
                              ? isBlocked ? t('Out of Stock') : `${t('Out of Stock')} (⚠️ ${t('Allowed')})`
                              : `${formatStockQty(stockQty, item)} ${t('available')}`}
                          </span>
                        </div>

                        <div className="mt-3.5">
                          <span className="text-[10px] bg-indigo-50 text-indigo-700 font-extrabold px-1.5 py-0.5 rounded uppercase">{cleanCategoryName(item.category)}</span>
                          <h4 className="font-black text-gray-900 text-xs mt-1 block truncate">{item.name}</h4>
                          <div className="flex items-center justify-between gap-1 mt-0.5">
                            <span className="text-[9px] font-mono text-gray-400 block tracking-widest truncate">SKU: {item.code}</span>
                            {(() => {
                              const storeBatches = item.batches?.[selectedStoreId as number] || [];
                              const expiries = storeBatches
                                .filter(b => b.qty > 0 && b.expiryDate)
                                .map(b => b.expiryDate as string);
                              const directExp = item.expiryDates?.[selectedStoreId as number] || item.expiryDate;
                              if (directExp) expiries.push(directExp);
                              if (expiries.length === 0) return null;
                              expiries.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
                              const earliest = expiries[0];
                              const days = getDaysUntilExpiry(earliest);
                              const status = getExpiryStatus(earliest);

                              if (status === 'expired') {
                                return (
                                  <span className="text-[9px] font-mono font-black text-rose-700 bg-rose-50 border border-rose-200 px-1 rounded shrink-0">
                                    EXPIRED
                                  </span>
                                );
                              }
                              if (status === 'urgent') {
                                return (
                                  <span className="text-[9px] font-mono font-bold text-red-600 bg-red-50 border border-red-200 px-1 rounded shrink-0" title={t('Critical: 7 days or less')}>
                                    FEFO: {days}d left
                                  </span>
                                );
                              }
                              if (status === 'warning') {
                                return (
                                  <span className="text-[9px] font-mono font-bold text-amber-700 bg-amber-50 border border-amber-200 px-1 rounded shrink-0" title={t('Early warning: 30 days or less')}>
                                    FEFO: {days}d left
                                  </span>
                                );
                              }
                              return null;
                            })()}
                          </div>
                        </div>
                      </div>

                      <div className="p-3 border-t bg-gray-50/50 flex items-center justify-between">
                        <span className="text-[13px] font-black text-brand">
                          {formatMoney(currentPrice, activeCurrency, activeExchangeRate)}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleOpenBarcodeStudio(item);
                            }}
                            className="p-1 rounded text-gray-400 hover:text-gray-800 hover:bg-gray-200 transition-colors cursor-pointer"
                            title={t('Print Barcode & Shelf Price Tag')}
                          >
                            <Barcode className="w-3.5 h-3.5" />
                          </button>
                          <button
                            disabled={isBlocked}
                            className={`${isBlocked ? 'bg-gray-300' : 'bg-brand group-hover:bg-brand-hover'} text-white p-1 rounded transition-colors`}
                          >
                            <Plus className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                })}

                {filteredProducts.length === 0 && (
                  <div className="col-span-full py-16 text-center text-gray-400 font-bold text-xs">
                    {t('No registered catalog item match the filters')}
                  </div>
                )}
              </div>

              {filteredProducts.length > POS_PAGE_SIZE && (
                <div className="py-2.5 px-3 flex items-center justify-between border-t border-gray-200 bg-gray-50/80 rounded-xl mb-4">
                  <span className="text-[11px] font-semibold text-gray-500">
                    {t('Showing')} <span className="font-bold text-gray-800">{(currentCatalogPage - 1) * POS_PAGE_SIZE + 1}</span> - <span className="font-bold text-gray-800">{Math.min(currentCatalogPage * POS_PAGE_SIZE, filteredProducts.length)}</span> {t('of')} <span className="font-bold text-gray-800">{filteredProducts.length}</span> {t('items')}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      disabled={currentCatalogPage <= 1}
                      onClick={() => setCatalogPage(prev => Math.max(1, prev - 1))}
                      className="px-2.5 py-1 text-xs font-bold rounded-lg border border-gray-300 bg-white text-gray-700 hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed transition"
                    >
                      {t('Previous')}
                    </button>
                    <span className="text-xs font-bold text-gray-700 px-1.5">
                      {currentCatalogPage} / {totalCatalogPages}
                    </span>
                    <button
                      type="button"
                      disabled={currentCatalogPage >= totalCatalogPages}
                      onClick={() => setCatalogPage(prev => Math.min(totalCatalogPages, prev + 1))}
                      className="px-2.5 py-1 text-xs font-bold rounded-lg border border-gray-300 bg-white text-gray-700 hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed transition"
                    >
                      {t('Next')}
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Mobile Floating Cart Quick Access Bar */}
            <div className="md:hidden mt-auto pt-2 bg-white border-t border-gray-200 -mx-5 -mb-5 p-3 flex items-center justify-between shrink-0 shadow-md">
              <div className="flex items-center gap-2.5">
                <div className="relative bg-brand p-2 rounded-xl text-white shrink-0">
                  <ShoppingBag className="w-5 h-5" />
                  {cart.length > 0 && (
                    <span className="absolute -top-1.5 -right-1.5 bg-red-600 text-white text-[9px] font-black w-4.5 h-4.5 rounded-full flex items-center justify-center border-2 border-white shadow-xs">
                      {cart.reduce((s, i) => s + i.qty, 0)}
                    </span>
                  )}
                </div>
                <div>
                  <span className="text-[10px] text-gray-400 font-extrabold uppercase tracking-wider block">
                    {cart.length === 0 ? t('Cart Empty') : `${cart.length} ${t('Products')} (${cart.reduce((s, i) => s + i.qty, 0)} ${t('units')})`}
                  </span>
                  <span className="text-xs font-black text-gray-900 block">
                    {formatMoney(totals.total, activeCurrency, activeExchangeRate)}
                  </span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setActiveTab('cart')}
                className="bg-brand hover:bg-brand-hover text-white text-xs font-black px-3.5 py-2 rounded-xl uppercase tracking-wider flex items-center gap-1.5 shadow-sm active:scale-95 transition"
              >
                {t('View Cart')} &rarr;
              </button>
            </div>
          </div>

          {/* Right Panel: Shopping Cart Details & Invoice Summary */}
          <div className={`w-full md:w-96 flex-grow flex-1 flex flex-col p-4 md:p-5 bg-gray-50 flex-shrink-0 border-t md:border-t-0 border-gray-200 max-h-full overflow-hidden ${activeTab !== 'cart' ? 'flex md:flex' : 'flex'}`}>
            <div className="flex-shrink-0 space-y-3.5 mb-3">
              <div className="flex justify-between items-center">
                <span className="font-bold text-gray-900 text-xs uppercase tracking-wider">{t('Cart Summary')}</span>
                <div className="flex items-center gap-3">
                  {cart.length > 0 && (
                    <button
                      onClick={handleSuspendCart}
                      className="text-[10px] text-amber-600 hover:text-amber-700 font-black flex items-center gap-1 uppercase tracking-wider"
                      title={t('Hold current cart to serve another customer')}
                    >
                      ⏸️ {t('Hold')}
                    </button>
                  )}
                  <button
                    onClick={() => {
                      setCart([]);
                      setOrderNote('');
                    }}
                    className="text-[10px] text-gray-400 hover:text-red-600 font-bold uppercase tracking-wider"
                  >
                    {t('Clear')}
                  </button>
                </div>
              </div>

              {/* Client and pricing selectors */}
              <div className="space-y-2 bg-white p-3.5 rounded-xl border border-gray-200/75">
                <div className="space-y-1">
                  <label className="text-[9px] font-black text-gray-400 uppercase tracking-wider block">{t('Client Client')}</label>
                  <select
                    value={selectedCustomerId != null && !Number.isNaN(selectedCustomerId as any) ? selectedCustomerId : ''}
                    onChange={(e) => {
                      const val = e.target.value;
                      setSelectedCustomerId(/^\d+$/.test(val) ? Number(val) : (val as any));
                    }}
                    className="w-full px-2 py-1.5 border rounded-md text-xs font-semibold outline-none bg-white text-gray-800"
                  >
                    {activeCustomersForStore.map(c => (
                      <option key={c.id} value={c.id}>{c.name} ({t(c.type)})</option>
                    ))}
                  </select>
                </div>

                <div className="flex justify-between items-center pt-2 border-t">
                  <span className="text-[10px] font-bold text-gray-400 uppercase">{t('Billing Mode')}:</span>
                  <div className="flex bg-gray-100 p-0.5 rounded-md">
                    <button
                      type="button"
                      onClick={() => handlePriceTypeChange('Retail')}
                      className={`px-2 py-1 rounded text-[9px] font-black uppercase transition-all ${
                        priceType === 'Retail' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500 hover:text-gray-900'
                      }`}
                    >
                      Retail
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePriceTypeChange('Wholesale')}
                      className={`px-2 py-1 rounded text-[9px] font-black uppercase transition-all ${
                        priceType === 'Wholesale' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500 hover:text-gray-900'
                      }`}
                    >
                      Wholesale
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePriceTypeChange('Preferred')}
                      className={`px-2 py-1 rounded text-[9px] font-black uppercase transition-all ${
                        priceType === 'Preferred' ? 'bg-white text-gray-900 shadow-xs' : 'text-gray-500 hover:text-gray-900'
                      }`}
                    >
                      Preferred
                    </button>
                  </div>
                </div>

                {selectedCustomer && priceType === 'Wholesale' && (
                  <div className="pt-2 border-t text-[10px] space-y-0.5 font-bold">
                    <div className="flex justify-between">
                      <span className="text-gray-400">CREDIT LIMIT:</span>
                      <span className="text-gray-900">{formatMoney(selectedCustomer.creditLimit, activeCurrency, activeExchangeRate)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-400">CURRENT BAL:</span>
                      <span className="text-amber-600">{formatMoney(selectedCustomer.balance, activeCurrency, activeExchangeRate)}</span>
                    </div>
                    {isCreditExceeded && (
                      <div className="bg-red-50 text-red-700 p-1.5 rounded mt-1.5 border border-red-100 text-[9px] font-black uppercase tracking-wider flex items-center gap-1">
                        <AlertTriangle className="w-3 h-3 shrink-0" />
                        <span>Credit Limit Exceeded!</span>
                      </div>
                    )}
                  </div>
                )}
              </div>
            </div>

            {/* Middle Scrollable Section: Suspended Carts + Cart Items + Payment/Notes Options */}
            <div className={`flex-grow flex-1 overflow-y-auto min-h-0 pr-1 scrollbar-thin space-y-3 flex flex-col ${cart.length === 0 ? 'flex-1 justify-center' : 'flex-1'}`}>
              {/* Suspended Carts Panel */}
              {suspendedCarts.length > 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-[10px] font-black text-amber-800 uppercase tracking-wider flex items-center gap-1.5">
                      ⏳ {t('Held Carts / Suspended')} ({suspendedCarts.length})
                    </span>
                  </div>
                  <div className="space-y-1.5 max-h-32 overflow-y-auto pr-0.5 scrollbar-thin">
                    {suspendedCarts.map(sc => {
                      const custObj = customers.find(c => c.id === sc.customerId);
                      return (
                        <div key={sc.id} className="bg-white border border-amber-100 rounded-lg p-2 flex items-center justify-between text-[11px] hover:shadow-xs transition">
                          <div className="min-w-0 flex-1">
                            <span className="font-extrabold text-gray-800 block truncate">
                              {custObj?.name || t('Guest')} - {sc.note}
                            </span>
                            <span className="text-[9px] text-gray-400 font-mono">
                              {sc.timestamp} | {sc.cart.reduce((sum, item) => sum + item.qty, 0)} {t('items')} ({t(sc.priceType)})
                            </span>
                          </div>
                          <div className="flex items-center gap-1.5 ml-2 shrink-0">
                            {pendingResumeCartId === sc.id && cart.length > 0 ? (
                              <>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setCart(sc.cart);
                                    setSelectedCustomerId(sc.customerId);
                                    setPriceType(sc.priceType);
                                    setSuspendedCarts(suspendedCarts.filter(c => c.id !== sc.id));
                                    setPendingResumeCartId(null);
                                    toast.success(t('Held cart replaced active cart'));
                                  }}
                                  className="bg-red-600 hover:bg-red-700 text-white px-2 py-0.5 rounded text-[9px] font-bold uppercase transition"
                                >
                                  {t('Replace')}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    const merged = [...cart];
                                    sc.cart.forEach((scItem: any) => {
                                      const match = merged.find((c: any) => c.productId === scItem.productId && (c as any).unitType === scItem.unitType);
                                      if (match) {
                                        match.qty += scItem.qty;
                                      } else {
                                        merged.push(scItem);
                                      }
                                    });
                                    setCart(merged);
                                    setSelectedCustomerId(sc.customerId);
                                    setPriceType(sc.priceType);
                                    setSuspendedCarts(suspendedCarts.filter(c => c.id !== sc.id));
                                    setPendingResumeCartId(null);
                                    toast.success(t('Held cart merged into active cart'));
                                  }}
                                  className="bg-amber-600 hover:bg-amber-700 text-white px-2 py-0.5 rounded text-[9px] font-bold uppercase transition"
                                >
                                  {t('Merge')}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setPendingResumeCartId(null)}
                                  className="text-gray-400 hover:text-gray-600 px-1 text-[9px] font-bold"
                                >
                                  {t('Cancel')}
                                </button>
                              </>
                            ) : (
                              <>
                                <button
                                  type="button"
                                  onClick={() => {
                                    if (cart.length > 0) {
                                      setPendingResumeCartId(sc.id);
                                      return;
                                    }
                                    setCart(sc.cart);
                                    setSelectedCustomerId(sc.customerId);
                                    setPriceType(sc.priceType);
                                    setSuspendedCarts(suspendedCarts.filter(c => c.id !== sc.id));
                                    toast.success(t('Held cart retrieved successfully'));
                                  }}
                                  className="bg-amber-600 hover:bg-amber-700 text-white px-2 py-0.5 rounded text-[9px] font-bold uppercase transition"
                                >
                                  {t('Resume')}
                                </button>
                                <button
                                  type="button"
                                  onClick={() => {
                                    setSuspendedCarts(suspendedCarts.filter(c => c.id !== sc.id));
                                    if (pendingResumeCartId === sc.id) setPendingResumeCartId(null);
                                    toast.success(t('Draft cleared'));
                                  }}
                                  className="text-gray-400 hover:text-red-600"
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                </button>
                              </>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Cart Items List */}
              <div className={`space-y-2 flex-grow flex-col ${cart.length === 0 ? 'flex-1 flex justify-center' : 'flex-1 flex'} min-h-[180px]`}>
                {cart.map(c => {
                  const product = stockItems.find(p => p.id === c.productId);
                  if (!product) return null;

                  const currentUnitType = c.unitType || 'main';

                  return (
                    <div
                      key={`${c.productId}-${currentUnitType}`}
                      className="bg-white rounded-xl border border-gray-200/85 p-3 flex items-center justify-between gap-2 shadow-xs"
                    >
                      <div className="min-w-0 flex-1">
                        <span className="font-black text-gray-900 text-xs block truncate">{product.name}</span>
                        <div className="flex flex-wrap items-center gap-1.5 mt-0.5">
                          <span className="text-[10px] text-brand font-bold">
                            {formatMoney(c.price, activeCurrency, activeExchangeRate)} / {currentUnitType === 'sub' ? product.subUnitName : (product.unit || 'unit')}
                          </span>
                          {product.useSubUnitPricing && (
                            <select
                              value={currentUnitType}
                              onChange={(e) => handleToggleCartUnit(c.productId, e.target.value as 'main' | 'sub')}
                              className="px-1 py-0.5 text-[9px] border border-gray-300 rounded bg-white font-bold text-gray-700 outline-none cursor-pointer"
                            >
                              <option value="main">{product.unit || 'Main Unit'}</option>
                              <option value="sub">{product.subUnitName || 'Sub-Unit'}</option>
                            </select>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleUpdateQty(c.productId, currentUnitType, Math.max(0, parseFloat((c.qty - 1).toFixed(4))))}
                          className="w-5 h-5 bg-gray-100 hover:bg-gray-200 rounded flex items-center justify-center font-bold text-gray-600 animate-none"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <input
                          type="number"
                          step="any"
                          min="0"
                          value={typeof c.qty === 'number' && !Number.isNaN(c.qty) ? c.qty : 0}
                          onChange={(e) => handleUpdateQty(c.productId, currentUnitType, parseFloat(e.target.value) || 0)}
                          className="w-12 px-1 py-0.5 text-xs font-bold text-center border rounded bg-gray-50 text-gray-900 focus:outline-none focus:ring-1 focus:ring-brand"
                        />
                        <button
                          onClick={() => handleUpdateQty(c.productId, currentUnitType, parseFloat((c.qty + 1).toFixed(4)))}
                          className="w-5 h-5 bg-gray-100 hover:bg-gray-200 rounded flex items-center justify-center font-bold text-gray-600 animate-none"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <button
                        onClick={() => handleRemoveItem(c.productId, currentUnitType)}
                        className="text-gray-400 hover:text-brand"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  );
                })}

                {cart.length === 0 && (
                  <div className="flex-grow flex-1 flex flex-col items-center justify-center min-h-[220px] max-h-[550px] overflow-y-auto py-4 px-3 text-center space-y-3 bg-white border border-dashed border-gray-300 rounded-2xl my-2 shadow-2xs">
                    <div className="w-12 h-12 rounded-full bg-brand/10 flex items-center justify-center shrink-0">
                      <ShoppingBag className="w-6 h-6 text-brand animate-pulse" />
                    </div>
                    <div>
                      <p className="text-xs font-black text-gray-900 uppercase tracking-wider">{t('Active Cart is Empty')}</p>
                      <p className="text-[10px] text-gray-500 font-medium max-w-[240px] leading-relaxed mt-0.5">
                        {t('Tap items in the catalog to add products. Essential store & shift details are shown below.')}
                      </p>
                    </div>

                    {/* Shift & Store Real-time Performance Metrics */}
                    <div className="w-full pt-2.5 border-t border-gray-100 text-left text-[11px] space-y-1.5 text-gray-600">
                      <div className="flex justify-between items-center bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-200/60">
                        <span className="font-bold text-gray-400 uppercase tracking-wider text-[8px]">{t('Active Store')}</span>
                        <span className="font-extrabold text-gray-800 truncate max-w-[150px]">{stores.find(s => sameId(s.id, selectedStoreId))?.name || t('Not Assigned')}</span>
                      </div>
                      <div className="flex justify-between items-center bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-200/60">
                        <span className="font-bold text-gray-400 uppercase tracking-wider text-[8px]">{t('Shift Operator')}</span>
                        <span className="font-extrabold text-gray-800 truncate max-w-[150px]">{currentUser?.name || t('Guest')} ({t(currentUser?.role || '')})</span>
                      </div>
                      <div className="flex justify-between items-center bg-emerald-50/70 px-2.5 py-1.5 rounded-lg border border-emerald-200/60">
                        <span className="font-extrabold text-emerald-800 uppercase tracking-wider text-[8px]">{t('Shift Sales Count')}</span>
                        <span className="font-black text-emerald-700 bg-emerald-100 px-1.5 py-0.5 rounded text-[10px]">
                          {shiftOrders.length} {t('sales')} ({shiftProductsSoldVolume} {t('items')})
                        </span>
                      </div>
                      <div className="flex justify-between items-center bg-emerald-50/70 px-2.5 py-1.5 rounded-lg border border-emerald-200/60">
                        <span className="font-extrabold text-emerald-800 uppercase tracking-wider text-[8px]">{t('Shift Total Revenue')}</span>
                        <span className="font-black text-emerald-700 text-[11px]">
                          {formatMoney(shiftTotalRevenue, activeCurrency, activeExchangeRate)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-200/60">
                        <span className="font-bold text-gray-400 uppercase tracking-wider text-[8px]">{t('Billing Mode')}</span>
                        <span className="font-extrabold text-amber-600 bg-amber-50 px-1.5 py-0.5 rounded border border-amber-100 text-[10px]">{t(priceType)}</span>
                      </div>
                      <div className="flex justify-between items-center bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-200/60">
                        <span className="font-bold text-gray-400 uppercase tracking-wider text-[8px]">{t('Selected Client')}</span>
                        <span className="font-extrabold text-gray-800 truncate max-w-[150px]">{customers.find(c => c.id === selectedCustomerId)?.name || t('Guest')}</span>
                      </div>
                      <div className="flex justify-between items-center bg-gray-50 px-2.5 py-1.5 rounded-lg border border-gray-200/60">
                        <span className="font-bold text-gray-400 uppercase tracking-wider text-[8px]">{t('Store Catalog Items')}</span>
                        <span className="font-black text-gray-700">{stockItems.length} {t('products registered')}</span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Payment & Adjustments Panel */}
              {cart.length > 0 && (
                <div className="border-t pt-3 space-y-3 no-print">
                  <div className="bg-white rounded-xl border border-gray-200 p-3 space-y-2 shadow-2xs">
                    <span className="text-[10px] font-extrabold text-brand uppercase tracking-wider block">
                      ⚡ {t('Discounts & Transaction Notes')}
                    </span>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-gray-400 uppercase">{t('Discount Type')}</label>
                        <select
                          value={orderDiscountType}
                          onChange={(e) => setOrderDiscountType(e.target.value as 'Flat' | 'Percentage')}
                          className="w-full px-2 py-1 border border-gray-300 rounded text-xs bg-white font-semibold outline-none"
                        >
                          <option value="Flat">{t('Flat')}</option>
                          <option value="Percentage">{t('Percentage (%)')}</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-gray-400 uppercase">{t('Discount Value')}</label>
                        <input
                          type="number"
                          min="0"
                          value={typeof orderDiscountValue === 'number' && !Number.isNaN(orderDiscountValue) ? orderDiscountValue : 0}
                          onChange={(e) => setOrderDiscountValue(parseFloat(e.target.value) || 0)}
                          className="w-full px-2 py-1 border border-gray-300 rounded text-xs font-semibold outline-none focus:border-brand"
                        />
                      </div>
                    </div>
                    <div className="space-y-1">
                      <label className="text-[9px] font-bold text-gray-400 uppercase">{t('Transaction Notes')}</label>
                      <input
                        type="text"
                        placeholder={t('Any internal memo or delivery note...')}
                        value={orderNote}
                        onChange={(e) => setOrderNote(e.target.value)}
                        className="w-full px-2 py-1 border border-gray-300 rounded text-xs outline-none focus:border-brand"
                      />
                    </div>
                  </div>

                  <div className="bg-white rounded-xl border border-gray-200 p-3 space-y-2 shadow-2xs">
                    <span className="text-[10px] font-extrabold text-brand uppercase tracking-wider block">
                      💳 {t('Payment Mode & Split Options')}
                    </span>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-gray-400 uppercase">{t('Payment Method')}</label>
                        <select
                          value={paymentMethod}
                          onChange={(e) => setPaymentMethod(e.target.value as 'Cash' | 'Bank' | 'Mobile Money' | 'Split')}
                          className="w-full px-2 py-1 border border-gray-300 rounded text-xs bg-white font-semibold outline-none"
                        >
                          <option value="Cash">{t('Cash')}</option>
                          <option value="Bank">{t('Bank / Transfer')}</option>
                          <option value="Mobile Money">{t('Mobile Money (M-Pesa/Tigo)')}</option>
                          <option value="Split">{t('Split Payments 🔄')}</option>
                        </select>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[9px] font-bold text-gray-400 uppercase">{t('Payment Status')}</label>
                        <select
                          value={paymentStatus}
                          onChange={(e) => setPaymentStatus(e.target.value as 'Paid' | 'Credit' | 'Partial')}
                          className="w-full px-2 py-1 border border-gray-300 rounded text-xs bg-white font-semibold outline-none"
                        >
                          <option value="Paid">{t('Paid in Full')}</option>
                          <option value="Credit">{t('Credit / On Account')}</option>
                          <option value="Partial">{t('Partial Deposit')}</option>
                        </select>
                      </div>
                    </div>

                    {/* Split payments inputs */}
                    {paymentMethod === 'Split' && (
                      <div className="space-y-1.5 pt-2 border-t mt-2">
                        <span className="text-[9px] font-extrabold text-indigo-600 uppercase block">{t('Split Breakdown')}</span>
                        <div className="grid grid-cols-3 gap-1.5">
                          <div className="space-y-0.5">
                            <label className="text-[8px] font-bold text-gray-400 uppercase">{t('Cash')}</label>
                            <input
                              type="number"
                              min="0"
                              placeholder="0"
                              value={cashAmount || ''}
                              onChange={(e) => setCashAmount(parseFloat(e.target.value) || 0)}
                              className="w-full px-1.5 py-1 border border-gray-300 rounded text-[11px] font-bold font-mono outline-none"
                            />
                          </div>
                          <div className="space-y-0.5">
                            <label className="text-[8px] font-bold text-gray-400 uppercase">{t('Bank')}</label>
                            <input
                              type="number"
                              min="0"
                              placeholder="0"
                              value={bankAmount || ''}
                              onChange={(e) => setBankAmount(parseFloat(e.target.value) || 0)}
                              className="w-full px-1.5 py-1 border border-gray-300 rounded text-[11px] font-bold font-mono outline-none"
                            />
                          </div>
                          <div className="space-y-0.5">
                            <label className="text-[8px] font-bold text-gray-400 uppercase">{t('Mobile')}</label>
                            <input
                              type="number"
                              min="0"
                              placeholder="0"
                              value={mobileAmount || ''}
                              onChange={(e) => setMobileAmount(parseFloat(e.target.value) || 0)}
                              className="w-full px-1.5 py-1 border border-gray-300 rounded text-[11px] font-bold font-mono outline-none"
                            />
                          </div>
                        </div>
                        <div className="text-[10px] font-bold text-indigo-500 mt-1 flex justify-between font-mono">
                          <span>{t('Total Split Paid')}:</span>
                          <span>{formatMoney(cashAmount + bankAmount + mobileAmount, activeCurrency, activeExchangeRate)}</span>
                        </div>
                      </div>
                    )}

                    {/* Partial payment inputs */}
                    {paymentStatus === 'Partial' && paymentMethod !== 'Split' && (
                      <div className="space-y-1 pt-2 border-t mt-2">
                        <label className="text-[9px] font-bold text-gray-400 uppercase">
                          {paymentMethod === 'Cash' ? t('Amount Paid (Cash)') : (paymentMethod === 'Bank' ? t('Amount Paid (Bank)') : t('Amount Paid (Mobile)'))}
                        </label>
                        <input
                          type="number"
                          min="0"
                          placeholder="Enter deposit amount"
                          value={paymentMethod === 'Cash' ? cashAmount || '' : (paymentMethod === 'Bank' ? bankAmount || '' : mobileAmount || '')}
                          onChange={(e) => {
                            const val = parseFloat(e.target.value) || 0;
                            if (paymentMethod === 'Cash') setCashAmount(val);
                            else if (paymentMethod === 'Bank') setBankAmount(val);
                            else setMobileAmount(val);
                          }}
                          className="w-full px-2 py-1 border border-gray-300 rounded text-xs font-semibold font-mono outline-none focus:border-brand"
                        />
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Grand Summary Calculations and Fixed Bottom Buttons */}
            <div className="pt-3 border-t space-y-3 mt-2 bg-gray-50 flex-shrink-0">
              <div className="space-y-1.5 text-xs font-semibold bg-white p-3 rounded-xl border border-gray-200/80 shadow-2xs">
                <div className="flex justify-between text-gray-500">
                  <span>{t('Items Count')}</span>
                  <span className="font-bold text-gray-900">{cart.reduce((sum, item) => sum + item.qty, 0)} units</span>
                </div>
                <div className="flex justify-between text-gray-900 font-bold text-sm pt-1 border-t border-gray-100">
                  <span>{t('GRAND TOTAL')}</span>
                  <span className="text-brand font-black text-base">
                    {formatMoney(totals.total, activeCurrency, activeExchangeRate)}
                  </span>
                </div>
                <div className="flex justify-between items-center text-xs text-emerald-800 bg-emerald-50/80 p-2 rounded-xl border border-emerald-200 mt-1">
                  <div className="flex items-center gap-1.5 font-extrabold">
                    <TrendingUp className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>{t('Estimated Gross Profit')}</span>
                  </div>
                  <div className="flex items-center gap-2 font-black">
                    <span className="text-emerald-700">+{formatMoney(totals.profit, activeCurrency, activeExchangeRate)}</span>
                    <button
                      type="button"
                      onClick={() => setShowProfitBreakdownModal(true)}
                      className="bg-emerald-700 hover:bg-emerald-800 text-white px-2 py-0.5 rounded text-[10px] font-bold uppercase transition flex items-center gap-1 cursor-pointer shadow-2xs"
                      title={t('View step-by-step profit & COGS calculation breakdown')}
                    >
                      <Info className="w-3 h-3" />
                      {t('Breakdown')}
                    </button>
                  </div>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2.5 border border-gray-300 rounded-xl text-xs font-extrabold text-gray-700 hover:bg-gray-100 bg-white shadow-xs transition"
                >
                  {t('Cancel')}
                </button>
                <button
                  type="button"
                  onClick={handleCheckout}
                  disabled={cart.length === 0 || isCreditExceeded}
                  className="flex-2 py-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:bg-gray-300 text-white font-extrabold rounded-xl text-xs uppercase tracking-wider shadow-md transition flex items-center justify-center gap-1.5 disabled:cursor-not-allowed"
                >
                  <CheckCircle className="w-4 h-4" />
                  {t('Complete Checkout')}
                </button>
              </div>
            </div>

          </div>

        </div>

        {/* Close shift submodal form */}
        {showClosingModal && activeShift && isCompanyAdmin && (
          <div className="fixed inset-0 z-55 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col">
              <div className="px-5 py-4 border-b flex items-center justify-between bg-red-900 text-white">
                <span className="font-bold flex items-center gap-2 text-sm">
                  <AlertTriangle className="w-5 h-5 text-amber-400" /> {t('Close Cash Drawer & Reconcile')}
                </span>
                <button onClick={() => setShowClosingModal(false)} className="p-1 hover:bg-red-800 rounded text-red-200 hover:text-white">
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="p-6 space-y-4">
                <div className="bg-slate-50 p-4 rounded-xl space-y-2 text-xs font-semibold">
                  <div className="flex justify-between">
                    <span className="text-gray-400">{t('Opening Float')}:</span>
                    <span className="font-bold text-gray-900">{formatMoney(activeShift.openingFloat, activeCurrency, activeExchangeRate)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-400">{t('Total Shift Cash Sales')}:</span>
                    <span className="font-bold text-emerald-600">+{formatMoney(activeShift.expectedCashSales || 0, activeCurrency, activeExchangeRate)}</span>
                  </div>
                  {autoDrawerExpensesTotal > 0 && (
                    <div className="space-y-1.5 pt-1 border-t border-dashed border-slate-200">
                      <div className="flex justify-between text-rose-600">
                        <span className="font-bold flex items-center gap-1">
                          <ArrowDownRight className="w-3.5 h-3.5" />
                          {t('Drawer Cash Expenses Paid Out')}:
                        </span>
                        <span className="font-bold font-mono">-{formatMoney(autoDrawerExpensesTotal, activeCurrency, activeExchangeRate)}</span>
                      </div>
                      {linkedShiftExpenses.length > 0 && (
                        <div className="bg-rose-50/80 border border-rose-200/80 rounded-lg p-2 max-h-24 overflow-y-auto space-y-1">
                          {linkedShiftExpenses.map(exp => (
                            <div key={exp.id} className="flex justify-between items-center text-[10px] text-gray-700">
                              <span className="truncate max-w-[190px]" title={exp.description}>
                                • {exp.description} <span className="text-gray-400 font-mono">({exp.category})</span>
                              </span>
                              <span className="font-mono font-bold text-rose-700 shrink-0">
                                -{formatMoney(exp.amount, activeCurrency, activeExchangeRate)}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                  <div className="flex justify-between border-t pt-2 font-black text-gray-900">
                    <span>{t('Expected Total Drawer Cash')}:</span>
                    <span>{formatMoney(activeShift.openingFloat + (activeShift.expectedCashSales || 0) - autoDrawerExpensesTotal, activeCurrency, activeExchangeRate)}</span>
                  </div>
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-black uppercase tracking-wider text-gray-400 block">{t('Actual Counted Cash on Hand')}</label>
                    <button
                      type="button"
                      onClick={() => { setShowDenomClose(!showDenomClose); setDenomCounts({}); }}
                      className="text-[10px] text-brand hover:underline font-bold flex items-center gap-1 cursor-pointer"
                    >
                      <Calculator className="w-3 h-3" />
                      {showDenomClose ? t('Hide Calculator') : t('Count Denominations')}
                    </button>
                  </div>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs font-bold text-gray-400">{activeCurrency}</span>
                    <input
                      type="number"
                      value={closingCashActualStr}
                      onChange={(e) => setClosingCashActualStr(e.target.value)}
                      className="w-full pl-12 pr-3 py-2 border rounded-lg text-xs font-black outline-none focus:border-brand"
                      placeholder={t('Enter exact cash amount in drawer')}
                    />
                  </div>
                  {showDenomClose && (
                    <div className="mt-2">
                      {renderPhysicalDenominationCalculator('close')}
                    </div>
                  )}
                </div>

                {/* Live Discrepancy Tracking Card */}
                {(() => {
                  const drawerExp = autoDrawerExpensesTotal;
                  const expectedTotal = activeShift.openingFloat + (activeShift.expectedCashSales || 0) - drawerExp;
                  const actualCash = parseFloat(closingCashActualStr) || 0;
                  const discrepancy = actualCash - expectedTotal;

                  return (
                    <div className={`p-3 rounded-xl border text-xs font-semibold ${
                      discrepancy === 0
                        ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                        : discrepancy > 0
                        ? 'bg-blue-50 border-blue-200 text-blue-800'
                        : 'bg-red-50 border-red-200 text-red-800'
                    }`}>
                      <div className="flex justify-between items-center">
                        <span>{t('Expected Drawer Cash')}:</span>
                        <span>{formatMoney(expectedTotal, activeCurrency, activeExchangeRate)}</span>
                      </div>
                      <div className="flex justify-between items-center border-t border-current/10 pt-1.5 mt-1.5 font-bold">
                        <span>{t('Discrepancy Status')}:</span>
                        <span>
                          {discrepancy === 0 && (
                            <span className="text-emerald-700">✓ {t('Balanced')}</span>
                          )}
                          {discrepancy > 0 && (
                            <span className="text-blue-700">+{formatMoney(discrepancy, activeCurrency, activeExchangeRate)} ({t('Overage')})</span>
                          )}
                          {discrepancy < 0 && (
                            <span className="text-red-700">{formatMoney(discrepancy, activeCurrency, activeExchangeRate)} ({t('Shortage')})</span>
                          )}
                        </span>
                      </div>
                      {discrepancy < 0 && (
                        <p className="text-[10px] text-red-600 mt-1.5 font-medium italic animate-pulse">
                          * {t('Please justify this shortage in the shift closing notes below.')}
                        </p>
                      )}
                    </div>
                  );
                })()}

                <div className="space-y-1">
                  <label className="text-[10px] font-black uppercase tracking-wider text-gray-400 block">{t('Shift Closing Notes (Discrepancy Justifications)')}</label>
                  <textarea
                    value={closingNotes}
                    onChange={(e) => setClosingNotes(e.target.value)}
                    className="w-full px-3 py-2 border rounded-lg text-xs font-semibold outline-none h-16 resize-none"
                    placeholder={t('Describe any shortages, overages, or physical drawer notes...')}
                  />
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowClosingModal(false)}
                    className="flex-1 py-2 border border-gray-300 hover:bg-gray-50 text-gray-700 font-bold rounded-lg text-xs transition"
                  >
                    {t('Keep Open')}
                  </button>
                  <button
                    type="button"
                    onClick={handleCloseShift}
                    className="flex-1 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg text-xs transition shadow-sm cursor-pointer"
                  >
                    {t('Close Session & Reconcile')}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Profit & COGS Calculation Breakdown Modal */}
        {showProfitBreakdownModal && (
          <div className="fixed inset-0 z-55 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[90vh] flex flex-col overflow-hidden animate-fadeIn">
              <div className="px-5 py-4 border-b flex items-center justify-between bg-emerald-900 text-white shrink-0">
                <div className="flex items-center gap-2">
                  <Calculator className="w-5 h-5 text-emerald-300" />
                  <div>
                    <h3 className="font-bold text-sm">{t('Profit & COGS Calculation Breakdown')}</h3>
                    <span className="text-[11px] text-emerald-200 block">{t('Transparent step-by-step cost & margin derivation')}</span>
                  </div>
                </div>
                <button onClick={() => setShowProfitBreakdownModal(false)} className="p-1 hover:bg-white/10 rounded-lg text-white transition">
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="p-5 overflow-y-auto space-y-4">
                {/* Top Formula Banner */}
                <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 space-y-2">
                  <div className="flex items-center gap-2 text-emerald-950 font-extrabold text-xs">
                    <TrendingUp className="w-4 h-4 text-emerald-600" />
                    <span>{t('Profit Calculation Formula')}</span>
                  </div>
                  <p className="text-xs text-emerald-900 font-mono leading-relaxed">
                    <strong>{t('Gross Profit')}</strong> = {t('Total Sales Revenue')} ({formatMoney(totals.total, activeCurrency, activeExchangeRate)}) − {t('Cost of Goods Sold (COGS)')} ({formatMoney(totals.cost, activeCurrency, activeExchangeRate)}) = <span className="text-emerald-700 font-extrabold">{formatMoney(totals.profit, activeCurrency, activeExchangeRate)}</span>
                  </p>
                  <p className="text-[11px] text-emerald-700 font-medium">
                    💡 {t('COGS is calculated using First-In, First-Out (FIFO) inventory batches. Stock received earliest is consumed first.')}
                  </p>
                </div>

                {/* Summary Metric Cards */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="bg-gray-50 border border-gray-200 p-3 rounded-xl">
                    <span className="text-[10px] font-bold text-gray-500 uppercase block">{t('Total Revenue')}</span>
                    <span className="text-sm font-extrabold text-gray-900">{formatMoney(totals.total, activeCurrency, activeExchangeRate)}</span>
                  </div>
                  <div className="bg-amber-50 border border-amber-200 p-3 rounded-xl">
                    <span className="text-[10px] font-bold text-amber-700 uppercase block">{t('Total COGS Cost')}</span>
                    <span className="text-sm font-extrabold text-amber-950">{formatMoney(totals.cost, activeCurrency, activeExchangeRate)}</span>
                  </div>
                  <div className="bg-emerald-50 border border-emerald-200 p-3 rounded-xl">
                    <span className="text-[10px] font-bold text-emerald-700 uppercase block">{t('Net Gross Profit')}</span>
                    <span className="text-sm font-extrabold text-emerald-700">+{formatMoney(totals.profit, activeCurrency, activeExchangeRate)}</span>
                  </div>
                  <div className="bg-indigo-50 border border-indigo-200 p-3 rounded-xl">
                    <span className="text-[10px] font-bold text-indigo-700 uppercase block">{t('Profit Margin %')}</span>
                    <span className="text-sm font-extrabold text-indigo-900">
                      {totals.total > 0 ? ((totals.profit / totals.total) * 100).toFixed(1) : 0}%
                    </span>
                  </div>
                </div>

                {/* Itemized Table */}
                <div className="border border-gray-200 rounded-xl overflow-hidden">
                  <div className="px-4 py-2.5 bg-gray-50 border-b border-gray-200 font-bold text-xs text-gray-800">
                    {t('Itemized Product Cost & Profit Attribution')} ({cart.length} {t('items in cart')})
                  </div>

                  {cart.length === 0 ? (
                    <div className="p-6 text-center text-gray-400 text-xs">
                      {t('Cart is empty. Add products to view profit breakdown.')}
                    </div>
                  ) : (
                    <div className="divide-y divide-gray-100">
                      {cart.map((c, i) => {
                        const item = stockItems.find(p => p.id === c.productId);
                        if (!item) return null;

                        const isSubUnit = c.unitType === 'sub';
                        const conversion = isSubUnit ? 1 : (item.useSubUnitPricing ? (item.subUnitConversion || 1) : 1);
                        const baseQtyRequired = c.qty * conversion;

                        const fifoBreakdown = getFIFOBatchBreakdown(item, selectedStoreId as number, baseQtyRequired);
                        const lineRevenue = c.price * c.qty;
                        const lineCost = fifoBreakdown.totalCost;
                        const lineProfit = lineRevenue - lineCost;
                        const marginPct = lineRevenue > 0 ? ((lineProfit / lineRevenue) * 100).toFixed(1) : '0';

                        return (
                          <div key={i} className="p-3.5 space-y-2 hover:bg-gray-50/60 transition">
                            <div className="flex flex-wrap items-center justify-between gap-2">
                              <div>
                                <span className="font-extrabold text-xs text-gray-900 block">{item.name} ({item.code})</span>
                                <span className="text-[10px] text-gray-500 font-medium">
                                  {t('Selling')}: {c.qty} {c.unitType === 'sub' ? item.subUnitName : (item.unit || 'units')} @ {formatMoney(c.price, activeCurrency, activeExchangeRate)}
                                </span>
                              </div>
                              <div className="text-right">
                                <span className="font-extrabold text-xs text-emerald-700 block">
                                  {lineProfit >= 0 ? '+' : ''}{formatMoney(lineProfit, activeCurrency, activeExchangeRate)} ({marginPct}% {t('margin')})
                                </span>
                                <span className="text-[10px] text-gray-500 font-mono">
                                  {t('Rev')}: {formatMoney(lineRevenue, activeCurrency, activeExchangeRate)} | {t('COGS')}: {formatMoney(lineCost, activeCurrency, activeExchangeRate)}
                                </span>
                              </div>
                            </div>

                            {/* FIFO Batch Sources details */}
                            <div className="bg-purple-50/60 border border-purple-100 rounded-lg p-2 text-[10px] text-purple-950 space-y-1 font-mono">
                              <span className="font-bold text-purple-700 block flex items-center gap-1">
                                <Layers className="w-3 h-3 text-purple-600" />
                                {t('Cost Origin (FIFO Batch Trace)')}:
                              </span>
                              <div className="space-y-0.5 pl-4">
                                {fifoBreakdown.batchContributions.map((b, idx) => (
                                  <div key={idx} className="flex justify-between">
                                    <span>
                                      • {b.poNumber} ({b.qtyDeducted} {item.unit || 'units'} @ {formatMoney(b.unitCost, activeCurrency, activeExchangeRate)})
                                    </span>
                                    <span className="font-bold">{formatMoney(b.totalCost, activeCurrency, activeExchangeRate)}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              <div className="px-5 py-3 border-t bg-gray-50 flex justify-end shrink-0">
                <button
                  onClick={() => setShowProfitBreakdownModal(false)}
                  className="bg-gray-900 hover:bg-gray-800 text-white font-bold text-xs px-4 py-2 rounded-xl transition"
                >
                  {t('Close')}
                </button>
              </div>
            </div>
          </div>
        )}

        {/* ========================================================================= */}
        {/* POS BARCODE STUDIO & SHELF LABEL GENERATOR (RETAILER / WHOLESALER / PREFERRED) */}
        {/* ========================================================================= */}
        {showBarcodeModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-black/75 backdrop-blur-xs animate-fade-in">
            <div className="bg-white w-full max-w-4xl max-h-[92vh] rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-gray-200">
              
              {/* Modal Header */}
              <div className="px-6 py-4 bg-gradient-to-r from-gray-900 via-gray-800 to-gray-900 text-white flex items-center justify-between shrink-0">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-amber-400/20 border border-amber-400/30 flex items-center justify-center text-amber-400">
                    <Barcode className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-black tracking-wide text-white">
                        {t('POS Barcode Studio & Label Generator')}
                      </h3>
                      <span className="text-[10px] px-2 py-0.5 rounded-full font-extrabold uppercase bg-amber-400 text-gray-900">
                        Code 128
                      </span>
                    </div>
                    <p className="text-xs text-gray-400">
                      {t('Generate vector barcodes with Retailer, Wholesaler & Preferred Customer price mapping')}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => setShowBarcodeModal(false)}
                  className="p-1.5 rounded-lg hover:bg-white/10 text-gray-400 hover:text-white transition cursor-pointer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Modal Body */}
              <div className="p-6 overflow-y-auto flex-1 space-y-6">
                
                {/* Product Picker & Search */}
                <div className="bg-gray-50 p-4 rounded-xl border border-gray-200/80 space-y-3">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                    <div className="flex-1">
                      <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-1">
                        {t('Select Catalog Product')}
                      </label>
                      <div className="relative">
                        <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                        <input
                          type="text"
                          placeholder={t('Search by product name or SKU...')}
                          value={barcodeSearchTerm}
                          onChange={(e) => setBarcodeSearchTerm(e.target.value)}
                          className="w-full pl-9 pr-3 py-2 bg-white border border-gray-300 rounded-lg text-xs font-semibold outline-none focus:ring-2 focus:ring-brand/30 focus:border-brand"
                        />
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      <div>
                        <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-1">
                          {t('Label Copies')}
                        </label>
                        <input
                          type="number"
                          min="1"
                          max="100"
                          value={Number.isFinite(barcodeLabelQty) ? barcodeLabelQty : 1}
                          onChange={(e) => setBarcodeLabelQty(Math.max(1, Math.min(100, parseInt(e.target.value, 10) || 1)))}
                          className="w-20 px-2.5 py-2 bg-white border border-gray-300 rounded-lg text-xs font-bold text-center outline-none focus:border-brand"
                        />
                      </div>

                      <div>
                        <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wider block mb-1">
                          {t('Label Format')}
                        </label>
                        <select
                          value={barcodePrintLayout}
                          onChange={(e: any) => setBarcodePrintLayout(e.target.value)}
                          className="px-3 py-2 bg-white border border-gray-300 rounded-lg text-xs font-bold outline-none focus:border-brand"
                        >
                          <option value="thermal">🏷️ {t('Thermal Label (50x30mm)')}</option>
                          <option value="shelf">📌 {t('Shelf Edge Tag')}</option>
                          <option value="sheet">📄 {t('A4 Sticker Sheet (24/page)')}</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  {/* Filtered Products Horizontal Scroll List */}
                  {barcodeSearchTerm.trim() && (
                    <div className="max-h-36 overflow-y-auto space-y-1 border-t pt-2">
                      {stockItems
                        .filter(item =>
                          safeLower(item.name).includes(barcodeSearchTerm.toLowerCase()) ||
                          safeLower(item.code).includes(barcodeSearchTerm.toLowerCase())
                        )
                        .slice(0, 8)
                        .map(item => (
                          <div
                            key={item.id}
                            onClick={() => {
                              setBarcodeSelectedProduct(item);
                              setBarcodeSearchTerm('');
                            }}
                            className={`p-2 rounded-lg text-xs flex items-center justify-between cursor-pointer transition ${
                              barcodeSelectedProduct?.id === item.id
                                ? 'bg-brand/10 border border-brand font-bold text-brand'
                                : 'hover:bg-white bg-white/70 border border-transparent'
                            }`}
                          >
                            <span className="truncate">{item.name} <span className="font-mono text-gray-400">({item.code})</span></span>
                            <span className="font-bold text-gray-700">{formatMoney(item.retailPrice, activeCurrency, activeExchangeRate)}</span>
                          </div>
                        ))}
                    </div>
                  )}
                </div>

                {/* Customer Price Tier Selector */}
                {barcodeSelectedProduct && (
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-xs font-black text-gray-800 uppercase tracking-wider flex items-center gap-1.5">
                        <Tag className="w-4 h-4 text-brand" />
                        <span>{t('Customer Pricing Tier for Barcode Label')}</span>
                      </label>
                      <span className="text-[11px] font-semibold text-gray-500">
                        {t('Choose which price to print or choose Multi-Tier Shelf Tag')}
                      </span>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                      {/* Retailer Tier */}
                      <button
                        type="button"
                        onClick={() => setBarcodePriceTier('Retail')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          barcodePriceTier === 'Retail'
                            ? 'border-blue-500 bg-blue-50/60 ring-2 ring-blue-500/20 shadow-xs'
                            : 'border-gray-200 hover:border-gray-300 bg-white'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-black uppercase text-blue-700 bg-blue-100 px-1.5 py-0.5 rounded">
                            {t('Retailer')}
                          </span>
                          {barcodePriceTier === 'Retail' && <CheckCircle className="w-4 h-4 text-blue-600" />}
                        </div>
                        <p className="text-sm font-black text-gray-900 mt-1">
                          {formatMoney(barcodeSelectedProduct.retailPrice, activeCurrency, activeExchangeRate)}
                        </p>
                        <p className="text-[10px] text-gray-500 mt-0.5">{t('Standard Rejareja Price')}</p>
                      </button>

                      {/* Wholesaler Tier */}
                      <button
                        type="button"
                        onClick={() => setBarcodePriceTier('Wholesale')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          barcodePriceTier === 'Wholesale'
                            ? 'border-amber-500 bg-amber-50/60 ring-2 ring-amber-500/20 shadow-xs'
                            : 'border-gray-200 hover:border-gray-300 bg-white'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-black uppercase text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded">
                            {t('Wholesaler')}
                          </span>
                          {barcodePriceTier === 'Wholesale' && <CheckCircle className="w-4 h-4 text-amber-600" />}
                        </div>
                        <p className="text-sm font-black text-gray-900 mt-1">
                          {formatMoney(barcodeSelectedProduct.wholesalePrice, activeCurrency, activeExchangeRate)}
                        </p>
                        <p className="text-[10px] text-gray-500 mt-0.5">{t('Bulk Jumla Price')}</p>
                      </button>

                      {/* Preferred Customer Tier */}
                      <button
                        type="button"
                        onClick={() => setBarcodePriceTier('Preferred')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          barcodePriceTier === 'Preferred'
                            ? 'border-emerald-500 bg-emerald-50/60 ring-2 ring-emerald-500/20 shadow-xs'
                            : 'border-gray-200 hover:border-gray-300 bg-white'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-black uppercase text-emerald-800 bg-emerald-100 px-1.5 py-0.5 rounded">
                            {t('Preferred')}
                          </span>
                          {barcodePriceTier === 'Preferred' && <CheckCircle className="w-4 h-4 text-emerald-600" />}
                        </div>
                        <p className="text-sm font-black text-gray-900 mt-1">
                          {formatMoney(barcodeSelectedProduct.partnerPrice ?? barcodeSelectedProduct.retailPrice, activeCurrency, activeExchangeRate)}
                        </p>
                        <p className="text-[10px] text-gray-500 mt-0.5">{t('Special Partner / VIP Price')}</p>
                      </button>

                      {/* Multi-Tier Tag */}
                      <button
                        type="button"
                        onClick={() => setBarcodePriceTier('All')}
                        className={`p-3 rounded-xl border text-left transition-all cursor-pointer ${
                          barcodePriceTier === 'All'
                            ? 'border-purple-500 bg-purple-50/60 ring-2 ring-purple-500/20 shadow-xs'
                            : 'border-gray-200 hover:border-gray-300 bg-white'
                        }`}
                      >
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-[10px] font-black uppercase text-purple-800 bg-purple-100 px-1.5 py-0.5 rounded">
                            {t('All Tiers')}
                          </span>
                          {barcodePriceTier === 'All' && <CheckCircle className="w-4 h-4 text-purple-600" />}
                        </div>
                        <p className="text-xs font-black text-gray-900 mt-1">
                          {t('Multi-Price Tag')}
                        </p>
                        <p className="text-[10px] text-gray-500 mt-0.5">{t('Shows Retail, Wholesale & Preferred')}</p>
                      </button>
                    </div>
                  </div>
                )}

                {/* Live Barcode Label Preview Card */}
                {barcodeSelectedProduct && (() => {
                  const item = barcodeSelectedProduct;
                  const { bars, totalWidth } = encodeCode128B(item.code, 2);
                  const barcodeHeight = 44;

                  let activeLabelPrice = item.retailPrice;
                  let activeLabelTierName = t('Retail Price');
                  let activeTierBadgeColor = 'bg-blue-600 text-white';

                  if (barcodePriceTier === 'Wholesale') {
                    activeLabelPrice = item.wholesalePrice;
                    activeLabelTierName = t('Wholesale Price (Jumla)');
                    activeTierBadgeColor = 'bg-amber-600 text-white';
                  } else if (barcodePriceTier === 'Preferred') {
                    activeLabelPrice = item.partnerPrice ?? item.retailPrice;
                    activeLabelTierName = t('Preferred Price (Mteja Maalumu)');
                    activeTierBadgeColor = 'bg-emerald-600 text-white';
                  }

                  return (
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-5 items-start">
                      
                      {/* Left: Label Visual Preview */}
                      <div className="bg-gray-100 p-5 rounded-2xl flex flex-col items-center justify-center border border-gray-200">
                        <span className="text-[10px] font-black text-gray-400 uppercase tracking-wider mb-2">
                          {t('Physical Sticker / Shelf Tag Preview')}
                        </span>

                        {/* Printable Label Box */}
                        <div
                          id="pos-barcode-print-container"
                          className="w-full max-w-sm bg-white p-4 rounded-xl border-2 border-dashed border-gray-300 shadow-md flex flex-col items-center text-center space-y-2 transition-all"
                        >
                          {/* Store Name & Category */}
                          <div className="w-full flex items-center justify-between border-b pb-1.5 text-[9px] font-extrabold uppercase text-gray-400">
                            <span className="truncate max-w-[150px]">{(settings as any)?.companyName || 'TRADECORE ERP'}</span>
                            <span className="text-gray-500">{cleanCategoryName(item.category)}</span>
                          </div>

                          {/* Product Title */}
                          <div className="w-full">
                            <h4 className="text-xs font-black text-gray-900 truncate">{item.name}</h4>
                            <p className="text-[10px] text-gray-500 font-mono tracking-wider">
                              SKU: {item.code} {item.unit ? `• ${item.unit}` : ''}
                            </p>
                          </div>

                          {/* Vector SVG Barcode */}
                          <div className="w-full flex justify-center py-1 bg-white">
                            <svg
                              viewBox={`0 0 ${totalWidth} ${barcodeHeight + 16}`}
                              className="w-full max-h-14 overflow-visible"
                            >
                              <rect width={totalWidth} height={barcodeHeight + 16} fill="#ffffff" />
                              {bars.map((bar, idx) => (
                                <rect
                                  key={idx}
                                  x={bar.x}
                                  y={0}
                                  width={bar.width}
                                  height={barcodeHeight}
                                  fill="#000000"
                                />
                              ))}
                              <text
                                x={totalWidth / 2}
                                y={barcodeHeight + 13}
                                textAnchor="middle"
                                fontFamily="monospace"
                                fontSize="11"
                                fontWeight="bold"
                                fill="#000000"
                                letterSpacing="2"
                              >
                                {item.code}
                              </text>
                            </svg>
                          </div>

                          {/* Price Tag Representation */}
                          {barcodePriceTier === 'All' ? (
                            <div className="w-full grid grid-cols-3 gap-1 pt-1.5 border-t border-gray-100 text-[10px]">
                              <div className="bg-blue-50 p-1 rounded border border-blue-100 text-center">
                                <span className="block text-[8px] font-bold text-blue-700 uppercase">{t('Retail')}</span>
                                <span className="font-black text-gray-900">{formatMoney(item.retailPrice, activeCurrency, activeExchangeRate)}</span>
                              </div>
                              <div className="bg-amber-50 p-1 rounded border border-amber-100 text-center">
                                <span className="block text-[8px] font-bold text-amber-700 uppercase">{t('Wholesale')}</span>
                                <span className="font-black text-gray-900">{formatMoney(item.wholesalePrice, activeCurrency, activeExchangeRate)}</span>
                              </div>
                              <div className="bg-emerald-50 p-1 rounded border border-emerald-100 text-center">
                                <span className="block text-[8px] font-bold text-emerald-700 uppercase">{t('Preferred')}</span>
                                <span className="font-black text-gray-900">{formatMoney(item.partnerPrice ?? item.retailPrice, activeCurrency, activeExchangeRate)}</span>
                              </div>
                            </div>
                          ) : (
                            <div className="w-full pt-1 border-t border-gray-100 flex items-center justify-between px-2">
                              <span className={`text-[9px] font-black uppercase px-2 py-0.5 rounded ${activeTierBadgeColor}`}>
                                {activeLabelTierName}
                              </span>
                              <span className="text-base font-black text-gray-900">
                                {formatMoney(activeLabelPrice, activeCurrency, activeExchangeRate)}
                              </span>
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Right: How Barcode Scanning Works with Customer Types */}
                      <div className="space-y-4">
                        <div className="p-4 rounded-xl bg-gradient-to-br from-indigo-50/70 to-blue-50/70 border border-indigo-100 space-y-3">
                          <div className="flex items-center gap-2 text-indigo-900 font-black text-xs uppercase tracking-wide">
                            <Layers className="w-4 h-4 text-indigo-600" />
                            <span>{t('How Barcode Scanning Works with Customer Types')}</span>
                          </div>

                          <div className="space-y-2 text-xs text-gray-700 leading-relaxed">
                            <p>
                              {t('In TradeCore POS, barcode guns and camera scanners scan the')} <strong className="font-mono text-gray-900">{item.code}</strong> {t('SKU. The POS dynamically applies the pricing tier linked to the selected customer:')}
                            </p>

                            <div className="bg-white p-3 rounded-lg border border-indigo-100/80 space-y-2">
                              <div className="flex items-center justify-between text-xs pb-1 border-b border-gray-100">
                                <span className="font-bold text-gray-600">{t('Active POS Customer')}:</span>
                                <span className="font-black text-indigo-700">
                                  {selectedCustomer ? `${selectedCustomer.name} (${selectedCustomer.type})` : `Walk-In (${priceType})`}
                                </span>
                              </div>

                              <div className="flex items-center justify-between text-xs">
                                <span className="font-bold text-gray-600">{t('Price Charged on Barcode Scan')}:</span>
                                <span className="font-black text-emerald-600 text-sm">
                                  {formatMoney(getProductPrice(item, 'main', (selectedCustomer?.type || priceType) as any), activeCurrency, activeExchangeRate)}
                                </span>
                              </div>
                            </div>

                            <ul className="text-[11px] space-y-1 text-gray-600 pl-4 list-disc">
                              <li><strong>{t('Retailer (Rejareja)')}:</strong> {t('When Walk-In or Retail customer is chosen, scan charges standard retail price.')}</li>
                              <li><strong>{t('Wholesaler (Jumla)')}:</strong> {t('When wholesale buyer is chosen, scan automatically drops unit cost to bulk wholesale.')}</li>
                              <li><strong>{t('Preferred Customer')}:</strong> {t('When VIP or contract customer is chosen, scan instantly applies preferred price.')}</li>
                            </ul>
                          </div>
                        </div>

                        {/* Direct Test & Cart Action */}
                        <div className="flex flex-col gap-2">
                          <button
                            type="button"
                            onClick={() => {
                              handleAddToCart(item);
                              toast.success(`⚡ [${item.code}] ${item.name} ${t('added to cart at')} ${formatMoney(getProductPrice(item, 'main'), activeCurrency, activeExchangeRate)}`);
                            }}
                            className="w-full py-2.5 px-3 bg-brand hover:bg-brand-hover text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition cursor-pointer"
                          >
                            <ShoppingCart className="w-4 h-4" />
                            <span>{t('Test Scan / Add to POS Cart Now')} ({formatMoney(getProductPrice(item, 'main'), activeCurrency, activeExchangeRate)})</span>
                          </button>

                          <div className="flex items-center gap-2">
                            <button
                              type="button"
                              onClick={() => {
                                handlePrintWithFallback((title, desc) => {
                                  setConfirmModal({
                                    isOpen: true,
                                    title: t(title),
                                    description: t(desc),
                                    onConfirm: () => {}
                                  });
                                });
                              }}
                              className="flex-1 py-2 px-3 bg-gray-900 hover:bg-gray-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition cursor-pointer"
                            >
                              <Printer className="w-3.5 h-3.5" />
                              <span>{t('Print Labels')} ({barcodeLabelQty}x)</span>
                            </button>

                            <button
                              type="button"
                              onClick={() => handleDownloadBarcodeSvg(item.code, item.name)}
                              className="px-3 py-2 bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition cursor-pointer"
                              title={t('Download standalone vector SVG for product packaging or thermal software')}
                            >
                              <Download className="w-3.5 h-3.5" />
                              <span>{t('SVG')}</span>
                            </button>
                          </div>
                        </div>

                      </div>
                    </div>
                  );
                })()}

              </div>

              {/* Modal Footer */}
              <div className="px-6 py-3 border-t bg-gray-50 flex items-center justify-between shrink-0">
                <span className="text-[11px] font-semibold text-gray-500">
                  {t('Compatible with all standard barcode guns, USB scanners, Honeywell, Datalogic & mobile cameras.')}
                </span>
                <button
                  onClick={() => setShowBarcodeModal(false)}
                  className="bg-gray-900 hover:bg-gray-800 text-white font-bold text-xs px-5 py-2 rounded-xl transition cursor-pointer"
                >
                  {t('Done')}
                </button>
              </div>

            </div>
          </div>
        )}

      </div>
    </div>
  );
}
