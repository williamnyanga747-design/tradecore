import React, { useState, useEffect, useMemo, useRef } from 'react';
import { Expense, Store, Branch, PosShift } from '../types';
import { formatMoney, exportToExcel } from '../utils/format';
import { handlePrintWithFallback } from '../utils/printHelper';
import { safeLower } from '../utils/stateHelpers';
import { compressImageFile, formatByteSize } from '../utils/imageCompression';
import { Plus, Trash2, Pencil, Search, Calendar, CreditCard, Receipt, AlertCircle, FileSpreadsheet, Printer, Camera, Upload, X, CheckCircle2, FileText, ArrowDownRight } from 'lucide-react';
import { ConfirmActionModal } from './ConfirmActionModal';
import { sameId } from '../utils/idUtils';
import ExpenseReceiptModal from './ExpenseReceiptModal';
import ReceiptCameraModal from './ReceiptCameraModal';
import { toast } from '../utils/toast';

interface ExpensesProps {
  expenses: Expense[];
  stores: Store[];
  branches?: Branch[];
  currentCompanyId?: string | number | null;
  currentStoreId: string | number | null;
  currency: string;
  exchangeRate: number;
  isAdmin: boolean;
  logAction: (action: string, details: string) => void;
  onUpdateExpenses: (newExpenses: Expense[]) => void;
  translate: (t: string) => string;
  posShifts?: PosShift[];
  onUpdateShifts?: (newShifts: PosShift[]) => void;
}

export default function Expenses({
  expenses,
  stores,
  branches,
  currentCompanyId,
  currentStoreId,
  currency,
  exchangeRate,
  isAdmin,
  logAction,
  onUpdateExpenses,
  translate,
  posShifts = [],
  onUpdateShifts
}: ExpensesProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingExpenseId, setEditingExpenseId] = useState<number | null>(null);
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    description: '',
    onConfirm: () => {}
  });

  // Receipt Modal state
  const [selectedExpenseForReceipt, setSelectedExpenseForReceipt] = useState<Expense | null>(null);
  const [receiptModalOpen, setReceiptModalOpen] = useState(false);
  const [formCameraOpen, setFormCameraOpen] = useState(false);
  const formFileInputRef = useRef<HTMLInputElement | null>(null);
  
  // Form fields
  const [category, setCategory] = useState('Utilities');
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const activeStores = useMemo(() => stores.filter(s => !s.isDeleted), [stores]);
  const [storeId, setStoreId] = useState<string | number | null>(currentStoreId || (activeStores[0]?.id ?? null));
  const [paymentMethod, setPaymentMethod] = useState<'Cash' | 'Bank' | 'Mobile Money'>('Cash');
  const [paidFromDrawerFloat, setPaidFromDrawerFloat] = useState(true);
  const [receiptUrl, setReceiptUrl] = useState<string>('');
  const [receiptName, setReceiptName] = useState<string>('');

  // Filters
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('');
  const [filterStoreId, setFilterStoreId] = useState<string>('all');

  const categories = ['Rent', 'Utilities', 'Salaries', 'Transport', 'Packaging', 'Marketing', 'Other'];

  useEffect(() => {
    if (currentStoreId) {
      setStoreId(currentStoreId);
    }
  }, [currentStoreId]);

  const effectiveStoreId = useMemo(() => {
    return (storeId != null && storeId !== '' && storeId !== 'all') ? storeId : currentStoreId;
  }, [storeId, currentStoreId]);

  const activeShiftForStore = useMemo(() => {
    return (posShifts || []).find(s => sameId(s.storeId, effectiveStoreId) && s.status === 'Open');
  }, [posShifts, effectiveStoreId]);

  const handleOpenAdd = () => {
    setEditingExpenseId(null);
    setCategory('Utilities');
    setDescription('');
    setAmount('');
    setDate(new Date().toISOString().split('T')[0]);
    if (currentStoreId) setStoreId(currentStoreId);
    setPaymentMethod('Cash');
    setPaidFromDrawerFloat(true);
    setReceiptUrl('');
    setReceiptName('');
    setShowAddForm(true);
  };

  const handleOpenEdit = (exp: Expense) => {
    if (!isAdmin) return;
    setEditingExpenseId(exp.id);
    setCategory(exp.category);
    setDescription(exp.description);
    // Convert to display amount for edit form
    const displayAmt = currency === 'TZS' ? exp.amount * exchangeRate : exp.amount;
    setAmount(displayAmt.toString());
    setDate(exp.date);
    setStoreId(exp.storeId);
    setPaymentMethod(exp.paymentMethod);
    setPaidFromDrawerFloat(exp.paidFromDrawerFloat ?? false);
    setReceiptUrl(exp.receiptUrl || '');
    setReceiptName(exp.receiptName || '');
    setShowAddForm(true);
  };

  const handleFormReceiptFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files && e.target.files[0];
    if (!file) return;
    if (file.size > 15 * 1024 * 1024) {
      toast.error(translate('File is too large. Maximum size is 15MB.'));
      return;
    }
    try {
      if (file.type.startsWith('image/')) {
        const compressed = await compressImageFile(file, { maxWidth: 1280, maxHeight: 1280, quality: 0.82 });
        setReceiptUrl(compressed.dataUrl);
        setReceiptName(file.name);
        toast.success(`${translate('Receipt compressed')} (${formatByteSize(compressed.originalBytes)} → ${formatByteSize(compressed.compressedBytes)})`);
      } else {
        const reader = new FileReader();
        reader.onload = () => {
          setReceiptUrl(String(reader.result || ''));
          setReceiptName(file.name);
        };
        reader.readAsDataURL(file);
      }
    } catch {
      toast.error(translate('Could not process this receipt file.'));
    }
  };

  const handleSaveReceiptFromModal = async (expenseId: number, newReceiptUrl: string, newReceiptName?: string) => {
    const nowIso = new Date().toISOString();
    const updated = expenses.map(exp => {
      if (exp.id === expenseId) {
        return {
          ...exp,
          receiptUrl: newReceiptUrl,
          receiptName: newReceiptName || 'receipt.jpg',
          receiptUploadedAt: nowIso
        };
      }
      return exp;
    });
    await onUpdateExpenses(updated);
    logAction('Attached Expense Receipt', `Linked receipt to expense #${expenseId}`);
  };

  const handleRemoveReceiptFromModal = async (expenseId: number) => {
    const updated = expenses.map(exp => {
      if (exp.id === expenseId) {
        const copy = { ...exp };
        delete copy.receiptUrl;
        delete copy.receiptName;
        delete copy.receiptUploadedAt;
        return copy;
      }
      return exp;
    });
    await onUpdateExpenses(updated);
    logAction('Removed Expense Receipt', `Detached receipt from expense #${expenseId}`);
  };

  const handleSubmit = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!description.trim() || !amount) return;

    // Convert input amount back to USD (base currency)
    const rawAmt = parseFloat(amount);
    const usdAmount = currency === 'TZS' ? rawAmt / exchangeRate : rawAmt;

    const selectedStore = activeStores.find(s => sameId(s.id, storeId));
    const storeBranch = selectedStore && branches ? branches.find(b => sameId(b.id, selectedStore.branchId)) : null;
    const effectiveCompanyId = currentCompanyId
      || (selectedStore as any)?.companyId
      || storeBranch?.companyId;

    const cleanStoreId = storeId != null && storeId !== '' && storeId !== 'all' ? (selectedStore ? selectedStore.id : storeId) : null;

    const isDrawerExpense = paymentMethod === 'Cash' && paidFromDrawerFloat;
    const targetShiftId = isDrawerExpense && activeShiftForStore ? activeShiftForStore.id : (editingExpenseId !== null ? undefined : undefined);

    if (editingExpenseId !== null) {
      // Edit mode
      const updated = expenses.map(exp => {
        if (exp.id === editingExpenseId) {
          return {
            ...exp,
            category,
            description,
            amount: usdAmount,
            date,
            storeId: cleanStoreId,
            companyId: exp.companyId || effectiveCompanyId,
            paymentMethod,
            paidFromDrawerFloat: isDrawerExpense,
            posShiftId: targetShiftId !== undefined ? targetShiftId : exp.posShiftId,
            receiptUrl: receiptUrl || undefined,
            receiptName: receiptName || undefined,
            receiptUploadedAt: receiptUrl ? (exp.receiptUploadedAt || new Date().toISOString()) : undefined
          };
        }
        return exp;
      });
      // Keep the form mounted until the optimistic mutation promise settles so no
      // detached-form submission can ever be canceled by the browser.
      await onUpdateExpenses(updated);
      logAction("Edited Expense", `Modified expense ${editingExpenseId}: ${description} (${usdAmount} USD)`);
    } else {
      // Create mode
      const maxId = expenses.length > 0 ? Math.max(...expenses.map(e => e.id)) : 0;
      const newExp: Expense = {
        id: maxId + 1,
        expenseNumber: `EXP-2026-${String(maxId + 1).padStart(4, '0')}`,
        category,
        description,
        amount: usdAmount,
        date,
        storeId: cleanStoreId,
        companyId: effectiveCompanyId,
        paymentMethod,
        paidFromDrawerFloat: isDrawerExpense,
        posShiftId: targetShiftId || null,
        receiptUrl: receiptUrl || undefined,
        receiptName: receiptName || undefined,
        receiptUploadedAt: receiptUrl ? new Date().toISOString() : undefined
      };
      await onUpdateExpenses([newExp, ...expenses]);

      if (isDrawerExpense && activeShiftForStore && onUpdateShifts) {
        const updatedShifts = posShifts.map(s => {
          if (s.id === activeShiftForStore.id) {
            return {
              ...s,
              drawerExpensesTotal: (s.drawerExpensesTotal || 0) + usdAmount,
              expenseIds: Array.from(new Set([...(s.expenseIds || []), newExp.id]))
            };
          }
          return s;
        });
        onUpdateShifts(updatedShifts);
      }

      logAction("Logged Expense", `Added expense: ${newExp.expenseNumber} - ${description} (${usdAmount} USD)${isDrawerExpense ? ` [Paid from POS Drawer Shift #${activeShiftForStore?.id || 'Active'}]` : ''}`);
      if (isDrawerExpense) {
        toast.success(translate('Expense recorded and automatically linked to POS drawer shift!'));
      }
    }

    setShowAddForm(false);
  };

  const handleDelete = (id: number, expNum: string) => {
    if (!isAdmin) return;
    setConfirmModal({
      isOpen: true,
      title: translate("Confirm Delete Expense"),
      description: translate("Are you sure you want to completely delete this expense?"),
      onConfirm: () => {
        const filtered = expenses.filter(exp => exp.id !== id);
        onUpdateExpenses(filtered);
        logAction("Deleted Expense", `Removed expense item: ${expNum}`);
      }
    });
  };

  const getStoreName = (id: number | string | null) => {
    if (id == null) return translate("General / HQ");
    return stores.find(s => sameId(s.id, id))?.name || `Store #${id}`;
  };

  // Filter local store and queries
  const filteredExpenses = useMemo(() => {
    return expenses.filter(exp => {
      const matchStore = filterStoreId !== 'all'
        ? sameId(exp.storeId, filterStoreId)
        : (currentStoreId ? (sameId(exp.storeId, currentStoreId) || exp.storeId == null) : true);
      const matchCat = filterCategory ? exp.category === filterCategory : true;
      const matchSearch = searchQuery
        ? safeLower(exp.description).includes(searchQuery.toLowerCase()) ||
          safeLower(exp.expenseNumber).includes(searchQuery.toLowerCase())
        : true;
      return matchStore && matchCat && matchSearch;
    });
  }, [expenses, filterStoreId, currentStoreId, filterCategory, searchQuery]);

  const [currentPageNum, setCurrentPageNum] = useState<number>(1);
  const EXPENSES_PAGE_SIZE = 50;

  useEffect(() => {
    setCurrentPageNum(1);
  }, [searchQuery, filterCategory, currentStoreId]);

  const totalPages = Math.max(1, Math.ceil(filteredExpenses.length / EXPENSES_PAGE_SIZE));
  const activePage = Math.min(currentPageNum, totalPages);
  const paginatedExpenses = filteredExpenses.slice((activePage - 1) * EXPENSES_PAGE_SIZE, activePage * EXPENSES_PAGE_SIZE);

  const totalFilteredAmt = filteredExpenses.reduce((sum, e) => sum + e.amount, 0);

  const handleExportExcel = () => {
    let tableHtml = `
      <h3>${translate('Expenses')} Report - ${currentStoreId ? getStoreName(currentStoreId) : 'All Stores'}</h3>
      <p>Generated on: ${new Date().toLocaleString()}</p>
      <table>
        <thead>
          <tr>
            <th style="background-color: #ef4444; color: white;">Expense ID</th>
            <th style="background-color: #ef4444; color: white;">Date</th>
            <th style="background-color: #ef4444; color: white;">Category</th>
            <th style="background-color: #ef4444; color: white;">Description</th>
            <th style="background-color: #ef4444; color: white;">Store Location</th>
            <th style="background-color: #ef4444; color: white;">Payment Method</th>
            <th style="background-color: #ef4444; color: white; text-align: right;">Amount</th>
          </tr>
        </thead>
        <tbody>
    `;
    filteredExpenses.forEach(exp => {
      tableHtml += `
        <tr>
          <td style="font-weight: bold; color: #dc2626; font-family: monospace;">${exp.expenseNumber}</td>
          <td>${exp.date}</td>
          <td>${translate(exp.category)}</td>
          <td>${exp.description}</td>
          <td>${getStoreName(exp.storeId)}</td>
          <td>${exp.paymentMethod}</td>
          <td style="text-align: right; font-weight: bold;">${formatMoney(exp.amount, currency, exchangeRate)}</td>
        </tr>
      `;
    });
    tableHtml += `
          <tr style="background-color: #fef2f2; font-weight: bold;">
            <td colspan="6" style="text-align: right; padding: 10px;">Total Period Outflow:</td>
            <td style="text-align: right; color: #dc2626; padding: 10px;">${formatMoney(totalFilteredAmt, currency, exchangeRate)}</td>
          </tr>
        </tbody>
      </table>
    `;
    exportToExcel(tableHtml, `Expenses_Report_${new Date().toISOString().split('T')[0]}`);
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-col lg:flex-row gap-3 lg:items-center lg:justify-between no-print">
        <div className="flex flex-col sm:flex-row gap-3 flex-1">
          <div className="relative flex-1 max-w-xs">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search expenses..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-brand/20 outline-none"
            />
          </div>
          <select
            value={filterCategory}
            onChange={(e) => setFilterCategory(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white font-medium text-gray-700"
          >
            <option key="__all_categories__" value="">All Categories</option>
            {categories.map((c, cIdx) => (
              <option key={`exp-cat-${c}-${cIdx}`} value={c}>{c}</option>
            ))}
          </select>
          <select
            value={filterStoreId}
            onChange={(e) => setFilterStoreId(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white font-medium text-gray-700"
          >
            <option key="__all_stores__" value="all">{translate('All Stores & HQ')}</option>
            {activeStores.map((s, sIdx) => (
              <option key={s.id != null ? `exp-store-${s.id}-${sIdx}` : `exp-store-${sIdx}`} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleExportExcel}
            className="px-3 py-2 border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition whitespace-nowrap shadow-sm"
            title="Export directly to Excel"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-green-600" /> Export Excel
          </button>
          
          <button
            onClick={() => {
              handlePrintWithFallback((title, desc) => {
                setConfirmModal({
                  isOpen: true,
                  title: translate(title),
                  description: translate(desc),
                  onConfirm: () => {}
                });
              });
            }}
            className="px-3 py-2 border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition whitespace-nowrap shadow-sm"
            title="Print PDF of current view"
          >
            <Printer className="w-3.5 h-3.5 text-blue-600" /> Print PDF
          </button>

          <div className="bg-gray-50 border border-gray-200 rounded-lg px-3.5 py-1.5 text-right">
            <span className="text-[9px] font-bold text-gray-400 block tracking-wider uppercase">Outflow</span>
            <span className="text-xs font-black text-red-600">{formatMoney(totalFilteredAmt, currency, exchangeRate)}</span>
          </div>
          
          <button
            onClick={handleOpenAdd}
            className="bg-brand hover:bg-brand-hover text-white px-3.5 py-2 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition whitespace-nowrap shadow-sm"
          >
            <Plus className="w-4 h-4" /> Log Expense
          </button>
        </div>
      </div>

      {showAddForm && (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 max-w-2xl mx-auto">
          <h3 className="font-bold text-gray-900 text-sm mb-4 border-b pb-2">
            {editingExpenseId ? 'Modify Expense details' : 'Log New Expense'}
          </h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-semibold text-gray-700 mb-1 block">Expense Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white font-medium"
                >
                  {categories.map((c, cIdx) => (
                    <option key={`exp-form-cat-${c}-${cIdx}`} value={c}>{c}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-700 mb-1 block">Amount ({currency === 'TZS' ? 'TSh' : 'USD'})</label>
                <input
                  type="number"
                  step="any"
                  required
                  placeholder="Enter amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white font-mono font-medium"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-700 mb-1 block">Date</label>
                <input
                  type="date"
                  required
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white font-medium"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-gray-700 mb-1 block">Assigned Store</label>
                <select
                  value={storeId != null && !Number.isNaN(storeId as any) ? storeId : ''}
                  onChange={(e) => setStoreId(e.target.value === '' ? null : e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white font-medium"
                >
                  <option value="">{translate('General / HQ (All Stores)')}</option>
                  {activeStores.map(s => (
                    <option key={s.id} value={s.id}>{s.name}</option>
                  ))}
                </select>
              </div>

              <div className="md:col-span-2">
                <label className="text-xs font-semibold text-gray-700 mb-1 block">Payment Method</label>
                <div className="grid grid-cols-3 gap-2">
                  {(['Cash', 'Bank', 'Mobile Money'] as const).map(method => (
                    <button
                      key={method}
                      type="button"
                      onClick={() => setPaymentMethod(method)}
                      className={`py-2 border rounded-lg text-xs font-semibold transition cursor-pointer ${
                        paymentMethod === method
                          ? 'border-brand bg-brand-light text-brand'
                          : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                      }`}
                    >
                      {method}
                    </button>
                  ))}
                </div>

                {paymentMethod === 'Cash' && (
                  <div className="mt-3 p-3 rounded-xl border border-amber-200 bg-amber-50/80 flex items-start gap-3">
                    <input
                      type="checkbox"
                      id="paidFromDrawerFloat"
                      checked={paidFromDrawerFloat}
                      onChange={(e) => setPaidFromDrawerFloat(e.target.checked)}
                      className="mt-0.5 accent-amber-600 w-4 h-4 cursor-pointer rounded"
                    />
                    <label htmlFor="paidFromDrawerFloat" className="cursor-pointer text-xs text-amber-950 font-medium select-none">
                      <div className="font-bold flex items-center gap-1.5 text-amber-900">
                        <ArrowDownRight className="w-4 h-4 text-amber-600" />
                        {translate('Deduct directly from POS Register Cash Float')}
                      </div>
                      <div className="text-[11px] text-amber-800 mt-0.5 leading-relaxed">
                        {activeShiftForStore
                          ? `${translate('Connected to Active POS Shift')} #${activeShiftForStore.id} (${activeShiftForStore.username}). ${translate('Will automatically subtract from expected closing cash in drawer. No duplicate entry required!')}`
                          : translate('When an active shift is open for this store, cash is automatically deducted from the register drawer float.')}
                      </div>
                    </label>
                  </div>
                )}
              </div>

              <div className="md:col-span-2">
                <label className="text-xs font-semibold text-gray-700 mb-1 block">Description</label>
                <textarea
                  required
                  rows={2}
                  placeholder="Rent payment, electricity grid token, transport cost..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white"
                ></textarea>
              </div>

              {/* Receipt Attachment in Expense Form */}
              <div className="md:col-span-2 p-3.5 rounded-xl border border-gray-200 bg-gray-50/70 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Receipt className="w-4 h-4 text-brand" />
                    <label className="text-xs font-bold text-gray-800">
                      {translate('Receipt Attachment (Optional)')}
                    </label>
                  </div>
                  {receiptUrl && (
                    <button
                      type="button"
                      onClick={() => { setReceiptUrl(''); setReceiptName(''); }}
                      className="text-[11px] font-bold text-red-600 hover:underline inline-flex items-center gap-1"
                    >
                      <X className="w-3.5 h-3.5" /> {translate('Remove')}
                    </button>
                  )}
                </div>

                {receiptUrl ? (
                  <div className="flex items-center gap-3 bg-white p-2.5 rounded-lg border border-emerald-200">
                    {receiptUrl.startsWith('data:image/') || receiptUrl.startsWith('http') ? (
                      <img src={receiptUrl} alt="Receipt preview" className="w-14 h-14 object-cover rounded-md border border-gray-200" />
                    ) : (
                      <div className="w-14 h-14 rounded-md bg-emerald-50 text-emerald-600 flex items-center justify-center font-bold">
                        <FileText className="w-6 h-6" />
                      </div>
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 truncate">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                        <span className="truncate">{receiptName || 'receipt_attached.jpg'}</span>
                      </div>
                      <p className="text-[10px] text-gray-400 font-medium mt-0.5">
                        {translate('Ready to be linked with this expense record on save.')}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-wrap items-center gap-2">
                    <input
                      type="file"
                      ref={formFileInputRef}
                      onChange={handleFormReceiptFile}
                      accept="image/*,application/pdf"
                      className="hidden"
                    />
                    <button
                      type="button"
                      onClick={() => formFileInputRef.current?.click()}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 rounded-lg transition cursor-pointer shadow-2xs"
                    >
                      <Upload className="w-3.5 h-3.5 text-gray-500" />
                      {translate('Upload Receipt File')}
                    </button>
                    <button
                      type="button"
                      onClick={() => setFormCameraOpen(true)}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 rounded-lg transition cursor-pointer shadow-2xs"
                    >
                      <Camera className="w-3.5 h-3.5 text-brand" />
                      {translate('Capture with Camera')}
                    </button>
                    <span className="text-[11px] text-gray-400 font-medium ml-1">
                      {translate('Images & PDF up to 15MB')}
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-4 border-t">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={(e) => { (e as any).preventDefault?.(); void handleSubmit(e as any); }}
                className="px-5 py-2 bg-brand text-white rounded-lg text-sm font-semibold hover:bg-brand-hover"
              >
                Save Log
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-[13px] text-left">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr className="text-[11px] font-bold text-gray-600 uppercase tracking-wider">
                <th className="px-5 py-3">Expense ID</th>
                <th className="px-5 py-3">Date</th>
                <th className="px-5 py-3">Category</th>
                <th className="px-5 py-3">Description</th>
                <th className="px-5 py-3">Store Location</th>
                <th className="px-5 py-3">Payment Method</th>
                <th className="px-5 py-3 text-right">Amount</th>
                <th className="px-5 py-3 text-center">{translate('Receipt')}</th>
                <th className="px-5 py-3 w-24"></th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {paginatedExpenses.map((exp, expIdx) => (
                <tr key={exp.id != null ? `exp-row-${exp.id}-${expIdx}` : `exp-row-${expIdx}`} className="hover:bg-gray-50 transition-colors">
                  <td className="px-5 py-3 font-bold text-brand font-mono">{exp.expenseNumber}</td>
                  <td className="px-5 py-3 text-gray-500 whitespace-nowrap">{exp.date}</td>
                  <td className="px-5 py-3">
                    <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-100 text-amber-800">
                      {translate(exp.category)}
                    </span>
                  </td>
                  <td className="px-5 py-3 font-medium text-gray-900">{exp.description}</td>
                  <td className="px-5 py-3 text-gray-600">{getStoreName(exp.storeId)}</td>
                  <td className="px-5 py-3 text-gray-600 font-medium">
                    <div className="flex flex-col">
                      <span>{exp.paymentMethod}</span>
                      {exp.paidFromDrawerFloat && (
                        <span className="text-[10px] text-amber-700 font-mono font-bold flex items-center gap-0.5 mt-0.5">
                          <ArrowDownRight className="w-3 h-3 text-amber-600" />
                          {exp.posShiftId ? `Drawer Float (#${exp.posShiftId})` : 'Drawer Float'}
                        </span>
                      )}
                    </div>
                  </td>
                  <td className="px-5 py-3 text-right font-bold text-gray-900">
                    {formatMoney(exp.amount, currency, exchangeRate)}
                  </td>
                  <td className="px-5 py-3 text-center whitespace-nowrap">
                    {exp.receiptUrl ? (
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedExpenseForReceipt(exp);
                          setReceiptModalOpen(true);
                        }}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 hover:bg-emerald-100 transition cursor-pointer shadow-2xs"
                        title={translate('View linked receipt')}
                      >
                        <Receipt className="w-3.5 h-3.5 text-emerald-600" />
                        <span>{translate('Receipt')}</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedExpenseForReceipt(exp);
                          setReceiptModalOpen(true);
                        }}
                        className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg text-[11px] font-semibold text-gray-500 hover:text-brand hover:border-brand/40 hover:bg-gray-50 transition border border-dashed border-gray-200 cursor-pointer"
                        title={translate('Upload/capture expense receipt')}
                      >
                        <Upload className="w-3 h-3 text-gray-400" />
                        <span>{translate('Import')}</span>
                      </button>
                    )}
                  </td>
                  <td className="px-5 py-3">
                    <div className="flex items-center gap-1.5 justify-end">
                      {isAdmin && (
                        <button
                          onClick={() => handleOpenEdit(exp)}
                          className="p-1 hover:bg-gray-100 rounded text-blue-600"
                          title="Modify"
                        >
                          <Pencil className="w-4 h-4" />
                        </button>
                      )}
                      {isAdmin && (
                        <button
                          onClick={() => handleDelete(exp.id, exp.expenseNumber)}
                          className="p-1 hover:bg-red-50 rounded text-red-600"
                          title="Delete"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
              {filteredExpenses.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-5 py-8 text-center text-gray-400">
                    <AlertCircle className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                    No expenses logged for current store context.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
        {filteredExpenses.length > 0 && (
          <div className="p-3 border-t border-gray-100 flex flex-col sm:flex-row items-center justify-between gap-3 bg-gray-50/50">
            <span className="text-xs text-gray-500 font-medium">
              Showing <span className="font-bold text-gray-800">{(activePage - 1) * EXPENSES_PAGE_SIZE + 1}</span> to <span className="font-bold text-gray-800">{Math.min(activePage * EXPENSES_PAGE_SIZE, filteredExpenses.length)}</span> of <span className="font-bold text-gray-800">{filteredExpenses.length}</span> expenses
            </span>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                disabled={activePage <= 1}
                onClick={() => setCurrentPageNum(prev => Math.max(1, prev - 1))}
                className="px-2.5 py-1 text-xs font-semibold rounded border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition"
              >
                Previous
              </button>
              <span className="text-xs font-bold text-gray-700 px-2">
                {activePage} / {totalPages}
              </span>
              <button
                type="button"
                disabled={activePage >= totalPages}
                onClick={() => setCurrentPageNum(prev => Math.min(totalPages, prev + 1))}
                className="px-2.5 py-1 text-xs font-semibold rounded border border-gray-200 bg-white text-gray-700 hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition"
              >
                Next
              </button>
            </div>
          </div>
        )}
      </div>
      <ConfirmActionModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        description={confirmModal.description}
      />

      {/* Expense Receipt Modal */}
      {receiptModalOpen && selectedExpenseForReceipt && (
        <ExpenseReceiptModal
          expense={selectedExpenseForReceipt}
          isOpen={receiptModalOpen}
          onClose={() => {
            setReceiptModalOpen(false);
            setSelectedExpenseForReceipt(null);
          }}
          onSaveReceipt={handleSaveReceiptFromModal}
          onRemoveReceipt={handleRemoveReceiptFromModal}
          currency={currency}
          exchangeRate={exchangeRate}
          translate={translate}
        />
      )}

      {/* Camera Capture Modal for Add/Edit Form */}
      {formCameraOpen && (
        <ReceiptCameraModal
          open={formCameraOpen}
          onClose={() => setFormCameraOpen(false)}
          onCapture={(dataUrl) => {
            setReceiptUrl(dataUrl);
            setReceiptName(`expense_camera_${Date.now()}.jpg`);
            toast.success(translate('Receipt photo captured from camera.'));
          }}
          translate={translate}
        />
      )}
    </div>
  );
}
