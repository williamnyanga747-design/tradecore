import React, { useState, useEffect } from 'react';
import {
  Company, Branch, Store, Customer, Supplier, Tax, StockItem, User
} from '../types';
import { defaultTaxes } from '../initialData';
import {
  Plus, Pencil, Trash2, X, Store as StoreIcon, Database, RefreshCw, FileText, MessageSquare,
  Search, Loader2, Globe, Building2, CheckCircle2, AlertCircle, Copy, Lock, ShieldCheck, Download, Upload, Shield, Save
} from 'lucide-react';
import { formatMoney } from '../utils/format';
import { ConfirmActionModal } from './ConfirmActionModal';
import { AccountStatementModal } from './AccountStatementModal';
import { SmartMessagingModal } from './SmartMessagingModal';
import { performCascadeDelete } from '../utils/cascadeDelete';
import { toast } from '../utils/toast';
import { getStoreCategories, getCompanyCategories, formatCompanyCategory, formatStoreCategory, cleanCategoryName, parseCategoryScope } from '../utils/categoryHelper';
import { sv, sameId, getActiveCompanyScope } from '../utils/idUtils';
import { v2DeleteCategory, v2UpsertCategory } from '../utils/normalizedPersistence';
import LocationPicker from './marketplace/LocationPicker';
import { compressImageFile } from '../utils/imageCompression';

interface MasterDataProps {
  currentPage: string;
  companies: Company[];
  branches: Branch[];
  stores: Store[];
  customers: Customer[];
  suppliers: Supplier[];
  categories: string[];
  taxes: Tax[];
  stockItems: StockItem[];
  users: User[];
  currentCompanyId: string | number | null;
  currentBranchId: string | number | null;
  currentStoreId: string | number | null;
  isAdmin: boolean;
  isSuperAdmin: boolean;
  currency: string;
  exchangeRate: number;
  translate: (text: string) => string;
  logAction: (action: string, details: string) => void;
  saveAllData: (updatedFields: any) => void;
  refreshMasterData?: (tab: string) => void;
  addCompany?: (data: { name: string; [k: string]: unknown }) => Promise<string>;
  mutateRecord?: (collection: string, op: 'upsert' | 'delete', recordId: string | number, record: any) => Promise<boolean>;
  settings?: any;
  currentUser?: any;
  onNavigate?: (page: string) => void;
  salesOrders?: any[];
  purchaseOrders?: any[];
}

export default function MasterData({
  currentPage,
  companies,
  branches,
  stores,
  customers,
  suppliers,
  categories,
  taxes,
  stockItems,
  users,
  currentCompanyId,
  currentBranchId,
  currentStoreId,
  isAdmin,
  isSuperAdmin,
  currency,
  exchangeRate,
  translate: t,
  logAction,
  saveAllData,
  refreshMasterData,
  addCompany,
  mutateRecord,
  settings,
  currentUser,
  onNavigate,
  salesOrders = [],
  purchaseOrders = []
}: MasterDataProps) {
  const [editingItem, setEditingItem] = useState<{ type: string; data: any } | null>(null);
  const [showOnlyNoTin, setShowOnlyNoTin] = useState(false);
  const [activeStoreDetailsId, setActiveStoreDetailsId] = useState<number | null>(null);
  const [categoryFilterStore, setCategoryFilterStore] = useState<string>('');
  const [taxCompanyFilter, setTaxCompanyFilter] = useState<string>('all');

  const userAssignedBranchIds = React.useMemo(() => {
    const raw = [
      ...((currentUser as any)?.assignedBranchIds || []),
      ...((currentUser as any)?.branchIds || []),
      ...(currentUser?.branchId != null ? [currentUser.branchId] : [])
    ];
    return raw
      .map(id => sv(id))
      .filter((id, idx, arr) => id !== '' && id !== 'none' && arr.indexOf(id) === idx);
  }, [currentUser]);

  const isBranchAdmin = React.useMemo(() => {
    if (!currentUser) return false;
    const r = String(currentUser.role || '').toLowerCase().trim();
    return r === 'branch administrator' || r === 'branch admin';
  }, [currentUser]);

  const userAssignedStoreIds = React.useMemo(() => {
    const raw = [
      ...((currentUser as any)?.assignedStoreIds || []),
      ...((currentUser as any)?.storeIds || []),
      ...(currentUser?.storeId != null ? [currentUser.storeId] : []),
      ...(currentStoreId != null ? [currentStoreId] : [])
    ];
    return raw
      .map(id => sv(id))
      .filter((id, idx, arr) => id !== '' && id !== 'none' && id !== 'all' && arr.indexOf(id) === idx);
  }, [currentUser, currentStoreId]);

  const userCompanyId = (currentUser as any)?.companyId ?? (currentUser as any)?.company_id;
  const effectiveCompanyId = React.useMemo(() => {
    if (!isSuperAdmin && userCompanyId != null && String(userCompanyId) !== '' && String(userCompanyId) !== 'null' && String(userCompanyId) !== 'all') {
      return String(userCompanyId);
    }
    if (currentCompanyId != null && String(currentCompanyId) !== '' && String(currentCompanyId) !== 'all') {
      return String(currentCompanyId);
    }
    if (userCompanyId != null && String(userCompanyId) !== '' && String(userCompanyId) !== 'null' && String(userCompanyId) !== 'all') {
      return String(userCompanyId);
    }
    const stored = localStorage.getItem('active_company_id');
    if (stored && stored !== 'all' && companies.some(c => sameId(c.id, stored))) {
      return stored;
    }
    const firstActive = companies.find(c => !c.isDeleted);
    return firstActive?.id != null ? String(firstActive.id) : '1';
  }, [isSuperAdmin, userCompanyId, currentCompanyId, companies]);

  const storeCompanyId = (st: any): string => {
    if (!st) return '';
    const own = st.company_id ?? st.companyId;
    if (own != null && String(own) !== '' && String(own) !== 'none') return String(own);
    const br = branches.find(b => b && sameId(b.id, st.branchId));
    return br ? String((br as any).company_id ?? br.companyId ?? '') : '';
  };

  const activeCompanyStores = React.useMemo(() => {
    const coId = effectiveCompanyId;
    if (!coId) return stores.filter(s => !s.isDeleted);
    return stores.filter(s => {
      if (s.isDeleted) return false;
      if (isSuperAdmin) return true;
      return sameId(storeCompanyId(s), coId);
    });
  }, [stores, branches, effectiveCompanyId, isSuperAdmin]);

  // Allowed stores for the user to view/operate:
  // - Super Admin: all active stores
  // - Company Admin: all stores of their own company (activeCompanyStores)
  // - Branch Admin / Store User: only stores under their assigned branch(es) or store(s)
  const userAllowedStoreIds = React.useMemo(() => {
    if (isSuperAdmin) return null; // all stores permitted
    if (!isBranchAdmin && isAdmin) {
      // Company Admin
      return activeCompanyStores.map(s => sv(s.id));
    }
    // Branch Admin or Store Admin:
    const filtered = activeCompanyStores.filter(st => {
      if (userAssignedBranchIds.length > 0 && st.branchId) {
        return userAssignedBranchIds.some(bid => sameId(bid, st.branchId));
      }
      if (userAssignedStoreIds.length > 0) {
        return userAssignedStoreIds.some(sid => sameId(sid, st.id));
      }
      return true;
    }).map(s => sv(s.id));
    return filtered.length > 0 ? filtered : activeCompanyStores.map(s => sv(s.id));
  }, [isSuperAdmin, isBranchAdmin, isAdmin, activeCompanyStores, userAssignedBranchIds, userAssignedStoreIds]);

  const [statementModal, setStatementModal] = useState<{
    isOpen: boolean;
    entityType: 'customer' | 'supplier';
    entityId: number;
    name: string;
  }>({
    isOpen: false,
    entityType: 'customer',
    entityId: 0,
    name: ''
  });

  const [messagingModal, setMessagingModal] = useState<{
    isOpen: boolean;
    recipientName: string;
    recipientPhone: string;
    outstandingBalance: number;
  }>({
    isOpen: false,
    recipientName: '',
    recipientPhone: '',
    outstandingBalance: 0
  });

  const [localCompanyRates, setLocalCompanyRates] = useState<Record<number, string>>({});
  const [localUserRates, setLocalUserRates] = useState<Record<string, string>>({});
  const [localGlobalRate, setLocalGlobalRate] = useState<string>('');

  const [geoLoading, setGeoLoading] = useState(false);
  const [geoError, setGeoError] = useState('');

  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    description: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    description: '',
    onConfirm: () => {}
  });

  // Helper for money formatting
  const fmt = (amt: number) => formatMoney(amt, currency, exchangeRate);

  // DIRECT-MYSQL TAB LOAD (2026-09-08-12): opening System Companies / Branches / Stores
  // re-reads the collection straight from MySQL (superadmin = GLOBAL server-side scope).
  // No more "Filter per-company snapshot … skipping due to company_id mismatch" — the list
  // IS whatever the tradecore_companies / stores tables hold, refreshed on every tab open.
  useEffect(() => {
    if (refreshMasterData && (currentPage === 'companies' || currentPage === 'branches' || currentPage === 'stores' || currentPage === 'categories')) {
      refreshMasterData(currentPage);
    }
  }, [currentPage, refreshMasterData]);

  // BUILD 2026-09-08-19 (Required Fix 4): clear stale form/editing state on explicit
  // company switch so the user never continues editing a record of the PREVIOUS scope
  // (e.g. editing Company B's store details while viewing Company A).
  useEffect(() => {
    const onScopeChange = () => {
      setEditingItem(null);
      setShowOnlyNoTin(false);
      setActiveStoreDetailsId(null);
      setStatementModal(prev => ({ ...prev, isOpen: false }));
      setMessagingModal(prev => ({ ...prev, isOpen: false }));
      setConfirmModal(prev => ({ ...prev, isOpen: false }));
      setLocalCompanyRates({});
      setLocalUserRates({});
      setLocalGlobalRate('');
    };
    window.addEventListener('companyScopeChanged', onScopeChange);
    return () => window.removeEventListener('companyScopeChanged', onScopeChange);
  }, []);

  // --- DELETE HANDLERS ---
  const handleDeleteCompany = (id: number) => {
    if (!isSuperAdmin) {
      toast.error(t('Access Denied: Only Super Admins can delete a company.'));
      return;
    }
    const compName = companies.find(c => sameId(c.id, id))?.name || `ID ${id}`;
    setConfirmModal({
      isOpen: true,
      title: t('Delete Company'),
      description: `${t('Are you sure you want to delete company')} "${compName}"? ${t('This will soft-delete its accounts, branches, stores and stock.')}`,
      onConfirm: () => {
        const result = performCascadeDelete('company', id, {
          companies,
          branches,
          stores,
          users,
          stockItems,
          purchaseOrders: [],
          salesOrders: [],
          expenses: []
        });
        saveAllData({
          companies: result.companies,
          branches: result.branches,
          stores: result.stores,
          users: result.users,
          stockItems: result.stockItems
        });
        logAction('Delete Company', `Soft deleted Company ID: ${id}`);
      }
    });
  };

  const handleDeleteBranch = (id: number) => {
    if (isBranchAdmin) {
      toast.error(t('Access Denied: Branch Administrators cannot delete branches.'));
      return;
    }
    const targetBranch = branches.find(b => sameId(b.id, id));
    if (!isSuperAdmin && targetBranch && !sameId(targetBranch.companyId, effectiveCompanyId)) {
      toast.error(t('Access Denied: You cannot delete branches belonging to another company.'));
      return;
    }
    const brName = targetBranch?.name || `ID ${id}`;
    setConfirmModal({
      isOpen: true,
      title: t('Delete Branch'),
      description: `${t('Are you sure you want to delete branch')} "${brName}"? ${t('This will soft-delete associated stores.')}`,
      onConfirm: () => {
        const result = performCascadeDelete('branch', id, {
          companies,
          branches,
          stores,
          users,
          stockItems,
          purchaseOrders: [],
          salesOrders: [],
          expenses: []
        });
        saveAllData({
          companies: result.companies,
          branches: result.branches,
          stores: result.stores,
          users: result.users,
          stockItems: result.stockItems
        });
        logAction('Delete Branch', `Soft deleted Branch ID: ${id}`);
      }
    });
  };

  const handleDeleteStore = (id: number) => {
    const targetStore = stores.find(s => sameId(s.id, id));
    const storeCo = storeCompanyId(targetStore);
    if (!isSuperAdmin && targetStore && storeCo && !sameId(storeCo, effectiveCompanyId)) {
      toast.error(t('Access Denied: You cannot delete stores belonging to another company.'));
      return;
    }
    const stName = targetStore?.name || `ID ${id}`;
    setConfirmModal({
      isOpen: true,
      title: t('Delete Store'),
      description: `${t('Are you sure you want to delete store')} "${stName}"?`,
      onConfirm: () => {
        const result = performCascadeDelete('store', id, {
          companies,
          branches,
          stores,
          users,
          stockItems,
          purchaseOrders: [],
          salesOrders: [],
          expenses: []
        });
        saveAllData({
          companies: result.companies,
          branches: result.branches,
          stores: result.stores,
          users: result.users,
          stockItems: result.stockItems
        });
        logAction('Delete Store', `Soft deleted Store ID: ${id}`);
      }
    });
  };

  const handleDeleteCategory = (catName: string) => {
    const parsed = parseCategoryScope(catName);
    const cleanName = parsed.name || cleanCategoryName(catName);
    setConfirmModal({
      isOpen: true,
      title: t('Delete Category'),
      description: `${t('Are you sure you want to permanently delete category')} "${cleanName}"?`,
      onConfirm: async () => {
        const rawCo = sv(currentCompanyId);
        const cid = (rawCo && rawCo !== 'all')
          ? rawCo
          : (currentUser?.companyId ? sv(currentUser.companyId) : '1');
        if (cid) {
          const sqlOk = await v2DeleteCategory(cid, cleanName, parsed.storeId).catch((e) => { console.warn('[MasterData] v2DeleteCategory failed', e); return false; });
          if (!sqlOk) {
            toast.error(t('Delete failed — category was not removed. Please try again.'));
            return;
          }
        }
        const updatedCategories = categories.filter(c => {
          if (c === catName) return false;
          const p = parseCategoryScope(c);
          if (parsed.storeId) {
            return !(p.storeId === parsed.storeId && p.name.toLowerCase() === cleanName.toLowerCase());
          } else {
            return !(p.companyId === (parsed.companyId || cid) && !p.storeId && p.name.toLowerCase() === cleanName.toLowerCase());
          }
        });
        saveAllData({ categories: updatedCategories });
        logAction('Delete Category', `Deleted Category: ${cleanName}`);
      }
    });
  };

  const isGlobalTaxPolicy = (settings?.taxPolicyMode || 'global') === 'global';

  const handleToggleTaxPolicy = (newMode: 'global' | 'individual') => {
    if (!isSuperAdmin) {
      toast.error(t('Only Super Admin can change the Tax Policy mode'));
      return;
    }
    const currentGlobal = (settings?.globalTaxes && settings.globalTaxes.length > 0)
      ? settings.globalTaxes
      : (taxes.filter(t => t.isGlobal || !t.companyId).length > 0 ? taxes.filter(t => t.isGlobal || !t.companyId) : taxes);

    const updatedSettings = {
      ...settings,
      taxPolicyMode: newMode,
      globalTaxes: currentGlobal
    };
    saveAllData({ settings: updatedSettings });
    logAction('Tax Policy Mode Changed', `Super Admin set Tax Policy to ${newMode === 'global' ? 'GLOBAL (All Companies)' : 'INDIVIDUAL (Per-Company)'}`);
    toast.success(
      newMode === 'global'
        ? t('Global Tax Mode activated! All companies now use the unified global tax rates.')
        : t('Individual Tax Mode activated! Each company admin now configures their own independent tax rates.')
    );
  };

  const handleCopyGlobalRatesToCompany = (targetCid: string | number) => {
    const globalRates: Tax[] = (settings?.globalTaxes && settings.globalTaxes.length > 0)
      ? settings.globalTaxes
      : (taxes.filter(t => t.isGlobal || !t.companyId).length > 0 ? taxes.filter(t => t.isGlobal || !t.companyId) : taxes);

    const nextBaseId = Math.max(0, ...taxes.map(t => Number(t.id) || 0)) + 1;
    const clonedRates: Tax[] = globalRates.map((gt, idx) => ({
      ...gt,
      id: nextBaseId + idx,
      companyId: targetCid,
      isGlobal: false
    }));

    const updatedCompanyTaxes = {
      ...(settings?.companyTaxes || {}),
      [targetCid]: clonedRates
    };

    const otherTaxes = taxes.filter(t => !sameId(t.companyId, targetCid));
    saveAllData({
      taxes: [...otherTaxes, ...clonedRates],
      settings: {
        ...settings,
        companyTaxes: updatedCompanyTaxes
      }
    });

    const compName = companies.find(c => sameId(c.id, targetCid))?.name || `Company #${targetCid}`;
    logAction('Copy Global Tax Rates', `Copied global tax rates to ${compName}`);
    toast.success(t(`Global tax rates copied to ${compName} successfully!`));
  };

  const saveCompanyTaxes = (updatedTaxes: Tax[]) => {
    const compId = currentCompanyId ?? currentUser?.companyId ?? null;
    if (compId != null) {
      saveAllData({
        settings: {
          ...settings,
          companyTaxes: {
            ...(settings?.companyTaxes || {}),
            [compId]: updatedTaxes
          }
        }
      });
    } else {
      saveAllData({ taxes: updatedTaxes });
    }
  };

  const handleDeleteTax = (id: number) => {
    const tx = taxes.find(t => t.id === id) || (settings?.globalTaxes || []).find((t: any) => t.id === id);
    const txName = tx ? `${tx.name} (${tx.rate}%)` : `ID ${id}`;

    if (isGlobalTaxPolicy && !isSuperAdmin) {
      toast.error(t('Global tax rates can only be deleted by Super Admin'));
      return;
    }

    setConfirmModal({
      isOpen: true,
      title: t('Delete Tax Rate'),
      description: `${t('Are you sure you want to permanently delete tax rate')} "${txName}"?`,
      onConfirm: () => {
        if (isGlobalTaxPolicy) {
          const updatedTaxes = taxes.filter(t => t.id !== id);
          const updatedGlobal = (settings?.globalTaxes || taxes).filter((t: any) => t.id !== id);
          saveAllData({
            taxes: updatedTaxes,
            settings: { ...settings, globalTaxes: updatedGlobal }
          });
          logAction('Delete Global Tax', `Deleted Global Tax: ${txName}`);
        } else {
          const targetCid = tx?.companyId ?? (taxCompanyFilter !== 'all' ? taxCompanyFilter : (currentCompanyId ?? currentUser?.companyId ?? null));
          const existingComp = (settings?.companyTaxes?.[targetCid] || taxes.filter(t => sameId(t.companyId, targetCid)));
          const updatedComp = existingComp.filter((t: any) => t.id !== id);
          const updatedAll = taxes.filter(t => t.id !== id);

          saveAllData({
            taxes: updatedAll,
            settings: {
              ...settings,
              companyTaxes: {
                ...(settings?.companyTaxes || {}),
                ...(targetCid ? { [targetCid]: updatedComp } : {})
              }
            }
          });
          logAction('Delete Company Tax', `Deleted Tax ID: ${id} for Company #${targetCid}`);
        }
        toast.success(t('Tax rate deleted successfully'));
      }
    });
  };

  const handleDeleteCustomer = (id: number) => {
    const cust = customers.find(c => sameId(c.id, id));
    const custName = cust ? cust.name : `ID ${id}`;
    setConfirmModal({
      isOpen: true,
      title: t('Delete Customer'),
      description: `${t('Are you sure you want to delete customer')} "${custName}"?`,
      onConfirm: () => {
        const updatedCustomers = customers.filter(c => !sameId(c.id, id));
        saveAllData({ customers: updatedCustomers });
        logAction('Delete Customer', `Deleted Customer ID: ${id}`);
      }
    });
  };

  const handleDeleteSupplier = (id: number) => {
    const sup = suppliers.find(s => sameId(s.id, id));
    const supName = sup ? sup.name : `ID ${id}`;
    setConfirmModal({
      isOpen: true,
      title: t('Delete Supplier'),
      description: `${t('Are you sure you want to delete supplier')} "${supName}"?`,
      onConfirm: () => {
        const updatedSuppliers = suppliers.filter(s => !sameId(s.id, id));
        saveAllData({ suppliers: updatedSuppliers });
        logAction('Delete Supplier', `Deleted Supplier ID: ${id}`);
      }
    });
  };

  // --- RESTORE HANDLERS ---
  const handleRestoreCompany = (id: number) => {
    const updatedCompanies = companies.map(c => sameId(c.id, id) ? { ...c, isDeleted: false } : c);
    const companyBranches = branches.filter(b => sameId(b.companyId, id)).map(b => b.id);
    const updatedBranches = branches.map(b => sameId(b.companyId, id) ? { ...b, isDeleted: false } : b);
    const updatedStores = stores.map(s => companyBranches.includes(s.branchId) ? { ...s, isDeleted: false } : s);

    saveAllData({
      companies: updatedCompanies,
      branches: updatedBranches,
      stores: updatedStores
    });
    logAction('Restore Company', `Restored Company ID: ${id} and its branches & stores`);
  };

  const handleRestoreBranch = (id: number) => {
    const updatedBranches = branches.map(b => b.id === id ? { ...b, isDeleted: false } : b);
    const updatedStores = stores.map(s => sameId(s.branchId, id) ? { ...s, isDeleted: false } : s);

    saveAllData({
      branches: updatedBranches,
      stores: updatedStores
    });
    logAction('Restore Branch', `Restored Branch ID: ${id} and its stores`);
  };

  const handleRestoreStore = (id: number) => {
    const updatedStores = stores.map(s => s.id === id ? { ...s, isDeleted: false } : s);

    saveAllData({
      stores: updatedStores
    });
    logAction('Restore Store', `Restored Store ID: ${id}`);
  };

  const handlePermanentDeleteCompany = (id: number) => {
    setConfirmModal({
      isOpen: true,
      title: t('Permanent Delete Company'),
      description: t('Are you sure you want to permanently delete this company? This will also permanently remove all its branches and stores. This action is irreversible.'),
      onConfirm: () => {
        const updatedCompanies = companies.filter(c => c.id !== id);
        const deletedBranchesInCompany = branches.filter(b => sameId(b.companyId, id)).map(b => b.id);
        const updatedBranches = branches.filter(b => b.companyId !== id);
        const updatedStores = stores.filter(s => !deletedBranchesInCompany.includes(s.branchId));
        saveAllData({ 
          companies: updatedCompanies,
          branches: updatedBranches,
          stores: updatedStores
        });
        logAction('Permanent Delete Company', `Permanently deleted Company ID: ${id}`);
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handlePermanentDeleteBranch = (id: number) => {
    setConfirmModal({
      isOpen: true,
      title: t('Permanent Delete Branch'),
      description: t('Are you sure you want to permanently delete this branch? This will also permanently remove all its stores. This action is irreversible.'),
      onConfirm: () => {
        const updatedBranches = branches.filter(b => b.id !== id);
        const updatedStores = stores.filter(s => s.branchId !== id);
        saveAllData({ 
          branches: updatedBranches,
          stores: updatedStores
        });
        logAction('Permanent Delete Branch', `Permanently deleted Branch ID: ${id}`);
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  const handlePermanentDeleteStore = (id: number) => {
    setConfirmModal({
      isOpen: true,
      title: t('Permanent Delete Store'),
      description: t('Are you sure you want to permanently delete this store? This action is irreversible.'),
      onConfirm: () => {
        const updatedStores = stores.filter(s => s.id !== id);
        saveAllData({ 
          stores: updatedStores
        });
        logAction('Permanent Delete Store', `Permanently deleted Store ID: ${id}`);
        setConfirmModal(prev => ({ ...prev, isOpen: false }));
      }
    });
  };

  // --- SAVE HANDLERS FOR FORMS ---
  const handleSave = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const { type, data } = editingItem;

    if (type === 'company') {
      const coLang = data.language || 'en';
      const coCurr = data.currency || 'USD';
      const coRate = data.exchangeRate !== undefined ? Number(data.exchangeRate) : 1;
      const subEnd = data.subscriptionEnd || data.subscription_end || '';
      const coThemeColor = data.themeColor || data.theme_color || '#c41e3a';
      const cleanCompany = {
        ...data,
        themeColor: coThemeColor,
        theme_color: coThemeColor,
        subscriptionEnd: subEnd,
        subscription_end: subEnd,
        language: coLang,
        currency: coCurr,
        exchangeRate: coRate
      };

      if (data.id) {
        // Edit
        const compId = data.id;
        const updated = companies.map(c => sameId(c.id, compId) ? { ...c, ...cleanCompany } : c);
        const nextSettings = {
          ...settings,
          companyLanguages: { ...(settings?.companyLanguages || {}), [compId]: coLang },
          companyCurrencies: { ...(settings?.companyCurrencies || {}), [compId]: coCurr },
          companyExchangeRates: { ...(settings?.companyExchangeRates || {}), [compId]: coRate }
        };
        saveAllData({ companies: updated, settings: nextSettings });
        if (mutateRecord) {
          mutateRecord('companies', 'upsert', compId, cleanCompany).catch(() => {});
        }
        toast.success(t('Company updated successfully!'));
        logAction('Edit Company', `Modified Company details for: ${data.name}`);
      } else {
        // Create — DIRECT MySQL via addCompany (2026-09-08-13): explicit awaited
        // v2_upsert_company POST + GLOBAL v2_list_companies re-fetch so the new
        // row is visible to ALL users and survives reload. Falls back to old
        // saveAllData path if addCompany prop is not provided.
        if (addCompany) {
          try {
            const newId = await addCompany(cleanCompany);
            const newCo: any = {
              ...cleanCompany,
              id: newId,
              company_id: newId,
              is_default: false,
              created_by: 'root_mandate'
            };
            const nextCompanies = companies.some(c => sameId(c.id, newId))
              ? companies.map(c => sameId(c.id, newId) ? { ...c, ...newCo } : c)
              : [...companies, newCo];
            const nextSettings = {
              ...settings,
              companyLanguages: { ...(settings?.companyLanguages || {}), [newId]: coLang },
              companyCurrencies: { ...(settings?.companyCurrencies || {}), [newId]: coCurr },
              companyExchangeRates: { ...(settings?.companyExchangeRates || {}), [newId]: coRate }
            };
            saveAllData({ companies: nextCompanies, settings: nextSettings });
            toast.success(t('Company registered successfully!'));
            logAction('Create Company', `Registered new Company: ${data.name} (id=${newId})`);
          } catch (e: any) {
            console.error('[MasterData] addCompany failed', e);
            toast.error(t('Failed to save company: ') + (e?.message || String(e)));
            const nextId = (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : `co_${Date.now()}`;
            const newCo: any = {
              ...cleanCompany,
              id: nextId,
              company_id: nextId,
              is_default: false,
              created_by: 'root_mandate'
            };
            const nextCompanies = [...companies, newCo];
            const nextSettings = {
              ...settings,
              companyLanguages: { ...(settings?.companyLanguages || {}), [nextId]: coLang },
              companyCurrencies: { ...(settings?.companyCurrencies || {}), [nextId]: coCurr },
              companyExchangeRates: { ...(settings?.companyExchangeRates || {}), [nextId]: coRate }
            };
            saveAllData({ companies: nextCompanies, settings: nextSettings });
          }
        } else {
          const nextId = Math.max(0, ...companies.map(c => Number(c.id) || 0)) + 1;
          const newCo: any = {
            ...cleanCompany,
            id: nextId,
            company_id: nextId,
            is_default: false,
            created_by: 'root_mandate'
          };
          const nextSettings = {
            ...settings,
            companyLanguages: { ...(settings?.companyLanguages || {}), [nextId]: coLang },
            companyCurrencies: { ...(settings?.companyCurrencies || {}), [nextId]: coCurr },
            companyExchangeRates: { ...(settings?.companyExchangeRates || {}), [nextId]: coRate }
          };
          saveAllData({ companies: [...companies, newCo], settings: nextSettings });
          toast.success(t('Company registered successfully!'));
          logAction('Create Company', `Registered new Company: ${data.name}`);
        }
      }
    } else if (type === 'branch') {
      if (isBranchAdmin) {
        toast.error(t('Access Denied: Branch Administrators cannot create or edit branches.'));
        return;
      }
      const userCo = (currentUser as any)?.companyId ?? (currentUser as any)?.company_id;
      const targetCoId = !isSuperAdmin && userCo != null && String(userCo) !== '' && String(userCo) !== 'null'
        ? String(userCo)
        : (data.companyId !== undefined && data.companyId !== null && data.companyId !== '' && String(data.companyId) !== 'NaN' && String(data.companyId) !== '0'
          ? String(data.companyId)
          : effectiveCompanyId);
      const parsedCoId = String(targetCoId);
      const cleanData = { ...data, companyId: parsedCoId, company_id: parsedCoId };
      if (data.id) {
        const updated = branches.map(b => sameId(b.id, data.id) ? cleanData : b);
        saveAllData({ branches: updated });
        logAction('Edit Branch', `Modified Branch details for: ${data.name}`);
      } else {
        const nextId = Math.max(0, ...branches.map(b => b.id)) + 1;
        const newBranch = { ...cleanData, id: nextId };
        saveAllData({ branches: [...branches, newBranch] });
        logAction('Create Branch', `Registered new Branch: ${data.name}`);
      }
    } else if (type === 'store') {
      // BUILD 2026-09-08-18: branch ids are strings too — parse as string, never NaN.
      const parsedBranchId = sv(data.branchId) || sv(currentBranchId) || '1';
      // Normalize Multi-Store Location Mapping fields before persisting (saved via the JSON blob).
      const lat = parseFloat(data.latitude);
      const lng = parseFloat(data.longitude);
      const isMarketplaceVisible = data.isMarketplaceVisible !== false;
      const userCo = (currentUser as any)?.companyId ?? (currentUser as any)?.company_id;
      const targetStoreCoId = !isSuperAdmin && userCo != null && String(userCo) !== '' && String(userCo) !== 'null'
        ? String(userCo)
        : (sv(data.company_id ?? data.companyId) || (() => {
            const ownerBranch = branches.find(b => sameId(b.id, parsedBranchId));
            return sv(ownerBranch?.companyId) || effectiveCompanyId;
          })());
      const cleanData = {
        ...data,
        location: data.location || data.addressText || '',
        landmark: data.landmark || '',
        addressText: data.addressText || data.landmark || data.location || '',
        branchId: parsedBranchId,
        company_id: targetStoreCoId,
        companyId: targetStoreCoId,
        latitude: Number.isFinite(lat) ? lat : undefined,
        longitude: Number.isFinite(lng) ? lng : undefined,
        googleMapsUrl: typeof data.googleMapsUrl === 'string' && data.googleMapsUrl.trim() ? data.googleMapsUrl.trim() : undefined,
        operatingHours: typeof data.operatingHours === 'string' && data.operatingHours.trim() ? data.operatingHours.trim() : undefined,
        isMarketplaceVisible
      };
      if (data.id) {
        const updated = stores.map(s => sameId(s.id, data.id) ? cleanData : s);
        saveAllData({ stores: updated });
        logAction('Edit Store', `Modified Store details for: ${data.name}`);
      } else {
        const nextId = Math.max(0, ...stores.map(s => Number(s.id) || 0)) + 1;
        const newStore = { ...cleanData, id: nextId };
        // Seed store stock value 0 for all items
        const updatedStock = stockItems.map(p => ({
          ...p,
          stock: { ...p.stock, [nextId]: 0 }
        }));
        saveAllData({
          stores: [...stores, newStore],
          stockItems: updatedStock
        });
        logAction('Create Store', `Registered new Store: ${data.name}`);
      }
    } else if (type === 'customer') {
      const limit = parseFloat(data.creditLimitDisplay) || 0;
      const bal = parseFloat(data.balanceDisplay) || 0;
      // Convert to local system units (USD)
      const creditLimit = currency === 'TZS' ? limit / exchangeRate : limit;
      const balance = currency === 'TZS' ? bal / exchangeRate : bal;

      const cleanData = { ...data, creditLimit, balance };
      delete cleanData.creditLimitDisplay;
      delete cleanData.balanceDisplay;

      if (data.id) {
        // BUILD 2026-09-08-19 (Fix 1): ensure the OWNING company scope survives edits —
        // a record loaded without company_id (legacy/global rows) must not lose its
        // scope when written back through the DIRECT delta; tag the active scope.
        const editData = { ...cleanData, company_id: sv(cleanData.company_id ?? cleanData.companyId) || getActiveCompanyScope(currentCompanyId, currentUser) };
        const updated = customers.map(c => sameId(c.id, data.id) ? editData : c);
        saveAllData({ customers: updated });
        logAction('Edit Customer', `Modified Customer parameters for: ${data.name}`);
      } else {
        const nextId = Math.max(0, ...customers.map(c => Number(c.id) || 0)) + 1;
        // BUILD 2026-09-08-18/19: tag the record with its owning company id as a string
        // (resolved at submission time — never hardcode '1'). Cross-company globals then
        // never host orphaned customer rows reachable by no scope.
        const newCust = { ...cleanData, id: nextId, company_id: sv(currentCompanyId) || getActiveCompanyScope(currentCompanyId, currentUser) };
        saveAllData({ customers: [...customers, newCust] });
        logAction('Create Customer', `Registered new Customer: ${data.name}`);
      }
    } else if (type === 'supplier') {
      if (data.id) {
        const editData = { ...data, company_id: sv(data.company_id ?? data.companyId) || getActiveCompanyScope(currentCompanyId, currentUser) };
        const updated = suppliers.map(s => sameId(s.id, data.id) ? editData : s);
        saveAllData({ suppliers: updated });
        logAction('Edit Supplier', `Modified Supplier parameters for: ${data.name}`);
      } else {
        const nextId = Math.max(0, ...suppliers.map(s => Number(s.id) || 0)) + 1;
        const newSupplier = { ...data, id: nextId, company_id: sv(data.company_id ?? data.companyId) || sv(currentCompanyId) || getActiveCompanyScope(currentCompanyId, currentUser) };
        saveAllData({ suppliers: [...suppliers, newSupplier] });
        logAction('Create Supplier', `Registered new Supplier: ${data.name}`);
      }
    } else if (type === 'category') {
      if (!data.name?.trim()) return;
      const cleanName = cleanCategoryName(data.name.trim());
      const targetStoreId = data.storeId !== undefined && data.storeId !== '' ? String(data.storeId) : (categoryFilterStore || '');
      const assignedStore = targetStoreId ? stores.find(s => sameId(s.id, targetStoreId)) : null;
      const storeCoId = assignedStore?.companyId ? sv(assignedStore.companyId) : null;
      const rawCo = sv(currentCompanyId);
      const coId = storeCoId || ((rawCo && rawCo !== 'all')
        ? rawCo
        : (currentUser?.companyId ? sv(currentUser.companyId) : (companies.find(c => !c.isDeleted)?.id ? sv(companies.find(c => !c.isDeleted)!.id) : '1')));

      // Drop any null/empty/legacy entries so a malformed categories array can never
      // crash the filter or leak `null` into the persisted blob.
      const safeCats = (categories || []).filter(c => c && typeof c === 'string' && c.trim());
      const newCatName = targetStoreId
        ? formatStoreCategory(cleanName, targetStoreId, coId)
        : formatCompanyCategory(cleanName, coId);

      if (safeCats.some(c => c === newCatName)) {
        toast.warning(t('Category already exists!'));
        return;
      }
      // Call direct v2UpsertCategory so MySQL database is updated immediately
      try {
        await v2UpsertCategory(coId, cleanName, undefined, targetStoreId || undefined);
      } catch (err) {
        console.warn('[MasterData] v2UpsertCategory direct call error:', err);
      }
      // Persist immediately + synchronize with backend (both scoped key and clean name for seamless stock dropdowns)
      const mergedNextCats = Array.from(new Set([...safeCats, newCatName, cleanName]));
      await saveAllData({
        categories: mergedNextCats
      });
      logAction('Create Category', `Created Category: ${cleanName}${targetStoreId ? ` for Store #${targetStoreId}` : ''}`);
      toast.success(t('Category created successfully!'));
    } else if (type === 'tax') {
      const isGlobalPolicy = (settings?.taxPolicyMode || 'global') === 'global';
      if (isGlobalPolicy && !isSuperAdmin) {
        toast.error(t('Global tax rates can only be modified by Super Admin'));
        setEditingItem(null);
        return;
      }
      const rate = parseFloat(data.rate) || 0;
      const taxName = (data.name || '').trim();
      if (!taxName) {
        toast.error(t('Tax Name is required'));
        return;
      }

      if (isGlobalPolicy) {
        // Global tax rate:
        const cleanData: Tax = {
          ...data,
          name: taxName,
          rate,
          type: 'Percentage',
          storeId: data.storeId || null,
          companyId: null,
          isGlobal: true
        };

        const currentGlobalList: Tax[] = (settings?.globalTaxes && settings.globalTaxes.length > 0)
          ? settings.globalTaxes
          : (taxes.filter(t => t.isGlobal || !t.companyId).length > 0 ? taxes.filter(t => t.isGlobal || !t.companyId) : taxes);

        let updatedGlobal: Tax[];
        let updatedAll: Tax[];

        if (data.id) {
          updatedGlobal = currentGlobalList.map(t => t.id === data.id ? cleanData : t);
          updatedAll = taxes.map(t => t.id === data.id ? cleanData : t);
          logAction('Edit Global Tax', `Modified global tax: ${cleanData.name} (${cleanData.rate}%)`);
        } else {
          const nextId = Math.max(0, ...taxes.map(t => Number(t.id) || 0), ...(currentGlobalList.map(t => Number(t.id) || 0))) + 1;
          const newTax: Tax = { ...cleanData, id: nextId };
          updatedGlobal = [...currentGlobalList, newTax];
          updatedAll = [...taxes, newTax];
          logAction('Create Global Tax', `Registered new global tax: ${cleanData.name} (${cleanData.rate}%)`);
        }

        saveAllData({
          taxes: updatedAll,
          settings: {
            ...settings,
            taxPolicyMode: 'global',
            globalTaxes: updatedGlobal
          }
        });
        toast.success(t('Global tax rate saved successfully!'));
      } else {
        // Individual / Independent Mode:
        const targetCid = data.companyId || (taxCompanyFilter !== 'all' ? taxCompanyFilter : null) || currentCompanyId || currentUser?.companyId || (companies.length > 0 ? companies[0].id : null);
        if (!targetCid) {
          toast.error(t('Please select a company for this tax rate'));
          return;
        }

        const cleanData: Tax = {
          ...data,
          name: taxName,
          rate,
          type: 'Percentage',
          storeId: data.storeId || null,
          companyId: targetCid,
          isGlobal: false
        };

        const existingCompTaxes: Tax[] = (settings?.companyTaxes?.[targetCid] && settings.companyTaxes[targetCid].length > 0)
          ? settings.companyTaxes[targetCid]
          : taxes.filter(t => sameId(t.companyId, targetCid));

        let updatedCompTaxes: Tax[];
        let updatedAllTaxes: Tax[];

        if (data.id) {
          updatedCompTaxes = existingCompTaxes.map(t => t.id === data.id ? cleanData : t);
          updatedAllTaxes = taxes.map(t => t.id === data.id ? cleanData : t);
          logAction('Edit Company Tax', `Modified tax for Company #${targetCid}: ${cleanData.name} (${cleanData.rate}%)`);
        } else {
          const nextId = Math.max(0, ...taxes.map(t => Number(t.id) || 0), ...(existingCompTaxes.map(t => Number(t.id) || 0))) + 1;
          const newTax: Tax = { ...cleanData, id: nextId };
          updatedCompTaxes = [...existingCompTaxes, newTax];
          updatedAllTaxes = [...taxes, newTax];
          logAction('Create Company Tax', `Created tax for Company #${targetCid}: ${cleanData.name} (${cleanData.rate}%)`);
        }

        saveAllData({
          taxes: updatedAllTaxes,
          settings: {
            ...settings,
            taxPolicyMode: 'individual',
            companyTaxes: {
              ...(settings?.companyTaxes || {}),
              [targetCid]: updatedCompTaxes
            }
          }
        });
        toast.success(t('Company tax rate saved successfully!'));
      }
    }

    setEditingItem(null);
  };

  // --- RENDER CONTENT BY currentPage ---
  const content = (() => {
    switch (currentPage) {
    case 'companies':
      if (!isSuperAdmin) {
        return <div className="p-4 bg-red-100 text-red-800 rounded-lg">{t('Access Denied')}</div>;
      }
      return (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm max-w-4xl mx-auto">
          <div className="p-4 border-b flex items-center justify-between">
            <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
              <Database className="w-4 h-4 text-brand" />
              {t('System Companies')}
            </h3>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowOnlyNoTin(!showOnlyNoTin)}
                className={`px-3 py-2 rounded-lg text-xs font-bold border transition inline-flex items-center gap-1.5 ${
                  showOnlyNoTin ? 'bg-red-500 text-white border-red-500' : 'bg-white text-red-600 border-red-200 hover:bg-red-50'
                }`}
                title={t('Companies without a TIN')}
              >
                {t('No TIN')} ({companies.filter(c => !c.isDeleted && !c.tinNumber).length})
              </button>
              {isSuperAdmin && (
                <button
                  onClick={() => setEditingItem({ type: 'company', data: { name: '' } })}
                  className="bg-brand text-white px-3.5 py-2 rounded-lg text-xs font-bold hover:bg-brand-hover flex items-center gap-1.5 transition"
                >
                  <Plus className="w-3.5 h-3.5" /> {t('Add Company')}
                </button>
              )}
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[13px] text-left">
              <thead className="bg-gray-50 border-b text-gray-500 text-[10px] uppercase font-bold tracking-wider">
                <tr>
                  <th className="px-6 py-3">{t('Company Name')}</th>
                  <th className="px-6 py-3">{t('TIN')}</th>
                  <th className="px-6 py-3">{t('Allocated Admins')}</th>
                  <th className="px-6 py-3">{t('Subscription End')}</th>
                  <th className="px-6 py-3">{t('Status')}</th>
                  <th className="px-6 py-3 w-32 text-right"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {(isSuperAdmin
                  ? companies.filter(c => !c.isDeleted && (!showOnlyNoTin || !c.tinNumber))
                  : companies.filter(c => !c.isDeleted && sameId(c.id, effectiveCompanyId))
                ).map(c => {
                  const admins = users
                    .filter(u => u.role === 'Admin' && sameId(u.companyId, c.id))
                    .map(u => u.name)
                    .join(', ') || t('No admins assigned');
                  
                  const isApproved = c.subscriptionApproved !== false;
                  const todayStr = new Date().toISOString().split('T')[0];
                  const isExpired = c.subscriptionEnd ? todayStr > c.subscriptionEnd : false;
                  
                  return (
                    <tr key={c.id} className="hover:bg-gray-50/50">
                      <td className="px-6 py-4 font-bold text-gray-900 flex items-center gap-3">
                        {c.logoUrl ? (
                          <img src={c.logoUrl} alt="Logo" className="w-8 h-8 rounded-lg object-contain bg-gray-50 border border-gray-200" referrerPolicy="no-referrer" />
                        ) : (
                          <div className="w-8 h-8 rounded-lg bg-brand/10 text-brand flex items-center justify-center font-bold text-xs">
                            {(c.name || '?').charAt(0).toUpperCase()}
                          </div>
                        )}
                        <span>{c.name}</span>
                      </td>
                      <td className="px-6 py-4">
                        {c.tinNumber ? (
                          <div className="flex items-center gap-1.5">
                            <span className="font-mono text-xs font-bold text-gray-700">{c.tinNumber}</span>
                            {c.tinVerified && (
                              <span className="bg-emerald-100 text-emerald-700 px-1.5 py-0.5 rounded text-[9px] font-black uppercase">✓</span>
                            )}
                          </div>
                        ) : (
                          <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase">{t('No TIN')}</span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-gray-500 font-semibold">{admins}</td>
                      <td className="px-6 py-4 font-mono text-xs text-gray-600">
                        {c.subscriptionEnd ? c.subscriptionEnd : t('Unlimited')}
                      </td>
                      <td className="px-6 py-4">
                        {!isApproved ? (
                          <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase">
                            {t('Payment Pending')}
                          </span>
                        ) : isExpired ? (
                          <span className="bg-amber-100 text-amber-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase">
                            {t('Expired')}
                          </span>
                        ) : (
                          <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-[10px] font-bold uppercase">
                            {t('Active')}
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <div className="flex justify-end gap-1.5">
                          <button
                            onClick={() => setEditingItem({ type: 'company', data: c })}
                            className="p-1 px-2 text-[10px] font-bold rounded border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 transition inline-flex items-center gap-1"
                            title={t('Edit')}
                          >
                            <Pencil className="w-3.5 h-3.5" />
                            {t('Edit')}
                          </button>
                          {isSuperAdmin && (
                            <button
                              onClick={() => handleDeleteCompany(c.id)}
                              className="p-1 px-2 text-[10px] font-bold rounded border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 transition inline-flex items-center gap-1"
                              title={t('Delete')}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              {t('Delete')}
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {renderEditModal()}
        </div>
      );

    case 'branches':
      const branchData = (isSuperAdmin
        ? branches
        : branches.filter(b => {
            if (!b || b.isDeleted) return false;
            if (!sameId(b.companyId, effectiveCompanyId)) return false;
            if (userAssignedBranchIds.length > 0) {
              return userAssignedBranchIds.some(bid => sameId(bid, b.id));
            }
            return true;
          })
      ).filter(b => !b.isDeleted);

      return (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm max-w-4xl mx-auto">
          <div className="p-4 border-b flex items-center justify-between">
            <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
              <Database className="w-4 h-4 text-brand" />
              {t('Branches')}
            </h3>
            {isBranchAdmin ? (
              <span className="text-[11px] font-semibold text-amber-700 bg-amber-50 px-2.5 py-1.5 rounded-lg border border-amber-200 flex items-center gap-1.5">
                <Database className="w-3.5 h-3.5" />
                {t('Branch Read-Only (Branch Administrator)')}
              </span>
            ) : (
              <button
                onClick={() => setEditingItem({ type: 'branch', data: { name: '', companyId: effectiveCompanyId, company_id: effectiveCompanyId } })}
                className="bg-brand text-white px-3.5 py-2 rounded-lg text-xs font-bold hover:bg-brand-hover flex items-center gap-1.5 transition"
              >
                <Plus className="w-3.5 h-3.5" /> {t('Add Branch')}
              </button>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[13px] text-left">
              <thead className="bg-gray-50 border-b text-gray-500 text-[10px] uppercase font-bold tracking-wider">
                <tr>
                  <th className="px-6 py-3">{t('Branch Name')}</th>
                  <th className="px-6 py-3">{t('Company Parent')}</th>
                  <th className="px-6 py-3 text-center">{t('Total Stores')}</th>
                  <th className="px-6 py-3 w-32 text-right"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {branchData.map(b => {
                  const compName = companies.find(c => sameId(c.id, b.companyId))?.name || 'N/A';
                  const storeCount = stores.filter(s => sameId(s.branchId, b.id)).length;
                  return (
                    <tr key={b.id} className="hover:bg-gray-50/50">
                      <td className="px-6 py-4 font-bold text-gray-900">{b.name}</td>
                      <td className="px-6 py-4 text-gray-500 font-semibold">{compName}</td>
                      <td className="px-6 py-4 text-center font-bold text-gray-700">{storeCount}</td>
                      <td className="px-6 py-4 text-right">
                        {!isBranchAdmin ? (
                          <div className="flex justify-end gap-1.5">
                            <button
                              onClick={() => {
                                if (!isSuperAdmin && !sameId(b.companyId, effectiveCompanyId)) {
                                  toast.error(t('Access Denied: You cannot edit branches of another company.'));
                                  return;
                                }
                                setEditingItem({ type: 'branch', data: b });
                              }}
                              className="p-1 px-2 text-[10px] font-bold rounded border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 transition inline-flex items-center gap-1"
                              title={t('Edit')}
                            >
                              <Pencil className="w-3.5 h-3.5" />
                              {t('Edit')}
                            </button>
                            <button
                              onClick={() => handleDeleteBranch(b.id)}
                              className="p-1 px-2 text-[10px] font-bold rounded border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 transition inline-flex items-center gap-1"
                              title={t('Delete')}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              {t('Delete')}
                            </button>
                          </div>
                        ) : (
                          <span className="text-[10px] text-gray-400 font-semibold italic">{t('View only')}</span>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {renderEditModal()}
        </div>
      );

    case 'stores':
      const activeCompanyId = effectiveCompanyId;
      const allowedBranches = branches
        .filter(b => {
          if (!b || b.isDeleted) return false;
          if (isSuperAdmin) return true;
          const matchCo = sameId(b.companyId, activeCompanyId);
          if (!matchCo) return false;
          if (userAssignedBranchIds.length > 0) {
            return userAssignedBranchIds.some(bid => sameId(bid, b.id));
          }
          return true;
        })
        .map(b => b.id);
      const storeData = stores.filter(s => {
        // Defensive guard (Req 5): a null/malformed store row must never crash the filter.
        if (!s || s.isDeleted) return false;
        if (isSuperAdmin) return true;
        if (!sameId(storeCompanyId(s), activeCompanyId)) return false;
        if (userAssignedBranchIds.length > 0 && s.branchId) {
          return userAssignedBranchIds.some(bid => sameId(bid, s.branchId));
        }
        return true;
      });

      return (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="p-4 border-b flex items-center justify-between">
            <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
              <StoreIcon className="w-4 h-4 text-brand" />
              {t('Store Management')}
            </h3>
            {isAdmin && (
              <button
                onClick={() => setEditingItem({ 
                  type: 'store', 
                  data: { 
                    name: '', 
                    branchId: allowedBranches.length > 0 ? allowedBranches[0] : (currentBranchId || 1), 
                    companyId: activeCompanyId,
                    company_id: activeCompanyId,
                    location: '', 
                    phone: '', 
                    latitude: '' as any, 
                    longitude: '' as any, 
                    googleMapsUrl: '', 
                    isMarketplaceVisible: true, 
                    operatingHours: '' 
                  } 
                })}
                className="bg-brand text-white px-3.5 py-2 rounded-lg text-xs font-bold hover:bg-brand-hover flex items-center gap-1.5 transition"
              >
                <Plus className="w-3.5 h-3.5" /> {t('Add Store')}
              </button>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[13px] text-left">
              <thead className="bg-gray-50 border-b text-gray-500 text-[10px] uppercase font-bold tracking-wider">
                <tr>
                  <th className="px-4 py-3">{t('Store Name')}</th>
                  <th className="px-4 py-3">{t('Branch Location')}</th>
                  <th className="px-4 py-3 text-center">{t('Total Items')}</th>
                  <th className="px-4 py-3 text-right">{t('Stock Value')}</th>
                  <th className="px-4 py-3 w-32 text-right"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {storeData.map(s => {
                  const branchName = branches.find(b => sameId(b.id, s.branchId))?.name || 'N/A';
                  const totalItems = stockItems.reduce((acc, p) => acc + (p.stock?.[s.id] || 0), 0);
                  const stockValue = stockItems.reduce((acc, p) => {
                    const rawQty = p.stock?.[s.id] || 0;
                    const mainQty = p.useSubUnitPricing ? rawQty / (p.subUnitConversion || 1) : rawQty;
                    return acc + (mainQty * p.purchasePrice);
                  }, 0);
                  return (
                    <React.Fragment key={s.id}>
                      <tr className="hover:bg-gray-50/50">
                        <td className="px-4 py-3 font-bold text-gray-900 flex items-center gap-2">
                          <StoreIcon className="w-4 h-4 text-gray-400" />
                          {s.name}
                        </td>
                        <td className="px-4 py-3 text-gray-500 font-semibold">{branchName}</td>
                        <td className="px-4 py-3 text-center font-semibold text-gray-700">{totalItems}</td>
                        <td className="px-4 py-3 text-right font-bold text-indigo-700">{fmt(stockValue)}</td>
                        <td className="px-4 py-3 text-right">
                          <div className="flex justify-end gap-1.5">
                            <button
                              onClick={() => setActiveStoreDetailsId(activeStoreDetailsId === s.id ? null : s.id)}
                              className="p-1 px-2 text-[10px] font-bold rounded border border-purple-200 bg-purple-50 text-purple-700 hover:bg-purple-100 transition inline-flex items-center gap-1"
                              title={t('Show/Hide Stock Inventory Breakdown')}
                            >
                              {activeStoreDetailsId === s.id ? t('Hide') : t('Details')}
                            </button>
                            {isAdmin && (
                              <>
                                <button
                                  onClick={() => {
                                    const storeCo = storeCompanyId(s);
                                    if (!isSuperAdmin && storeCo && !sameId(storeCo, activeCompanyId)) {
                                      toast.error(t('Access Denied: You cannot edit stores of another company.'));
                                      return;
                                    }
                                    setEditingItem({ type: 'store', data: s });
                                  }}
                                  className="p-1 px-2 text-[10px] font-bold rounded border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 transition inline-flex items-center gap-1"
                                  title={t('Edit')}
                                >
                                  <Pencil className="w-3.5 h-3.5" />
                                  {t('Edit')}
                                </button>
                                <button
                                  onClick={() => {
                                    const storeCo = storeCompanyId(s);
                                    if (!isSuperAdmin && storeCo && !sameId(storeCo, activeCompanyId)) {
                                      toast.error(t('Access Denied: You cannot delete stores of another company.'));
                                      return;
                                    }
                                    handleDeleteStore(s.id);
                                  }}
                                  className="p-1 px-2 text-[10px] font-bold rounded border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 transition inline-flex items-center gap-1"
                                  title={t('Delete')}
                                >
                                  <Trash2 className="w-3.5 h-3.5" />
                                  {t('Delete')}
                                </button>
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                      {activeStoreDetailsId === s.id && (
                        <tr className="bg-gray-50/70">
                          <td colSpan={5} className="p-4 border-t border-b text-xs">
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                              <div>
                                <span className="font-bold text-gray-700 uppercase tracking-wider text-[10px] block mb-1">{t('Physical Location')}</span>
                                <span className="text-gray-900 font-semibold">{s.location || t('No specific location configured')}</span>
                              </div>
                              <div>
                                <span className="font-bold text-gray-700 uppercase tracking-wider text-[10px] block mb-1">{t('Store Contact Phone')}</span>
                                <span className="text-gray-900 font-semibold">{s.phone || t('No specific phone configured')}</span>
                              </div>
                            </div>

                            <div className="border rounded-lg bg-white overflow-hidden shadow-xs">
                              <div className="bg-gray-100/50 p-2.5 border-b font-bold text-gray-700 text-[11px] uppercase tracking-wider">
                                {t('Active Stock Inventory weight inside')} {s.name}
                              </div>
                              <table className="w-full text-left text-[11px]">
                                <thead className="bg-gray-50 text-gray-500 font-bold border-b text-[9px] uppercase">
                                  <tr>
                                    <th className="p-2">{t('Item Name')}</th>
                                    <th className="p-2">{t('Category')}</th>
                                    <th className="p-2 text-center">{t('Current In Stock')}</th>
                                    <th className="p-2 text-right">{t('Unit Purchase Price')}</th>
                                    <th className="p-2 text-right">{t('Total Asset Value')}</th>
                                  </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100 font-medium text-gray-700">
                                  {stockItems
                                    .filter(p => (p.stock?.[s.id] || 0) > 0)
                                    .map(p => {
                                      const qty = p.stock?.[s.id] || 0;
                                      const mainQty = p.useSubUnitPricing ? qty / (p.subUnitConversion || 1) : qty;
                                      const totalValue = mainQty * p.purchasePrice;
                                      return (
                                        <tr key={p.id} className="hover:bg-gray-50/50">
                                          <td className="p-2 font-bold text-gray-900">{p.name} <span className="text-[10px] font-mono text-gray-400">({p.code})</span></td>
                                          <td className="p-2">{t(p.category)}</td>
                                          <td className="p-2 text-center font-bold text-emerald-700">{qty} {p.unit ? t(p.unit) : ''}</td>
                                          <td className="p-2 text-right font-semibold text-gray-600">{fmt(p.purchasePrice)}</td>
                                          <td className="p-2 text-right font-bold text-indigo-700">{fmt(totalValue)}</td>
                                        </tr>
                                      );
                                    })}
                                  {stockItems.filter(p => (p.stock?.[s.id] || 0) > 0).length === 0 && (
                                    <tr>
                                      <td colSpan={5} className="p-3 text-center text-gray-400 font-semibold">
                                        {t('This store currently holds empty inventory weights.')}
                                      </td>
                                    </tr>
                                  )}
                                </tbody>
                              </table>
                            </div>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
          {renderEditModal()}
        </div>
      );

    case 'customers':
      return (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="p-4 border-b flex items-center justify-between">
            <h3 className="font-bold text-gray-900 text-sm">{t('Customers')}</h3>
            {isAdmin && (
              <button
                onClick={() => setEditingItem({
                  type: 'customer',
                  data: { name: '', type: 'Retail', phone: '', email: '', creditLimitDisplay: '0', balanceDisplay: '0', companyId: effectiveCompanyId, company_id: effectiveCompanyId }
                })}
                className="bg-brand text-white px-3.5 py-2 rounded-lg text-xs font-bold hover:bg-brand-hover flex items-center gap-1.5 transition"
              >
                <Plus className="w-3.5 h-3.5" /> {t('Add Customer')}
              </button>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[13px] text-left">
              <thead className="bg-gray-50 border-b text-gray-500 text-[10px] uppercase font-bold tracking-wider">
                <tr>
                  <th className="px-6 py-3">{t('Name')}</th>
                  <th className="px-6 py-3">{t('Type')}</th>
                  <th className="px-6 py-3">{t('Contact')}</th>
                  <th className="px-6 py-3">{t('Assigned Store')}</th>
                  <th className="px-6 py-3 text-right">{t('Credit Limit')}</th>
                  <th className="px-6 py-3 text-right">{t('Balance')}</th>
                  <th className="px-6 py-3 w-32 text-right"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {customers.filter(c => (!c.storeId || c.storeId === currentStoreId) && (isSuperAdmin || sameId((c as any).companyId ?? (c as any).company_id, effectiveCompanyId))).map(c => (
                  <tr key={c.id} className="hover:bg-gray-50/50">
                    <td className="px-6 py-4 font-bold text-gray-900">{c.name}</td>
                    <td className="px-6 py-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        c.type === 'Wholesale' ? 'bg-amber-100 text-amber-800' :
                        c.type === 'Preferred' ? 'bg-indigo-100 text-indigo-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {t(c.type)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-gray-500 font-semibold">
                      <div>{c.phone}</div>
                      <div className="text-[10px] font-mono">{c.email}</div>
                    </td>
                    <td className="px-6 py-4 text-gray-600 font-semibold whitespace-nowrap">
                      {c.storeId ? stores.find(st => st.id === c.storeId)?.name || t('Unknown Store') : t('All Stores')}
                    </td>
                    <td className="px-6 py-4 text-right font-semibold">{fmt(c.creditLimit)}</td>
                    <td className={`px-6 py-4 text-right font-bold ${c.balance > 0 ? 'text-red-600' : 'text-gray-700'}`}>
                      {fmt(c.balance || 0)}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-1.5 flex-wrap">
                        <button
                          onClick={() => setStatementModal({
                            isOpen: true,
                            entityType: 'customer',
                            entityId: c.id,
                            name: c.name
                          })}
                          className="p-1 px-2 text-[10px] font-bold rounded border border-indigo-200 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition inline-flex items-center gap-1"
                          title="Account Ledger Statement"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          Ledger
                        </button>
                        {c.balance > 0 && (
                          <button
                            onClick={() => setMessagingModal({
                              isOpen: true,
                              recipientName: c.name,
                              recipientPhone: c.phone || '',
                              outstandingBalance: c.balance
                            })}
                            className="p-1 px-2 text-[10px] font-bold rounded border border-emerald-200 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 transition inline-flex items-center gap-1"
                            title="Send WhatsApp Payment Reminder"
                          >
                            <MessageSquare className="w-3.5 h-3.5 text-emerald-600" />
                            Reminder
                          </button>
                        )}
                        {(isAdmin || isSuperAdmin) && (
                          <>
                            <button
                              onClick={() => setEditingItem({
                                type: 'customer',
                                data: {
                                  ...c,
                                  creditLimitDisplay: (currency === 'TZS' ? c.creditLimit * exchangeRate : c.creditLimit).toString(),
                                  balanceDisplay: (currency === 'TZS' ? c.balance * exchangeRate : c.balance).toString()
                                }
                              })}
                              className="p-1 px-2 text-[10px] font-bold rounded border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 transition inline-flex items-center gap-1"
                              title={t('Edit')}
                            >
                              <Pencil className="w-3.5 h-3.5" />
                              {t('Edit')}
                            </button>
                            <button
                              onClick={() => handleDeleteCustomer(c.id)}
                              className="p-1 px-2 text-[10px] font-bold rounded border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 transition inline-flex items-center gap-1"
                              title={t('Delete')}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              {t('Delete')}
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {renderEditModal()}
        </div>
      );

    case 'suppliers':
      return (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm">
          <div className="p-4 border-b flex items-center justify-between">
            <h3 className="font-bold text-gray-900 text-sm">{t('Suppliers')}</h3>
            {isAdmin && (
              <button
                onClick={() => setEditingItem({ type: 'supplier', data: { name: '', contact: '', phone: '', email: '', companyId: effectiveCompanyId, company_id: effectiveCompanyId } })}
                className="bg-brand text-white px-3.5 py-2 rounded-lg text-xs font-bold hover:bg-brand-hover flex items-center gap-1.5 transition"
              >
                <Plus className="w-3.5 h-3.5" /> {t('Add Supplier')}
              </button>
            )}
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[13px] text-left">
              <thead className="bg-gray-50 border-b text-gray-500 text-[10px] uppercase font-bold tracking-wider">
                <tr>
                  <th className="px-6 py-3">{t('Name')}</th>
                  <th className="px-6 py-3">{t('Contact Person')}</th>
                  <th className="px-6 py-3">{t('Phone / Email')}</th>
                  <th className="px-6 py-3">{t('Assigned Store')}</th>
                  <th className="px-6 py-3 w-32 text-right"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {suppliers.filter(s => (!s.storeId || s.storeId === currentStoreId) && (isSuperAdmin || sameId((s as any).companyId ?? (s as any).company_id, effectiveCompanyId))).map(s => (
                  <tr key={s.id} className="hover:bg-gray-50/50">
                    <td className="px-6 py-4 font-bold text-gray-900">{s.name}</td>
                    <td className="px-6 py-4 text-gray-600 font-bold">{s.contact}</td>
                    <td className="px-6 py-4 text-gray-500 font-semibold">
                      <div>{s.phone}</div>
                      <div className="text-[10px] font-mono">{s.email}</div>
                    </td>
                    <td className="px-6 py-4 text-gray-600 font-semibold whitespace-nowrap">
                      {s.storeId ? stores.find(st => st.id === s.storeId)?.name || t('Unknown Store') : t('All Stores')}
                    </td>
                    <td className="px-6 py-4 text-right">
                      <div className="flex justify-end gap-1.5 flex-wrap">
                        <button
                          onClick={() => setStatementModal({
                            isOpen: true,
                            entityType: 'supplier',
                            entityId: s.id,
                            name: s.name
                          })}
                          className="p-1 px-2 text-[10px] font-bold rounded border border-indigo-200 bg-indigo-50 text-indigo-700 hover:bg-indigo-100 transition inline-flex items-center gap-1"
                          title="Account Ledger Statement"
                        >
                          <FileText className="w-3.5 h-3.5" />
                          Ledger
                        </button>
                        {(isAdmin || isSuperAdmin) && (
                          <>
                            <button
                              onClick={() => setEditingItem({ type: 'supplier', data: s })}
                              className="p-1 px-2 text-[10px] font-bold rounded border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 transition inline-flex items-center gap-1"
                              title={t('Edit')}
                            >
                              <Pencil className="w-3.5 h-3.5" />
                              {t('Edit')}
                            </button>
                            <button
                              onClick={() => handleDeleteSupplier(s.id)}
                              className="p-1 px-2 text-[10px] font-bold rounded border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 transition inline-flex items-center gap-1"
                              title={t('Delete')}
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                              {t('Delete')}
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {renderEditModal()}
        </div>
      );

    case 'categories': {
      const isGlobal = isSuperAdmin && (!currentCompanyId || currentCompanyId === 'all');
      const coId = isGlobal ? null : effectiveCompanyId;
      const baseCategories = categoryFilterStore
        ? getStoreCategories(categories, categoryFilterStore, coId)
        : getCompanyCategories(categories, coId);

      // Strict category isolation:
      // Admin / Branch Administrator see ONLY categories of their own store/company that they operate
      const displayedCategories = baseCategories.filter(c => {
        if (!c || typeof c !== 'string' || !c.trim()) return false;
        const parsed = parseCategoryScope(c);

        // 1. Company check: non-superadmin users CANNOT see categories from other companies
        if (!isSuperAdmin && coId) {
          if (parsed.companyId && !sameId(parsed.companyId, coId)) {
            return false;
          }
        }

        // 2. Store check: if category is tied to a specific store, verify the user operates that store
        if (!isSuperAdmin && userAllowedStoreIds && userAllowedStoreIds.length > 0) {
          if (parsed.storeId) {
            if (!userAllowedStoreIds.includes(sv(parsed.storeId))) {
              return false; // Belongs to a different store not operated by this user
            }
          }
        }

        return true;
      });

      return (
        <div className="bg-white rounded-xl border border-gray-200 shadow-sm max-w-3xl mx-auto mt-6">
          <div className="p-4 border-b flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
                <Database className="w-4 h-4 text-brand" />
                {t('Product Categories')}
              </h3>
              <p className="text-[11px] text-gray-500 mt-0.5">
                {t('Manage store-specific and company-wide inventory categories.')}
              </p>
            </div>
            <div className="flex items-center gap-2">
              <div className="flex items-center gap-1.5 bg-gray-50 border border-gray-200 rounded-lg px-2.5 py-1.5">
                <StoreIcon className="w-3.5 h-3.5 text-gray-400" />
                <span className="text-xs font-bold text-gray-500">{t('Store')}:</span>
                <select
                  value={categoryFilterStore}
                  onChange={(e) => setCategoryFilterStore(e.target.value)}
                  className="text-xs font-bold text-gray-800 bg-transparent outline-none cursor-pointer"
                >
                  <option value="">{t('All Stores')}</option>
                  {activeCompanyStores
                    .filter(st => !userAllowedStoreIds || userAllowedStoreIds.includes(sv(st.id)))
                    .map(st => (
                      <option key={st.id} value={st.id}>{st.name}</option>
                    ))}
                </select>
              </div>
              {isAdmin && (
                <button
                  onClick={() => setEditingItem({
                    type: 'category',
                    data: {
                      name: '',
                      storeId: categoryFilterStore || (userAllowedStoreIds && userAllowedStoreIds.length === 1 ? userAllowedStoreIds[0] : '')
                    }
                  })}
                  className="bg-brand text-white px-3.5 py-2 rounded-lg text-xs font-bold hover:bg-brand-hover flex items-center gap-1.5 transition"
                >
                  <Plus className="w-3.5 h-3.5" /> {t('Add Category')}
                </button>
              )}
            </div>
          </div>
          <ul className="divide-y divide-gray-100">
            {displayedCategories.map((c, i) => {
              const parsed = parseCategoryScope(c);
              const assignedStore = parsed.storeId ? stores.find(s => sameId(s.id, parsed.storeId)) : null;
              const assignedCompany = parsed.companyId ? companies.find(comp => sameId(comp.id, parsed.companyId)) : null;

              return (
                <li key={i} className="px-6 py-4 flex justify-between items-center hover:bg-gray-50/50">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="font-bold text-gray-800">{cleanCategoryName(c)}</span>
                    {assignedCompany && isGlobal && (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-purple-50 text-purple-700 border border-purple-200">
                        {assignedCompany.name}
                      </span>
                    )}
                    {assignedStore ? (
                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1">
                        <StoreIcon className="w-3 h-3" />
                        {assignedStore.name}
                      </span>
                    ) : (
                      <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-gray-100 text-gray-600 border border-gray-200">
                        {t('All Stores')}
                      </span>
                    )}
                  </div>
                  {isAdmin && (
                    <button
                      onClick={() => handleDeleteCategory(c)}
                      className="p-1 px-2 text-[10px] font-bold rounded border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 transition inline-flex items-center gap-1"
                      title={t('Delete')}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      {t('Delete')}
                    </button>
                  )}
                </li>
              );
            })}
            {displayedCategories.length === 0 && (
              <li className="px-6 py-8 text-center text-xs font-semibold text-gray-400">
                {categoryFilterStore ? t('No categories registered for this store yet. Click "Add Category" to create one.') : t('No categories registered.')}
              </li>
            )}
          </ul>
          {renderEditModal()}
        </div>
      );
    }

    case 'taxes': {
      const isGlobalMode = (settings?.taxPolicyMode || 'global') === 'global';
      const effectiveCoId = isSuperAdmin
        ? (taxCompanyFilter !== 'all' ? taxCompanyFilter : null)
        : (userCompanyId || currentCompanyId || (companies[0]?.id));
      const selectedCompany = effectiveCoId ? companies.find(c => sameId(c.id, effectiveCoId)) : null;

      // Global tax rate baseline
      const globalTaxList: Tax[] = (settings?.globalTaxes && settings.globalTaxes.length > 0)
        ? settings.globalTaxes
        : (taxes.filter(t => t.isGlobal || !t.companyId).length > 0 ? taxes.filter(t => t.isGlobal || !t.companyId) : defaultTaxes);

      // Determine taxes to show
      let displayedTaxes: Tax[] = [];
      let isInheritedGlobalForCompany = false;

      if (isGlobalMode) {
        displayedTaxes = globalTaxList;
      } else if (isSuperAdmin && taxCompanyFilter === 'all') {
        const indList = taxes.filter(t => !t.isGlobal && t.companyId);
        displayedTaxes = indList.length > 0 ? indList : globalTaxList;
        if (indList.length === 0) isInheritedGlobalForCompany = true;
      } else if (effectiveCoId) {
        const compTaxes = (settings?.companyTaxes?.[effectiveCoId] && settings.companyTaxes[effectiveCoId].length > 0)
          ? settings.companyTaxes[effectiveCoId]
          : taxes.filter(t => sameId(t.companyId, effectiveCoId));
        if (compTaxes.length > 0) {
          displayedTaxes = compTaxes;
        } else {
          displayedTaxes = [];
          isInheritedGlobalForCompany = true;
        }
      }

      // Can current operator add/edit in current mode
      const canManageCurrentView = isSuperAdmin || (!isGlobalMode && isAdmin);

      return (
        <div className="space-y-6 mx-auto mt-4 max-w-5xl">
          {/* TOP GOVERNANCE BANNER: SUPERADMIN GLOBAL VS INDIVIDUAL TAX POLICY */}
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-5 text-white shadow-sm">
            <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-5">
              <div className="space-y-1.5">
                <div className="flex items-center gap-2.5 flex-wrap">
                  <div className="p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400">
                    <Globe className="w-5 h-5" />
                  </div>
                  <h2 className="text-base font-bold text-white tracking-wide">
                    {t('Tax Rate Policy & Scope Mode')}
                  </h2>
                  <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full inline-flex items-center gap-1.5 ${
                    isGlobalMode
                      ? 'bg-emerald-500/15 text-emerald-300 border border-emerald-500/30'
                      : 'bg-blue-500/15 text-blue-300 border border-blue-500/30'
                  }`}>
                    {isGlobalMode ? <ShieldCheck className="w-3.5 h-3.5" /> : <Building2 className="w-3.5 h-3.5" />}
                    {isGlobalMode ? t('Global Rates Active (All Companies)') : t('Individual Rates Active (Per Company)')}
                  </span>
                </div>
                <p className="text-xs text-slate-300 max-w-2xl leading-relaxed">
                  {isGlobalMode
                    ? t('Global Policy Mode: All registered companies across the entire TradeCore system share the unified global tax rate structure. Company-specific overrides are locked.')
                    : t('Individual / Independent Policy Mode: Every company operates independently. Company Admins configure and manage their own specific tax rates (e.g. VAT, local withholding, or custom levies).')}
                </p>
              </div>

              {/* SUPERADMIN SWITCHER BUTTONS */}
              {isSuperAdmin ? (
                <div className="flex items-center bg-slate-950 p-1.5 rounded-xl border border-slate-800 shrink-0 shadow-inner">
                  <button
                    type="button"
                    onClick={() => handleToggleTaxPolicy('global')}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all ${
                      isGlobalMode
                        ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    <Globe className="w-4 h-4" />
                    {t('Global (All Companies)')}
                  </button>
                  <button
                    type="button"
                    onClick={() => handleToggleTaxPolicy('individual')}
                    className={`flex items-center gap-2 px-3.5 py-2 rounded-lg text-xs font-bold transition-all ${
                      !isGlobalMode
                        ? 'bg-amber-500 text-slate-950 shadow-md font-extrabold'
                        : 'text-slate-400 hover:text-white hover:bg-slate-800'
                    }`}
                  >
                    <Building2 className="w-4 h-4" />
                    {t('Individual / Independent')}
                  </button>
                </div>
              ) : (
                <div className="flex items-center gap-2 text-xs font-bold px-3 py-2 rounded-lg bg-slate-800/80 border border-slate-700/60 text-slate-300">
                  {isGlobalMode ? (
                    <>
                      <Lock className="w-4 h-4 text-amber-400" />
                      <span>{t('Managed Centrally by Super Admin')}</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      <span>{t('Independent Company Control Active')}</span>
                    </>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* INDIVIDUAL MODE: SUPERADMIN COMPANY SELECTOR OR COMPANY ADMIN NOTICE */}
          {!isGlobalMode && (
            <div className="bg-white border border-gray-200 rounded-xl p-4 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-blue-50 text-blue-700 border border-blue-100">
                  <Building2 className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-gray-900 uppercase tracking-wider">
                    {isSuperAdmin ? t('Target Company Scope') : t('Active Company')}
                  </h4>
                  <p className="text-xs text-gray-500">
                    {isSuperAdmin
                      ? t('Select a company to inspect or configure its specific tax rates, or view all.')
                      : `${t('Configuring independent tax rates for')}: ${selectedCompany?.name || t('Your Company')}`}
                  </p>
                </div>
              </div>

              {isSuperAdmin && (
                <div className="flex items-center gap-2">
                  <label className="text-xs font-bold text-gray-600 whitespace-nowrap">{t('Company')}:</label>
                  <select
                    value={taxCompanyFilter}
                    onChange={(e) => setTaxCompanyFilter(e.target.value)}
                    className="text-xs font-bold text-gray-800 bg-gray-50 border border-gray-300 rounded-lg px-3 py-2 outline-none focus:border-brand cursor-pointer"
                  >
                    <option value="all">{t('All Companies Overview')}</option>
                    {companies.map(c => {
                      const count = (settings?.companyTaxes?.[c.id]?.length) || (taxes.filter(t => sameId(t.companyId, c.id)).length);
                      return (
                        <option key={c.id} value={c.id}>
                          {c.name} {count > 0 ? `(${count} custom rates)` : `(${t('Using default')})`}
                        </option>
                      );
                    })}
                  </select>
                </div>
              )}
            </div>
          )}

          {/* TAX RATES TABLE CARD */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b flex flex-wrap items-center justify-between gap-3 bg-gray-50/50">
              <div>
                <h3 className="font-bold text-gray-900 text-sm flex items-center gap-2">
                  {isGlobalMode ? (
                    <>
                      <Globe className="w-4 h-4 text-amber-500" />
                      {t('Global Tax Rates (Enforced on All Companies)')}
                    </>
                  ) : (
                    <>
                      <Building2 className="w-4 h-4 text-blue-600" />
                      {taxCompanyFilter === 'all' && isSuperAdmin
                        ? t('All Companies Tax Register')
                        : `${t('Tax Rates for')}: ${selectedCompany?.name || t('Selected Company')}`}
                    </>
                  )}
                </h3>
                <p className="text-[11px] text-gray-500 mt-0.5">
                  {isGlobalMode
                    ? t('Standard rates applied uniformly during sales, checkout, invoices, and TRA EFD compliance.')
                    : t('Independent rates applied exclusively to transactions of the assigned company.')}
                </p>
              </div>

              <div className="flex items-center gap-2">
                {!isGlobalMode && effectiveCoId && isInheritedGlobalForCompany && canManageCurrentView && (
                  <button
                    type="button"
                    onClick={() => handleCopyGlobalRatesToCompany(effectiveCoId)}
                    className="bg-blue-50 border border-blue-200 text-blue-700 px-3 py-1.5 rounded-lg text-xs font-bold hover:bg-blue-100 flex items-center gap-1.5 transition"
                    title={t('Bootstrap company with standard global tax rates')}
                  >
                    <Copy className="w-3.5 h-3.5" />
                    {t('Copy Global Rates')}
                  </button>
                )}

                {canManageCurrentView ? (
                  <button
                    onClick={() => {
                      const defaultCid = !isGlobalMode
                        ? (effectiveCoId && effectiveCoId !== 'all' ? effectiveCoId : (companies[0]?.id || null))
                        : null;
                      setEditingItem({
                        type: 'tax',
                        data: {
                          name: '',
                          rate: 18,
                          companyId: defaultCid,
                          isGlobal: isGlobalMode
                        }
                      });
                    }}
                    className="bg-brand text-white px-3.5 py-2 rounded-lg text-xs font-bold hover:bg-brand-hover flex items-center gap-1.5 transition shadow-sm"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    {isGlobalMode ? t('Add Global Tax') : t('Add Tax Rate')}
                  </button>
                ) : (
                  <div className="text-[11px] font-bold text-gray-500 bg-gray-100 px-3 py-1.5 rounded-lg flex items-center gap-1.5 border border-gray-200">
                    <Lock className="w-3 h-3 text-gray-400" />
                    {t('Locked (Global Super Admin Policy)')}
                  </div>
                )}
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-[13px] text-left">
                <thead className="bg-gray-50 border-b text-gray-500 text-[10px] uppercase font-bold tracking-wider">
                  <tr>
                    <th className="px-6 py-3">{t('Scope')}</th>
                    <th className="px-6 py-3">{t('Tax Name')}</th>
                    <th className="px-6 py-3">{t('Assigned Store')}</th>
                    <th className="px-6 py-3 text-center">{t('Rate (%)')}</th>
                    <th className="px-6 py-3 text-center">{t('Status')}</th>
                    <th className="px-6 py-3 w-32 text-right">{t('Actions')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {displayedTaxes.map(tData => {
                    const rowComp = tData.companyId ? companies.find(c => sameId(c.id, tData.companyId)) : null;
                    const canEditRow = isSuperAdmin || (!isGlobalMode && isAdmin && sameId(tData.companyId, userCompanyId));

                    return (
                      <tr key={tData.id} className="hover:bg-gray-50/60 transition-colors">
                        <td className="px-6 py-4">
                          {isGlobalMode || tData.isGlobal || !tData.companyId ? (
                            <span className="text-[11px] font-bold text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-md inline-flex items-center gap-1">
                              <Globe className="w-3 h-3 text-amber-500" />
                              {t('Global (All Companies)')}
                            </span>
                          ) : (
                            <span className="text-[11px] font-bold text-blue-700 bg-blue-50 border border-blue-200 px-2 py-0.5 rounded-md inline-flex items-center gap-1">
                              <Building2 className="w-3 h-3 text-blue-500" />
                              {rowComp?.name || `Company #${tData.companyId}`}
                            </span>
                          )}
                        </td>
                        <td className="px-6 py-4 font-bold text-gray-900">
                          {tData.name}
                        </td>
                        <td className="px-6 py-4 text-gray-600 font-medium whitespace-nowrap">
                          {tData.storeId
                            ? stores.find(st => sameId(st.id, tData.storeId))?.name || t('Unknown Store')
                            : t('All Stores')}
                        </td>
                        <td className="px-6 py-4 text-center font-bold text-gray-900 text-sm">
                          {tData.rate}%
                        </td>
                        <td className="px-6 py-4 text-center">
                          <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-md">
                            {t('Active')}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-right">
                          {canEditRow ? (
                            <div className="flex justify-end gap-1.5">
                              <button
                                onClick={() => setEditingItem({ type: 'tax', data: tData })}
                                className="p-1 px-2.5 text-[11px] font-bold rounded-lg border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 transition inline-flex items-center gap-1"
                                title={t('Edit')}
                              >
                                <Pencil className="w-3 h-3" />
                                {t('Edit')}
                              </button>
                              <button
                                onClick={() => handleDeleteTax(tData.id)}
                                className="p-1 px-2.5 text-[11px] font-bold rounded-lg border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 transition inline-flex items-center gap-1"
                                title={t('Delete')}
                              >
                                <Trash2 className="w-3 h-3" />
                                {t('Delete')}
                              </button>
                            </div>
                          ) : (
                            <span className="text-[11px] font-semibold text-gray-400 inline-flex items-center gap-1">
                              <Lock className="w-3 h-3" /> {t('Read Only')}
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}

                  {displayedTaxes.length === 0 && (
                    <tr>
                      <td colSpan={6} className="px-6 py-10 text-center text-gray-400">
                        <div className="max-w-xs mx-auto space-y-2">
                          <AlertCircle className="w-8 h-8 text-gray-300 mx-auto" />
                          <p className="text-sm font-semibold text-gray-600">
                            {t('No tax rates configured for this view')}
                          </p>
                          <p className="text-xs text-gray-400">
                            {t('Click "Copy Global Rates" to import baseline rates or "+ Add Tax Rate" to create a new one.')}
                          </p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
          {renderEditModal()}
        </div>
      );
    }

    case 'data-recovery': {
      const allowAdminAccess = settings?.allowAdminDataRecovery || false;
      const isAdminUser = currentUser?.role === 'Admin';

      if (!isSuperAdmin && (!isAdminUser || !allowAdminAccess)) {
        return (
          <div className="bg-red-50 border border-red-200 text-red-800 p-6 rounded-xl max-w-xl mx-auto text-center space-y-2 mt-8 shadow-sm">
            <div className="text-3xl">🔒</div>
            <h3 className="font-extrabold text-base">{t('Access Denied')}</h3>
            <p className="text-xs font-medium text-red-700">
              {t('The Data Recovery Hub is restricted. Super Admin has not granted Admin permission for deleted Purchase Orders and Sales Invoices.')}
            </p>
          </div>
        );
      }

      const deletedCompanies = companies.filter(c => c.isDeleted);
      const deletedBranches = branches.filter(b => b.isDeleted);
      const deletedStores = stores.filter(s => s.isDeleted);
      const deletedPurchases = purchaseOrders.filter(po => po.isDeleted);
      const voidedSales = salesOrders.filter(so => so.status === 'Voided' || so.isDeleted);

      return (
        <div className="space-y-6 max-w-4xl mx-auto">
          {/* Header */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-600 text-white rounded-xl p-5 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
              <h3 className="font-bold text-base flex items-center gap-2">
                <RefreshCw className="w-5 h-5" />
                {t('Data Recovery Hub')}
              </h3>
              <p className="text-xs text-emerald-100 mt-1 max-w-xl">
                {t('Restore soft-deleted records or voided transactions. All historical audit details remain preserved.')}
              </p>
            </div>

            {/* Super Admin Toggle for Admin Access */}
            {isSuperAdmin && (
              <div className="bg-white/10 backdrop-blur-xs p-3 rounded-lg border border-white/20 shrink-0">
                <label className="flex items-center gap-2.5 cursor-pointer text-xs font-bold text-white">
                  <input
                    type="checkbox"
                    checked={allowAdminAccess}
                    onChange={(e) => {
                      const updatedSettings = {
                        ...settings,
                        allowAdminDataRecovery: e.target.checked
                      };
                      saveAllData({ settings: updatedSettings });
                      toast.success(e.target.checked
                        ? t('Data Recovery Hub access granted to Admins for POs and Sales Invoices!')
                        : t('Data Recovery Hub access restricted to Super Admin only.')
                      );
                    }}
                    className="w-4 h-4 rounded text-emerald-600 focus:ring-emerald-500 bg-white/20 border-white/30 cursor-pointer"
                  />
                  <span>{t('Grant Data Recovery Access to Admins')}</span>
                </label>
                <span className="block text-[10px] text-emerald-100 mt-0.5">
                  {t('Admins can view and restore deleted POs and voided Sales Invoices when enabled.')}
                </span>
              </div>
            )}
          </div>

          {/* Super Admin Per-Company Backup Access Delegation Manager */}
          {isSuperAdmin && (
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5 space-y-3">
              <div className="flex items-center justify-between border-b border-gray-100 pb-2">
                <div>
                  <h4 className="font-bold text-gray-900 text-xs uppercase tracking-wider flex items-center gap-1.5">
                    🏢 {t('Usimamizi wa Ruhusa za Backup kwa Kila Kampuni')}
                  </h4>
                  <p className="text-[11px] text-gray-500">
                    {t('Washa au zima uwezo wa Admin wa kila kampuni kupakua na kurejesha backup ya kampuni yake pekee.')}
                  </p>
                </div>
                <span className="text-xs font-bold text-brand bg-brand/10 px-2 py-0.5 rounded">
                  {companies.filter(c => !c.isDeleted).length} {t('Companies')}
                </span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-1">
                {companies.filter(c => !c.isDeleted).map((comp) => {
                  const isEnabled = Boolean(
                    settings?.companyBackupAccess?.[comp.id] || settings?.companyBackupAccess?.[String(comp.id)]
                  );
                  return (
                    <div key={comp.id} className="flex items-center justify-between p-2.5 rounded-lg border border-gray-100 hover:border-blue-200 bg-gray-50/50">
                      <div className="min-w-0 pr-2">
                        <span className="font-bold text-xs text-gray-800 block truncate">{comp.name}</span>
                        <span className="text-[10px] text-gray-500 block truncate">{(comp as any).city || comp.region || `ID: ${comp.id}`}</span>
                      </div>

                      <button
                        type="button"
                        onClick={() => {
                          const currentAccess = { ...(settings?.companyBackupAccess || {}) };
                          if (isEnabled) {
                            delete currentAccess[comp.id];
                            delete currentAccess[String(comp.id)];
                          } else {
                            currentAccess[comp.id] = true;
                            currentAccess[String(comp.id)] = true;
                          }
                          const updated = {
                            ...settings,
                            companyBackupAccess: currentAccess
                          };
                          saveAllData({ settings: updated });
                          toast.success(isEnabled
                            ? t(`Ufikiaji wa Backup umezuiwa kwa: ${comp.name}`)
                            : t(`Ufikiaji wa Backup umeruhusiwa kwa: ${comp.name}`)
                          );
                          logAction?.('Toggled Company Backup Access', `${isEnabled ? 'Revoked' : 'Granted'} backup privileges for ${comp.name} (${comp.id})`);
                        }}
                        className={`text-xs font-bold px-3 py-1 rounded-md transition cursor-pointer shrink-0 ${
                          isEnabled
                            ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                            : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                        }`}
                      >
                        {isEnabled ? t('Imeruhusiwa') : t('Imezuiwa')}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          )}


          {/* Enterprise Backup & Resilience Center */}
          {(() => {
            const effectiveCompanyId = currentUser?.companyId || currentCompanyId;
            const hasCompanyBackupAccess = isSuperAdmin || Boolean(
              effectiveCompanyId && (settings?.companyBackupAccess?.[effectiveCompanyId] || settings?.companyBackupAccess?.[String(effectiveCompanyId)])
            );

            if (!hasCompanyBackupAccess) {
              return (
                <div className="bg-amber-50/70 border border-amber-200 rounded-xl p-5 text-center space-y-2">
                  <div className="w-10 h-10 bg-amber-100 text-amber-700 rounded-full flex items-center justify-center mx-auto">
                    <Lock className="w-5 h-5" />
                  </div>
                  <h4 className="font-bold text-gray-900 text-sm">{t('Enterprise Backup Center Is Restricted')}</h4>
                  <p className="text-xs text-gray-600 max-w-lg mx-auto">
                    {t('Kituo hiki cha Hifadhi na Uokoaji wa Data kinaruhusiwa kwa Super Admin pekee, au Admin aliyepewa kibali maalum cha kampuni yake na Super Admin katika Mipangilio.')}
                  </p>
                </div>
              );
            }

            // Strictly filter data to current company if user is not Super Admin
            const scopedStock = isSuperAdmin
              ? stockItems
              : stockItems.filter(s => sameId(s.companyId, effectiveCompanyId));
            const scopedPurchases = isSuperAdmin
              ? purchaseOrders
              : purchaseOrders.filter(po => {
                  const s = stores.find(st => st.id === po.storeId);
                  return sameId(s?.companyId, effectiveCompanyId);
                });
            const scopedSales = isSuperAdmin
              ? salesOrders
              : salesOrders.filter(so => {
                  const s = stores.find(st => st.id === so.storeId);
                  return sameId(s?.companyId, effectiveCompanyId);
                });
            const scopedCustomers = isSuperAdmin
              ? customers
              : customers.filter(c => sameId((c as any).companyId, effectiveCompanyId));
            const scopedSuppliers = isSuperAdmin
              ? suppliers
              : suppliers.filter(s => sameId((s as any).companyId, effectiveCompanyId));
            const scopedCompanies = isSuperAdmin
              ? companies
              : companies.filter(c => sameId(c.id, effectiveCompanyId));
            const scopedBranches = isSuperAdmin
              ? branches
              : branches.filter(b => sameId(b.companyId, effectiveCompanyId));
            const scopedStores = isSuperAdmin
              ? stores
              : stores.filter(s => sameId(s.companyId, effectiveCompanyId));
            const scopedCategories = isSuperAdmin
              ? categories
              : categories.filter(cat => cat.startsWith(`co_${effectiveCompanyId}:`) || !cat.includes(':'));

            return (
              <div className="bg-white rounded-xl border border-blue-200 shadow-sm p-5 space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-100 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-blue-50 text-blue-700 rounded-lg">
                      <ShieldCheck className="w-5 h-5" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h4 className="font-bold text-gray-900 text-sm">
                          {isSuperAdmin
                            ? t('Enterprise Data Protection & Backup Center (Global Super Admin)')
                            : t('Enterprise Data Protection & Backup Center (Company Scoped)')}
                        </h4>
                        {!isSuperAdmin && (
                          <span className="text-[10px] font-bold px-2 py-0.5 bg-blue-100 text-blue-800 rounded">
                            {companies.find(c => sameId(c.id, effectiveCompanyId))?.name || `Company #${effectiveCompanyId}`}
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-gray-500">
                        {isSuperAdmin
                          ? t('Ulinzi thabiti wa data ya biashara zote: Pakua au rejesha data ya mfumo mzima kwa usalama.')
                          : t('Ulinzi thabiti wa kampuni yako pekee: Hifadhi na rudisha bidhaa, mauzo na ununuzi wa kampuni yako bila kuathiri kampuni nyingine.')}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2 text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200 w-fit">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                    {t('Multi-Tenant Row Isolation Active')}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* 1. Pakua Backup ya JSON */}
                  <button
                    type="button"
                    onClick={() => {
                      try {
                        const fullBackup = {
                          version: '2.0',
                          scope: isSuperAdmin ? 'global' : `company_${effectiveCompanyId}`,
                          companyId: isSuperAdmin ? undefined : effectiveCompanyId,
                          exportedAt: new Date().toISOString(),
                          companies: scopedCompanies,
                          branches: scopedBranches,
                          stores: scopedStores,
                          categories: scopedCategories,
                          stockItems: scopedStock,
                          purchaseOrders: scopedPurchases,
                          salesOrders: scopedSales,
                          expenses: (window as any).TRADECORE_LAST_STATE?.expenses || [],
                          customers: scopedCustomers,
                          suppliers: scopedSuppliers,
                          taxes
                        };
                        const blob = new Blob([JSON.stringify(fullBackup, null, 2)], { type: 'application/json' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        const dateStr = new Date().toISOString().split('T')[0];
                        const filenamePrefix = isSuperAdmin ? 'tradecore_global_backup' : `tradecore_company_${effectiveCompanyId}_backup`;
                        a.download = `${filenamePrefix}_${dateStr}.json`;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                        toast.success(t('Backup ya biashara imepakuliwa kikamilifu!'));
                        logAction?.('Data Backup Downloaded', `Exported ${isSuperAdmin ? 'global' : `company ${effectiveCompanyId}`} backup json`);
                      } catch (e: any) {
                        toast.error(t('Hitilafu ya kupakua backup: ') + (e?.message || 'Error'));
                      }
                    }}
                    className="flex items-center justify-center gap-2 px-4 py-3 bg-brand text-white font-bold text-xs rounded-xl hover:bg-brand-dark transition shadow-xs cursor-pointer active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    <span>{isSuperAdmin ? t('Pakua Backup ya Mfumo Mzima (JSON)') : t('Pakua Backup ya Kampuni Yangu (JSON)')}</span>
                  </button>

                  {/* 2. Rejesha Kutoka Faili la JSON */}
                  <label className="flex items-center justify-center gap-2 px-4 py-3 bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold text-xs rounded-xl hover:bg-emerald-100 transition shadow-xs cursor-pointer active:scale-95">
                    <Upload className="w-4 h-4" />
                    <span>{t('Rejesha Data Kutoka Faili')}</span>
                    <input
                      type="file"
                      accept=".json"
                      className="hidden"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (!file) return;
                        const reader = new FileReader();
                        reader.onload = (event) => {
                          try {
                            const content = event.target?.result as string;
                            const parsed = JSON.parse(content);
                            if (!parsed || typeof parsed !== 'object') {
                              throw new Error('Faili halina muundo sahihi wa data');
                            }

                            // TENANT ROW ISOLATION GUARD:
                            // If user is a Company Admin, force and rewrite every restored record
                            // to belong strictly to their authorized companyId. Rejects foreign IDs.
                            const payloadToSave: any = {};
                            if (Array.isArray(parsed.stockItems) && parsed.stockItems.length > 0) {
                              payloadToSave.stockItems = isSuperAdmin
                                ? parsed.stockItems
                                : parsed.stockItems.map((item: any) => ({
                                    ...item,
                                    companyId: effectiveCompanyId,
                                    company_id: effectiveCompanyId
                                  }));
                            }
                            if (Array.isArray(parsed.purchaseOrders) && parsed.purchaseOrders.length > 0) {
                              payloadToSave.purchaseOrders = isSuperAdmin
                                ? parsed.purchaseOrders
                                : parsed.purchaseOrders.map((po: any) => ({
                                    ...po,
                                    companyId: effectiveCompanyId,
                                    company_id: effectiveCompanyId
                                  }));
                            }
                            if (Array.isArray(parsed.salesOrders) && parsed.salesOrders.length > 0) {
                              payloadToSave.salesOrders = isSuperAdmin
                                ? parsed.salesOrders
                                : parsed.salesOrders.map((so: any) => ({
                                    ...so,
                                    companyId: effectiveCompanyId,
                                    company_id: effectiveCompanyId
                                  }));
                            }
                            if (Array.isArray(parsed.customers) && parsed.customers.length > 0) {
                              payloadToSave.customers = isSuperAdmin
                                ? parsed.customers
                                : parsed.customers.map((c: any) => ({ ...c, companyId: effectiveCompanyId }));
                            }
                            if (Array.isArray(parsed.suppliers) && parsed.suppliers.length > 0) {
                              payloadToSave.suppliers = isSuperAdmin
                                ? parsed.suppliers
                                : parsed.suppliers.map((s: any) => ({ ...s, companyId: effectiveCompanyId }));
                            }
                            if (Array.isArray(parsed.categories) && parsed.categories.length > 0) {
                              payloadToSave.categories = isSuperAdmin
                                ? parsed.categories
                                : parsed.categories.map((cat: any) =>
                                    typeof cat === 'string' && !cat.startsWith(`co_${effectiveCompanyId}:`)
                                      ? `co_${effectiveCompanyId}:${cleanCategoryName(cat)}`
                                      : cat
                                  );
                            }
                            if (Array.isArray(parsed.expenses) && parsed.expenses.length > 0) {
                              payloadToSave.expenses = isSuperAdmin
                                ? parsed.expenses
                                : parsed.expenses.map((exp: any) => ({ ...exp, companyId: effectiveCompanyId }));
                            }

                            saveAllData(payloadToSave);
                            toast.success(t('Data ya biashara imerejeshwa kikamilifu kwa usalama wa hali ya juu!'));
                            logAction?.('Data Restored From File', `Restored ${Object.keys(payloadToSave).length} collections strictly isolated for company ${effectiveCompanyId}`);
                          } catch (err: any) {
                            toast.error(t('Hitilafu wakati wa kurejesha: ') + (err?.message || 'Muundo batili'));
                          }
                        };
                        reader.readAsText(file);
                        e.target.value = '';
                      }}
                    />
                  </label>

                  {/* 3. Hamisha Bidhaa (Export Stock CSV) */}
                  <button
                    type="button"
                    onClick={() => {
                      try {
                        const activeStock = scopedStock.filter(s => !s.isDeleted);
                        const header = ['ID', 'Code', 'Name', 'Category', 'TotalStock', 'PurchasePrice', 'RetailPrice', 'WholesalePrice', 'LowStockAlert'];
                        const rows = activeStock.map(s => {
                          const totalQty = s.stock ? Object.values(s.stock).reduce((acc: number, val: any) => acc + (Number(val) || 0), 0) : 0;
                          return [
                            s.id,
                            `"${(s.code || '').replace(/"/g, '""')}"`,
                            `"${(s.name || '').replace(/"/g, '""')}"`,
                            `"${(s.category || '').replace(/"/g, '""')}"`,
                            totalQty,
                            s.purchasePrice ?? 0,
                            s.retailPrice ?? 0,
                            s.wholesalePrice ?? 0,
                            s.lowStockQty ?? 0
                          ];
                        });
                        const csvContent = [header.join(','), ...rows.map(r => r.join(','))].join('\n');
                        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
                        const url = URL.createObjectURL(blob);
                        const a = document.createElement('a');
                        a.href = url;
                        const filename = isSuperAdmin
                          ? `bidhaa_na_stoo_global_${new Date().toISOString().split('T')[0]}.csv`
                          : `bidhaa_na_stoo_company_${effectiveCompanyId}_${new Date().toISOString().split('T')[0]}.csv`;
                        a.download = filename;
                        document.body.appendChild(a);
                        a.click();
                        document.body.removeChild(a);
                        URL.revokeObjectURL(url);
                        toast.success(t('Ripoti ya bidhaa imepakuliwa kama CSV!'));
                      } catch (e: any) {
                        toast.error(t('Hitilafu ya CSV: ') + (e?.message || 'Error'));
                      }
                    }}
                    className="flex items-center justify-center gap-2 px-4 py-3 bg-amber-50 text-amber-900 border border-amber-200 font-bold text-xs rounded-xl hover:bg-amber-100 transition shadow-xs cursor-pointer active:scale-95"
                  >
                    <FileText className="w-4 h-4" />
                    <span>{t('Hamisha Bidhaa (CSV)')}</span>
                  </button>
                </div>

                <div className="bg-gray-50 rounded-lg p-3 text-[11px] text-gray-600 flex items-start gap-2 border border-gray-200">
                  <Shield className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  <span>
                    <strong>{t('Kumbuka ya Usalama wa Data & Multi-Tenant Isolation:')}</strong> {isSuperAdmin
                      ? t('Super Admin anadhibiti data yote ya mfumo mzima. Unaweza pia kuruhusu au kuzuia Admin wa kila kampuni kupakua/kurejesha data yake katika jopo la mipangilio hapa chini.')
                      : t('Data zote za kampuni yako zimehifadhiwa kwa ulinzi wa hali ya juu (Row-Level Security). Huwezi kuona wala kuathiri data ya kampuni nyingine.')}
                  </span>
                </div>
              </div>
            );
          })()}


          {/* Companies Section */}

          {isSuperAdmin && (
            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
              <div className="p-4 border-b bg-gray-50 flex items-center justify-between">
                <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                  📁 {t('Deleted Companies')}
                </h4>
                <span className="text-xs font-bold text-gray-400">
                  {deletedCompanies.length} {t('records')}
                </span>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-[13px] text-left">
                  <thead className="bg-gray-50 border-b text-[10px] uppercase font-bold text-gray-500 tracking-wider">
                    <tr>
                      <th className="px-6 py-3">{t('Company Name')}</th>
                      <th className="px-6 py-3 w-40 text-center">{t('Restore')}</th>
                      <th className="px-6 py-3 w-40 text-center">{t('Permanent Delete')}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {deletedCompanies.length === 0 ? (
                      <tr>
                        <td colSpan={3} className="px-6 py-8 text-center text-gray-400 italic">
                          {t('No deleted companies found.')}
                        </td>
                      </tr>
                    ) : (
                      deletedCompanies.map(c => (
                        <tr key={c.id} className="hover:bg-gray-50/50">
                          <td className="px-6 py-4 font-bold text-gray-900">{c.name}</td>
                          <td className="px-6 py-4 text-center">
                            <button
                              onClick={() => handleRestoreCompany(c.id)}
                              className="text-xs font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto"
                            >
                              <RefreshCw className="w-3 h-3" /> {t('Restore')}
                            </button>
                          </td>
                          <td className="px-6 py-4 text-center">
                            <button
                              onClick={() => handlePermanentDeleteCompany(c.id)}
                              className="text-xs font-bold bg-red-50 text-red-700 hover:bg-red-100 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto animate-pulse hover:animate-none"
                            >
                              <Trash2 className="w-3 h-3" /> {t('Permanent')}
                            </button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* Branches Section */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b bg-gray-50 flex items-center justify-between">
              <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                🌿 {t('Deleted Branches')}
              </h4>
              <span className="text-xs font-bold text-gray-400">
                {deletedBranches.length} {t('records')}
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-[13px] text-left">
                <thead className="bg-gray-50 border-b text-[10px] uppercase font-bold text-gray-500 tracking-wider">
                  <tr>
                    <th className="px-6 py-3">{t('Branch Name')}</th>
                    <th className="px-6 py-3">{t('Company Parent')}</th>
                    <th className="px-6 py-3 w-40 text-center">{t('Restore')}</th>
                    <th className="px-6 py-3 w-40 text-center">{t('Permanent Delete')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {deletedBranches.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-8 text-center text-gray-400 italic">
                        {t('No deleted branches found.')}
                      </td>
                    </tr>
                  ) : (
                    deletedBranches.map(b => (
                      <tr key={b.id} className="hover:bg-gray-50/50">
                        <td className="px-6 py-4 font-bold text-gray-900">{b.name}</td>
                        <td className="px-6 py-4 text-gray-500 font-semibold">
                          {companies.find(c => sameId(c.id, b.companyId))?.name || 'N/A'}
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => handleRestoreBranch(b.id)}
                            className="text-xs font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto"
                          >
                            <RefreshCw className="w-3 h-3" /> {t('Restore')}
                          </button>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => handlePermanentDeleteBranch(b.id)}
                            className="text-xs font-bold bg-red-50 text-red-700 hover:bg-red-100 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto animate-pulse hover:animate-none"
                          >
                            <Trash2 className="w-3 h-3" /> {t('Permanent')}
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Stores Section */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b bg-gray-50 flex items-center justify-between">
              <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                🏪 {t('Deleted Stores')}
              </h4>
              <span className="text-xs font-bold text-gray-400">
                {deletedStores.length} {t('records')}
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-[13px] text-left">
                <thead className="bg-gray-50 border-b text-[10px] uppercase font-bold text-gray-500 tracking-wider">
                  <tr>
                    <th className="px-6 py-3">{t('Store Name')}</th>
                    <th className="px-6 py-3">{t('Location / Contact')}</th>
                    <th className="px-6 py-3 w-40 text-center">{t('Restore')}</th>
                    <th className="px-6 py-3 w-40 text-center">{t('Permanent Delete')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {deletedStores.length === 0 ? (
                    <tr>
                      <td colSpan={4} className="px-6 py-8 text-center text-gray-400 italic">
                        {t('No deleted stores found.')}
                      </td>
                    </tr>
                  ) : (
                    deletedStores.map(s => (
                      <tr key={s.id} className="hover:bg-gray-50/50">
                        <td className="px-6 py-4 font-bold text-gray-900">{s.name}</td>
                        <td className="px-6 py-4 text-gray-500 text-xs">
                          {s.location} ({s.phone})
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => handleRestoreStore(s.id)}
                            className="text-xs font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto"
                          >
                            <RefreshCw className="w-3 h-3" /> {t('Restore')}
                          </button>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => handlePermanentDeleteStore(s.id)}
                            className="text-xs font-bold bg-red-50 text-red-700 hover:bg-red-100 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto animate-pulse hover:animate-none"
                          >
                            <Trash2 className="w-3 h-3" /> {t('Permanent')}
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Voided Sales Orders Section */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden animate-none">
            <div className="p-4 border-b bg-gray-50 flex items-center justify-between">
              <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                🛑 {t('Voided Sales Invoices (Audit Trail)')}
              </h4>
              <span className="text-xs font-bold text-gray-400">
                {voidedSales.length} {t('records')}
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-[13px] text-left">
                <thead className="bg-gray-50 border-b text-[10px] uppercase font-bold text-gray-500 tracking-wider">
                  <tr>
                    <th className="px-6 py-3">{t('Invoice / SO Number')}</th>
                    <th className="px-6 py-3">{t('Store / Customer')}</th>
                    <th className="px-6 py-3">{t('Total Amount')}</th>
                    <th className="px-6 py-3 w-40 text-center">{t('Restore / Unvoid')}</th>
                    <th className="px-6 py-3 w-40 text-center">{t('Permanent Delete')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {voidedSales.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-8 text-center text-gray-400 italic">
                        {t('No voided sales invoices found.')}
                      </td>
                    </tr>
                  ) : (
                    voidedSales.map(so => (
                      <tr key={so.id} className="hover:bg-gray-50/50">
                        <td className="px-6 py-4">
                          <span className="font-mono font-bold text-brand">{so.soNumber}</span>
                          <span className="block text-[10px] text-gray-400">{so.date}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="font-bold text-gray-900 block">🏪 {stores.find(s => s.id === so.storeId)?.name || `Store #${so.storeId}`}</span>
                          <span className="text-xs text-gray-500">👤 {customers.find(c => c.id === so.customerId)?.name || `Customer #${so.customerId}`}</span>
                        </td>
                        <td className="px-6 py-4 font-bold text-gray-950 font-mono">
                          {formatMoney(so.total, currency, exchangeRate)}
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            type="button"
                            onClick={() => {
                              const updated = salesOrders.map(item =>
                                String(item.id) === String(so.id)
                                  ? { ...item, status: 'Completed' as const, isDeleted: false, voidedAt: undefined }
                                  : item
                              );
                              saveAllData({ salesOrders: updated });
                              toast.success(t('Sales invoice successfully restored/unvoided!'));
                              logAction?.('Restored Sales Order', `Restored voided sales invoice ${so.soNumber}`);
                            }}
                            className="text-xs font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 hover:border-emerald-300 border border-emerald-200 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto cursor-pointer shadow-2xs active:scale-95"
                            title={t('Restore / Unvoid sales order to completed sales')}
                          >
                            <RefreshCw className="w-3.5 h-3.5" />
                            <span>{t('Unvoid')}</span>
                          </button>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            type="button"
                            onClick={() => {
                              const updated = salesOrders.filter(item => String(item.id) !== String(so.id));
                              saveAllData({ salesOrders: updated });
                              toast.success(t('Sales invoice permanently deleted!'));
                              logAction?.('Permanently Deleted Sales Order', `Permanently deleted sales invoice ${so.soNumber}`);
                            }}
                            className="text-xs font-bold bg-rose-50 text-rose-700 hover:bg-rose-100 hover:border-rose-300 border border-rose-200 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto cursor-pointer shadow-2xs active:scale-95"
                            title={t('Permanently delete this voided sales record from database')}
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                            <span>{t('Permanent')}</span>
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Deleted Purchase Orders Section */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden animate-none">
            <div className="p-4 border-b bg-gray-50 flex items-center justify-between">
              <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                📦 {t('Deleted Purchase Orders')}
              </h4>
              <span className="text-xs font-bold text-gray-400">
                {deletedPurchases.length} {t('records')}
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-[13px] text-left">
                <thead className="bg-gray-50 border-b text-[10px] uppercase font-bold text-gray-500 tracking-wider">
                  <tr>
                    <th className="px-6 py-3">{t('PO Number')}</th>
                    <th className="px-6 py-3">{t('Store / Supplier')}</th>
                    <th className="px-6 py-3">{t('Total Amount')}</th>
                    <th className="px-6 py-3 w-40 text-center">{t('Restore')}</th>
                    <th className="px-6 py-3 w-40 text-center">{t('Permanent Delete')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {deletedPurchases.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-8 text-center text-gray-400 italic">
                        {t('No deleted purchase orders found.')}
                      </td>
                    </tr>
                  ) : (
                    deletedPurchases.map(po => (
                      <tr key={po.id} className="hover:bg-gray-50/50">
                        <td className="px-6 py-4">
                          <span className="font-mono font-bold text-brand">{po.poNumber}</span>
                          <span className="block text-[10px] text-gray-400">{po.date}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="font-bold text-gray-900 block">🏪 {stores.find(s => s.id === po.storeId)?.name || `Store #${po.storeId}`}</span>
                          <span className="text-xs text-gray-500">👤 {suppliers.find(s => s.id === po.supplierId)?.name || `Supplier #${po.supplierId}`}</span>
                        </td>
                        <td className="px-6 py-4 font-bold text-gray-950 font-mono">
                          {formatMoney(po.total, currency, exchangeRate)}
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => {
                              const updated = purchaseOrders.map(item => item.id === po.id ? { ...item, isDeleted: false } : item);
                              saveAllData({ purchaseOrders: updated });
                              toast.success(t('Purchase order successfully restored!'));
                              logAction?.('Restored Purchase Order', `Restored deleted purchase order ${po.poNumber}`);
                            }}
                            className="text-xs font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto"
                          >
                            <RefreshCw className="w-3 h-3" /> {t('Restore')}
                          </button>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => {
                              const updated = purchaseOrders.filter(item => item.id !== po.id);
                              saveAllData({ purchaseOrders: updated });
                              toast.success(t('Purchase order permanently deleted!'));
                              logAction?.('Permanently Deleted Purchase Order', `Permanently deleted purchase order ${po.poNumber}`);
                            }}
                            className="text-xs font-bold bg-red-50 text-red-700 hover:bg-red-100 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto"
                          >
                            <Trash2 className="w-3 h-3" /> {t('Permanent')}
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Deleted Products Section */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden animate-none">
            <div className="p-4 border-b bg-gray-50 flex items-center justify-between">
              <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                📦 {t('Deleted Products')}
              </h4>
              <span className="text-xs font-bold text-gray-400">
                {stockItems.filter(p => p.isDeleted).length} {t('records')}
              </span>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-[13px] text-left">
                <thead className="bg-gray-50 border-b text-[10px] uppercase font-bold text-gray-500 tracking-wider">
                  <tr>
                    <th className="px-6 py-3">{t('Product Name')}</th>
                    <th className="px-6 py-3">{t('Code')}</th>
                    <th className="px-6 py-3">{t('Category')}</th>
                    <th className="px-6 py-3 w-40 text-center">{t('Restore')}</th>
                    <th className="px-6 py-3 w-40 text-center">{t('Permanent Delete')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {stockItems.filter(p => p.isDeleted).length === 0 ? (
                    <tr>
                      <td colSpan={5} className="px-6 py-8 text-center text-gray-400 italic">
                        {t('No deleted products found.')}
                      </td>
                    </tr>
                  ) : (
                    stockItems.filter(p => p.isDeleted).map(product => (
                      <tr key={product.id} className="hover:bg-gray-50/50">
                        <td className="px-6 py-4">
                          <span className="font-bold text-gray-900">{product.name}</span>
                        </td>
                        <td className="px-6 py-4 font-mono text-xs text-gray-600">
                          {product.code}
                        </td>
                        <td className="px-6 py-4 text-xs text-gray-500">
                          {product.category}
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => {
                              // ISOLATED MICRO-UPDATE: restore this single record only
                              // (atomic + per-record ack), so a stale sync can't wipe it back.
                              const restored: any = { ...product, isDeleted: false, updated_at: Date.now() };
                              if (mutateRecord) void mutateRecord('stockItems', 'upsert', product.id, restored);
                              else {
                                const updated = stockItems.map(item => item.id === product.id ? restored : item);
                                saveAllData({ stockItems: updated });
                              }
                              toast.success(t('Product successfully restored!'));
                              logAction?.('Restored Product', `Restored deleted product ${product.name}`);
                            }}
                            className="text-xs font-bold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto"
                          >
                            <RefreshCw className="w-3 h-3" /> {t('Restore')}
                          </button>
                        </td>
                        <td className="px-6 py-4 text-center">
                          <button
                            onClick={() => {
                              // ISOLATED MICRO-UPDATE: permanently delete ONLY this record
                              // (atomic filter + per-record ack), never the whole array.
                              if (mutateRecord) void mutateRecord('stockItems', 'delete', product.id, null);
                              else {
                                const updated = stockItems.filter(item => item.id !== product.id);
                                saveAllData({ stockItems: updated });
                              }
                              toast.success(t('Product permanently deleted!'));
                              logAction?.('Permanently Deleted Product', `Permanently deleted product ${product.name}`);
                            }}
                            className="text-xs font-bold bg-red-50 text-red-700 hover:bg-red-100 px-3 py-1.5 rounded-lg flex items-center gap-1 transition mx-auto"
                          >
                            <Trash2 className="w-3 h-3" /> {t('Permanent')}
                          </button>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      );
    }

    case 'exchange-rate':
      const currentGlobalRate = settings?.exchangeRate || 1;
      const currentGlobalCurrency = settings?.currency || 'USD';
      const activeUserCompId = currentUser?.companyId || currentCompanyId;

      const visibleExchangeCompanies = isSuperAdmin
        ? companies.filter(c => !c.isDeleted)
        : companies.filter(c => !c.isDeleted && sameId(c.id, activeUserCompId));

      const visibleExchangeUsers = isSuperAdmin
        ? users.filter(u => u.status === 'Active')
        : users.filter(u => u.status === 'Active' && sameId(u.companyId, activeUserCompId));

      const handleUpdateGlobalSettings = (newCurrency: string, newRate: number) => {
        const nextSettings = {
          ...settings,
          currency: newCurrency,
          exchangeRate: newRate
        };
        saveAllData({ settings: nextSettings });
        toast.success(t('Global fallback exchange rate settings updated.'));
        logAction('Update Global Exchange Rate', `Set global fallback: 1 USD = ${newRate} ${newCurrency}, currency: ${newCurrency}`);
      };

      const handleUpdateCompanySettings = (compId: number, newCurrency: string, newRate: number) => {
        const nextSettings = {
          ...settings,
          companyCurrencies: {
            ...(settings?.companyCurrencies || {}),
            [compId]: newCurrency
          },
          companyExchangeRates: {
            ...(settings?.companyExchangeRates || {}),
            [compId]: newRate
          }
        };
        saveAllData({ settings: nextSettings });
        toast.success(t('Company isolated currency settings updated successfully.'));
        logAction('Update Company Exchange Rate', `Set company (ID: ${compId}) rate: 1 USD = ${newRate} ${newCurrency}, currency: ${newCurrency}`);
      };

      const handleUpdateUserSettings = (username: string, newCurrency: string, newRate: number | null) => {
        const nextUserCurrencies = { ...(settings?.userCurrencies || {}) };
        const nextUserRates = { ...(settings?.userExchangeRates || {}) };

        if (newCurrency === '') {
          delete nextUserCurrencies[username];
        } else {
          nextUserCurrencies[username] = newCurrency;
        }

        if (newRate === null) {
          delete nextUserRates[username];
        } else {
          nextUserRates[username] = newRate;
        }

        const nextSettings = {
          ...settings,
          userCurrencies: nextUserCurrencies,
          userExchangeRates: nextUserRates
        };
        saveAllData({ settings: nextSettings });
        toast.success(t('User specific override settings updated successfully.'));
        logAction('Update User Exchange Rate Override', `Set user (${username}) rate: ${newRate !== null ? `1 USD = ${newRate} TZS` : 'Reset'}, currency: ${newCurrency || 'Reset'}`);
      };

      return (
        <div className="space-y-6 max-w-4xl mx-auto">
          {/* Header */}
          <div className="bg-gradient-to-r from-indigo-600 to-brand text-white rounded-xl p-5 shadow-sm">
            <h3 className="font-bold text-base flex items-center gap-2">
              🌐 {t('System Exchange Rate Controller')}
            </h3>
            <p className="text-xs text-indigo-100 mt-1 max-w-xl">
              {t('Configure independent currency and exchange rate operations per Company and override them per individual User. This ensures independent, localized transaction calculation across different organizations.')}
            </p>
          </div>

          {/* Section 1: Isolated Company Exchange Rates */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b bg-gray-50 flex items-center justify-between">
              <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                🏢 {t('Company Isolated Rates & Currencies')}
              </h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-[13px] text-left">
                <thead className="bg-gray-50 border-b text-[10px] uppercase font-bold text-gray-500 tracking-wider">
                  <tr>
                    <th className="px-6 py-3">{t('Company')}</th>
                    <th className="px-6 py-3">{t('Active Currency')}</th>
                    <th className="px-6 py-3">{t('Exchange Rate (1 USD = Local)')}</th>
                    <th className="px-6 py-3 text-right">{t('Action')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {visibleExchangeCompanies.map(c => {
                    const companyCurrency = settings?.companyCurrencies?.[c.id] || currentGlobalCurrency;
                    const companyRate = settings?.companyExchangeRates?.[c.id] !== undefined ? settings.companyExchangeRates[c.id] : currentGlobalRate;
                    const safeCompanyRateStr = companyRate !== undefined && !isNaN(Number(companyRate)) ? String(companyRate) : '1';
                    const rateInputVal = localCompanyRates[c.id] !== undefined ? localCompanyRates[c.id] : safeCompanyRateStr;

                    return (
                      <tr key={c.id} className="hover:bg-gray-50/30">
                        <td className="px-6 py-4 font-bold text-gray-900">{c.name}</td>
                        <td className="px-6 py-4">
                          <select
                            value={companyCurrency}
                            onChange={(e) => handleUpdateCompanySettings(c.id, e.target.value, companyRate)}
                            className="bg-white border border-gray-300 rounded-lg text-xs font-semibold px-2 py-1 outline-none focus:border-brand"
                          >
                            <option value="USD">USD ($)</option>
                            <option value="TZS">TZS (TSh)</option>
                            <option value="KES">KES (KSh)</option>
                            <option value="UGD">UGD (USh)</option>
                            <option value="UGX">UGX (USh)</option>
                            <option value="RWF">RWF (RF)</option>
                            <option value="EUR">EUR (€)</option>
                            <option value="GBP">GBP (£)</option>
                          </select>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <input
                              type="number"
                              step="any"
                              value={rateInputVal !== undefined && rateInputVal !== '' && !isNaN(Number(rateInputVal)) ? String(rateInputVal) : '1'}
                              onChange={(e) => setLocalCompanyRates({ ...localCompanyRates, [c.id]: e.target.value })}
                              className="w-28 px-2 py-1 border border-gray-300 rounded-lg text-xs font-black outline-none focus:border-brand"
                              placeholder="e.g. 2500"
                            />
                            <span className="text-[10px] font-bold text-gray-400">{companyCurrency}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <button
                            onClick={() => {
                              const inputFloat = parseFloat(rateInputVal);
                              if (!isNaN(inputFloat) && inputFloat > 0) {
                                handleUpdateCompanySettings(c.id, companyCurrency, inputFloat);
                              } else {
                                toast.error(t('Please enter a valid exchange rate.'));
                              }
                            }}
                            className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 hover:text-indigo-800 px-3 py-1 text-xs font-bold rounded-lg transition"
                          >
                            {t('Apply')}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 2: Personal / User Override Settings */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-4 border-b bg-gray-50 flex items-center justify-between">
              <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wider flex items-center gap-1.5">
                👤 {t('User Level Specific Overrides')}
              </h4>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-[13px] text-left">
                <thead className="bg-gray-50 border-b text-[10px] uppercase font-bold text-gray-500 tracking-wider">
                  <tr>
                    <th className="px-6 py-3">{t('User')}</th>
                    <th className="px-6 py-3">{t('Company / Role')}</th>
                    <th className="px-6 py-3">{t('Currency Override')}</th>
                    <th className="px-6 py-3">{t('Exchange Override (1 USD = Local)')}</th>
                    <th className="px-6 py-3 text-right">{t('Action')}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {visibleExchangeUsers.map(u => {
                    const userCurrency = settings?.userCurrencies?.[u.username] || '';
                    const userRate = settings?.userExchangeRates?.[u.username];
                    const safeUserRateStr = userRate !== undefined && !isNaN(Number(userRate)) ? String(userRate) : '';
                    const rateInputVal = localUserRates[u.username] !== undefined ? localUserRates[u.username] : safeUserRateStr;
                    const belongsToCompany = companies.find(c => sameId(c.id, u.companyId))?.name || t('Global / Super');

                    return (
                      <tr key={u.id} className="hover:bg-gray-50/30">
                        <td className="px-6 py-4 font-bold text-gray-900">
                          <div>{u.name}</div>
                          <div className="text-[10px] text-gray-400 font-mono">@{u.username}</div>
                        </td>
                        <td className="px-6 py-4 text-gray-500 font-semibold text-xs">
                          <div>{belongsToCompany}</div>
                          <div className="text-[10px] text-indigo-600 uppercase font-black tracking-wider">{u.role}</div>
                        </td>
                        <td className="px-6 py-4">
                          <select
                            value={userCurrency}
                            onChange={(e) => handleUpdateUserSettings(u.username, e.target.value, userRate !== undefined ? userRate : null)}
                            className="bg-white border border-gray-300 rounded-lg text-xs font-semibold px-2 py-1 outline-none focus:border-brand"
                          >
                            <option value="">{t('No Override (Inherit)')}</option>
                            <option value="USD">USD ($)</option>
                            <option value="TZS">TZS (TSh)</option>
                            <option value="KES">KES (KSh)</option>
                            <option value="UGD">UGD (USh)</option>
                            <option value="UGX">UGX (USh)</option>
                            <option value="RWF">RWF (RF)</option>
                            <option value="EUR">EUR (€)</option>
                            <option value="GBP">GBP (£)</option>
                          </select>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <input
                              type="number"
                              step="any"
                              value={rateInputVal !== undefined && rateInputVal !== '' && !isNaN(Number(rateInputVal)) ? String(rateInputVal) : ''}
                              onChange={(e) => setLocalUserRates({ ...localUserRates, [u.username]: e.target.value })}
                              className="w-28 px-2 py-1 border border-gray-300 rounded-lg text-xs font-black outline-none focus:border-brand"
                              placeholder={t('Inherit')}
                            />
                            <span className="text-[10px] font-bold text-gray-400">{userCurrency || t('Inherit')}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right flex items-center justify-end gap-1.5 pt-6">
                          <button
                            onClick={() => {
                              const inputFloat = parseFloat(rateInputVal);
                              if (rateInputVal === '') {
                                handleUpdateUserSettings(u.username, userCurrency, null);
                              } else if (!isNaN(inputFloat) && inputFloat > 0) {
                                handleUpdateUserSettings(u.username, userCurrency, inputFloat);
                              } else {
                                toast.error(t('Please enter a valid rate or clear the input.'));
                              }
                            }}
                            className="bg-indigo-50 hover:bg-indigo-100 text-indigo-700 px-3 py-1 text-xs font-bold rounded-lg transition"
                          >
                            {t('Apply')}
                          </button>
                          {(userCurrency !== '' || userRate !== undefined) && (
                            <button
                              onClick={() => {
                                handleUpdateUserSettings(u.username, '', null);
                                setLocalUserRates({ ...localUserRates, [u.username]: '' });
                              }}
                              className="bg-red-50 hover:bg-red-100 text-red-600 px-2 py-1 text-xs font-bold rounded-lg transition"
                              title={t('Clear overrides')}
                            >
                              {t('Clear')}
                            </button>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 3: Global Falling System Backups */}
          <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden p-5">
            <h4 className="font-bold text-gray-800 text-xs uppercase tracking-wider mb-3">
              🌍 {t('System Global Fallback Settings')}
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-end">
              <div>
                <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Global Currency Fallback')}</label>
                <select
                  value={currentGlobalCurrency}
                  onChange={(e) => handleUpdateGlobalSettings(e.target.value, currentGlobalRate)}
                  className="bg-white border border-gray-300 rounded-lg text-xs font-semibold px-3 py-2 w-full outline-none focus:border-brand"
                >
                  <option value="USD">USD ($)</option>
                  <option value="TZS">TZS (TSh)</option>
                  <option value="KES">KES (KSh)</option>
                  <option value="UGD">UGD (USh)</option>
                  <option value="UGX">UGX (USh)</option>
                  <option value="RWF">RWF (RF)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                </select>
              </div>
              <div>
                <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{`${t('Global Exchange Rate Fallback (1 USD =')} ${currentGlobalCurrency})`}</label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    step="any"
                    value={localGlobalRate !== '' ? localGlobalRate : (!isNaN(Number(currentGlobalRate)) && Number(currentGlobalRate) > 0 ? String(currentGlobalRate) : '1')}
                    onChange={(e) => setLocalGlobalRate(e.target.value)}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-xs font-black outline-none focus:border-brand"
                    placeholder="1"
                  />
                  <button
                    onClick={() => {
                      const inputFloat = parseFloat(localGlobalRate !== '' ? localGlobalRate : String(currentGlobalRate));
                      if (!isNaN(inputFloat) && inputFloat > 0) {
                        handleUpdateGlobalSettings(currentGlobalCurrency, inputFloat);
                        setLocalGlobalRate('');
                      } else {
                        toast.error(t('Please enter a valid rate.'));
                      }
                    }}
                    className="bg-brand hover:bg-brand-hover text-white px-4 py-2 text-xs font-bold rounded-lg transition shrink-0"
                  >
                    {t('Apply')}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      );

    default:
      return null;
  }
  })();

  // --- RENDER INNER EDITING OVERLAY MODAL ---
  function renderEditModal() {
    if (!editingItem) return null;
    const { type, data } = editingItem;
    const isEdit = !!data.id;

    return (
      <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
        <div className="fixed inset-0 bg-black/55 backdrop-blur-xs" onClick={() => setEditingItem(null)}></div>
        <div className="bg-white rounded-xl shadow-2xl w-full max-w-md max-h-[90vh] overflow-hidden flex flex-col relative z-10 transition-all transform scale-100 opacity-100 border border-gray-100">
          <div className="px-5 py-4 border-b flex items-center justify-between bg-gray-50">
            <h3 className="font-bold text-gray-900 text-sm uppercase tracking-wider">
              {isEdit ? t('Edit') : t('Add')} {t(type)}
            </h3>
            <button
              onClick={() => setEditingItem(null)}
              className="p-1 hover:bg-gray-200 rounded text-gray-400 hover:text-gray-600 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSave} className="flex flex-col overflow-hidden">
            <div className="p-5 space-y-4 overflow-y-auto max-h-[60vh] scrollbar-thin">
              {type === 'company' && (
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Company Name')} *</label>
                    <input
                      type="text"
                      required
                      value={data.name || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, name: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Subscription Period End Date')}</label>
                    <input
                      type="date"
                      value={data.subscriptionEnd || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, subscriptionEnd: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Subscription Status')}</label>
                    <select
                      value={data.subscriptionApproved !== undefined ? String(data.subscriptionApproved) : 'true'}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, subscriptionApproved: e.target.value === 'true' } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white focus:border-brand"
                    >
                      <option value="true">{t('Approved & Active')}</option>
                      <option value="false">{t('Blocked / Payment Pending')}</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Company Logo')}</label>
                    <div className="space-y-3">
                      {data.logoUrl && (
                        <div className="flex items-center gap-3 bg-gray-50 p-2.5 rounded-lg border border-dashed border-gray-200">
                          <img
                            src={data.logoUrl}
                            alt="Logo preview"
                            className="w-12 h-12 rounded-lg object-contain bg-white border border-gray-200"
                            referrerPolicy="no-referrer"
                            onError={(e) => {
                              (e.target as HTMLElement).style.display = 'none';
                            }}
                          />
                          <div>
                            <p className="text-xs font-bold text-gray-700">{t('Preview')}</p>
                            <button
                              type="button"
                              onClick={() => setEditingItem({ ...editingItem, data: { ...data, logoUrl: '' } })}
                              className="text-[11px] text-red-500 hover:underline font-bold"
                            >
                              {t('Remove')}
                            </button>
                          </div>
                        </div>
                      )}
                      <input
                        type="text"
                        placeholder="https://example.com/logo.png"
                        value={data.logoUrl || ''}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, logoUrl: e.target.value } })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                      />
                      <div className="flex items-center gap-2">
                        <span className="text-[11px] text-gray-400 font-bold uppercase">{t('OR')}</span>
                        <label className="cursor-pointer bg-gray-100 hover:bg-gray-200 text-gray-700 text-xs px-3 py-1.5 rounded-lg border border-gray-300 font-bold transition flex items-center gap-1.5">
                          📁 {t('Upload From Device')}
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={async (e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                try {
                                  const res = await compressImageFile(file, { maxWidth: 512, maxHeight: 512, quality: 0.8 });
                                  setEditingItem({
                                    ...editingItem,
                                    data: { ...data, logoUrl: res.dataUrl }
                                  });
                                } catch {
                                  const reader = new FileReader();
                                  reader.onloadend = () => {
                                    if (typeof reader.result === 'string') {
                                      setEditingItem({
                                        ...editingItem,
                                        data: { ...data, logoUrl: reader.result }
                                      });
                                    }
                                  };
                                  reader.readAsDataURL(file);
                                }
                              }
                            }}
                          />
                        </label>
                        {data.logoUrl && data.logoUrl.startsWith('data:') && (
                          <span className="text-[10px] text-green-600 font-semibold">✓ {t('Uploaded successfully')}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Company Theme Color')}</label>
                    <div className="flex items-center gap-3">
                      <input
                        type="color"
                        value={data.themeColor || data.theme_color || '#c41e3a'}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, themeColor: e.target.value, theme_color: e.target.value } })}
                        className="w-10 h-10 rounded border border-gray-300 cursor-pointer p-0 bg-transparent flex-shrink-0"
                      />
                      <input
                        type="text"
                        value={data.themeColor || data.theme_color || '#c41e3a'}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, themeColor: e.target.value, theme_color: e.target.value } })}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand font-mono font-semibold"
                        placeholder="#c41e3a"
                      />
                    </div>
                    <div className="flex gap-2 mt-2 flex-wrap">
                      {[
                        { name: 'Crimson', hex: '#c41e3a' },
                        { name: 'Indigo', hex: '#1e3a8a' },
                        { name: 'Emerald', hex: '#16a34a' },
                        { name: 'Violet', hex: '#7c3aed' },
                        { name: 'Charcoal', hex: '#374151' }
                      ].map(preset => (
                        <button
                          key={preset.hex}
                          type="button"
                          onClick={() => setEditingItem({ ...editingItem, data: { ...data, themeColor: preset.hex, theme_color: preset.hex } })}
                          className="px-2.5 py-1 text-[11px] font-bold rounded-md border text-gray-700 hover:bg-gray-50 flex items-center gap-1.5 transition"
                          style={{ borderColor: (data.themeColor || data.theme_color || '#c41e3a') === preset.hex ? preset.hex : '#e5e7eb' }}
                        >
                          <span className="w-2.5 h-2.5 rounded-full inline-block" style={{ backgroundColor: preset.hex }}></span>
                          {t(preset.name)}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* TRA COMPLIANCE — TIN / VAT / business license */}
                  <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl space-y-3">
                    <span className="text-xs font-extrabold text-amber-900 uppercase tracking-wider block">
                      {t('Taarifa za TRA (Tax Compliance)')}
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] font-bold text-gray-700 mb-1 block uppercase">{t('TIN Number')} *</label>
                        <input
                          type="text"
                          required
                          value={data.tinNumber || ''}
                          onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, tinNumber: e.target.value.replace(/[^0-9\-]/g, '') } })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono font-bold bg-white outline-none focus:border-brand"
                          placeholder="123-456-789"
                        />
                      </div>
                      <div>
                        <label className="text-[11px] font-bold text-gray-700 mb-1 block uppercase">{t('VRN Number (if VAT registered)')}</label>
                        <input
                          type="text"
                          value={data.vrnNumber || ''}
                          onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, vrnNumber: e.target.value.replace(/[^0-9A-Za-z\-]/g, '') } })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono font-bold bg-white outline-none focus:border-brand"
                          placeholder="e.g. 40-012345678"
                        />
                      </div>
                    </div>
                    <label className="flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={!!data.isVatRegistered}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, isVatRegistered: e.target.checked } })}
                        className="w-4 h-4 accent-amber-600"
                      />
                      <span className="text-[11px] font-bold text-gray-700">{t('Nimesajiliwa VAT (VAT registered)')}</span>
                    </label>
                    <div>
                      <label className="text-[11px] font-bold text-gray-700 mb-1 block uppercase">{t('Business License (URL or upload)')}</label>
                      <input
                        type="text"
                        value={data.businessLicense || ''}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, businessLicense: e.target.value } })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-bold bg-white outline-none focus:border-brand"
                        placeholder="https://... or data URL"
                      />
                    </div>
                  </div>

                  {/* Company Isolated Language & Currency Settings */}
                  <div className="p-3 bg-purple-50/70 border border-purple-200 rounded-xl space-y-3">
                    <span className="text-xs font-extrabold text-purple-950 uppercase tracking-wider block">
                      🌐 {t('Company Independent Language & Currency')}
                    </span>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[11px] font-bold text-gray-700 mb-1 block uppercase">{t('Company Language')}</label>
                        <select
                          value={data.language || settings?.companyLanguages?.[data.id] || 'en'}
                          onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, language: e.target.value } })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-semibold bg-white outline-none focus:border-brand"
                        >
                          <option value="en">English</option>
                          <option value="sw">Kiswahili (Swahili)</option>
                          <option value="fr">Français (French)</option>
                          <option value="es">Español (Spanish)</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-[11px] font-bold text-gray-700 mb-1 block uppercase">{t('Company Currency')}</label>
                        <select
                          value={data.currency || settings?.companyCurrencies?.[data.id] || 'USD'}
                          onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, currency: e.target.value } })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-semibold bg-white outline-none focus:border-brand"
                        >
                          <option value="USD">USD ($)</option>
                          <option value="TZS">TZS (TSh)</option>
                          <option value="KES">KES (KSh)</option>
                          <option value="UGD">UGD (USh)</option>
                          <option value="UGX">UGX (USh)</option>
                          <option value="RWF">RWF (RF)</option>
                          <option value="EUR">EUR (€)</option>
                          <option value="GBP">GBP (£)</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className="text-[11px] font-bold text-gray-700 mb-1 block uppercase">{t('Exchange Conversion (1 USD = X Local Units)')}</label>
                      <input
                        type="number"
                        step="any"
                        value={
                          data.exchangeRate !== undefined && !isNaN(Number(data.exchangeRate))
                            ? String(data.exchangeRate)
                            : (!isNaN(Number(settings?.companyExchangeRates?.[data.id])) ? String(settings?.companyExchangeRates?.[data.id]) : '1')
                        }
                        onChange={(e) => {
                          const val = parseFloat(e.target.value);
                          setEditingItem({ ...editingItem, data: { ...data, exchangeRate: isNaN(val) ? 1 : val } });
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-xs font-mono font-bold bg-white outline-none focus:border-brand"
                        placeholder="e.g. 2600"
                      />
                    </div>
                  </div>
                </div>
              )}

              {type === 'branch' && (
                <>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Branch Name')} *</label>
                    <input
                      type="text"
                      required
                      value={data.name || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, name: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  {isSuperAdmin ? (
                    <div>
                      <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Company Parent')} *</label>
                      <select
                        required
                        value={data.companyId || effectiveCompanyId}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, companyId: e.target.value } })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand bg-white font-semibold"
                      >
                        {companies.map((c, idx) => (
                          <option key={c.id != null ? String(c.id) : `comp-${idx}`} value={c.id}>{c.name}</option>
                        ))}
                      </select>
                    </div>
                  ) : (
                    <div>
                      <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Company Parent')}</label>
                      <input
                        type="text"
                        disabled
                        readOnly
                        value={companies.find(c => sameId(c.id, effectiveCompanyId))?.name || t('Your Company')}
                        className="w-full px-3 py-2 border border-gray-200 bg-gray-50 text-gray-600 rounded-lg text-sm font-semibold cursor-not-allowed"
                      />
                    </div>
                  )}
                </>
              )}

              {type === 'store' && (
                <>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Store Name')} *</label>
                    <input
                      type="text"
                      required
                      value={data.name || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, name: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Assigned Branch')} *</label>
                    <select
                      required
                      value={data.branchId || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, branchId: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand bg-white font-semibold"
                    >
                      {branches
                        .filter(b => !b.isDeleted && (isSuperAdmin || sameId(b.companyId, effectiveCompanyId)))
                        .map(b => (
                          <option key={b.id} value={b.id}>{b.name}</option>
                        ))}
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Location')} *</label>
                    <input
                      type="text"
                      required
                      value={data.location || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, location: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Phone')}</label>
                    <input
                      type="text"
                      value={data.phone || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, phone: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div className="space-y-3 border-t border-gray-100 pt-3 mt-1">
                    <div className="text-[10px] font-black uppercase tracking-wider text-brand">📍 {t('Store Location Mapping')}</div>
                    <div>
                      <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Specific Landmark / Area Details')}</label>
                      <input
                        type="text"
                        value={data.landmark || data.addressText || ''}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, landmark: e.target.value, addressText: e.target.value } })}
                        placeholder="e.g. Near Clock Tower, Aggrey / Msimbazi Junction"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand font-medium"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Google Maps URL / Link (Optional)')}</label>
                      <input
                        type="text"
                        value={data.googleMapsUrl || ''}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, googleMapsUrl: e.target.value } })}
                        placeholder="https://maps.app.goo.gl/..." 
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                      />
                    </div>
                    <div>
                      <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Operating Hours')}</label>
                      <input
                        type="text"
                        value={data.operatingHours || ''}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, operatingHours: e.target.value } })}
                        placeholder="Mon–Sat 08:00–18:00"
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                      />
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl border border-gray-200">
                      <div>
                        <div className="text-xs font-bold text-gray-800">{t('Show this store on the public product map')}</div>
                        <div className="text-[11px] text-gray-500">
                          {data.isMarketplaceVisible !== false ? (
                            <span className="text-emerald-600 font-bold">● {t('Active — Visible on public map')}</span>
                          ) : (
                            <span className="text-gray-400 font-bold">○ {t('Hidden from public map')}</span>
                          )}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          const current = data.isMarketplaceVisible !== false;
                          setEditingItem({ ...editingItem, data: { ...data, isMarketplaceVisible: !current } });
                        }}
                        className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                          data.isMarketplaceVisible !== false ? 'bg-emerald-600' : 'bg-gray-300'
                        }`}
                        role="switch"
                        aria-checked={data.isMarketplaceVisible !== false}
                      >
                        <span
                          className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                            data.isMarketplaceVisible !== false ? 'translate-x-5' : 'translate-x-0'
                          }`}
                        />
                      </button>
                    </div>
                  </div>
                </>
              )}

              {type === 'customer' && (
                <>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Name')} *</label>
                    <input
                      type="text"
                      required
                      value={data.name || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, name: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Type')} *</label>
                    <select
                      required
                      value={data.type || 'Retail'}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, type: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand bg-white font-semibold"
                    >
                      <option value="Retail">{t('Retail')}</option>
                      <option value="Wholesale">{t('Wholesale')}</option>
                      <option value="Preferred">{t('Preferred Partner')}</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Phone')}</label>
                    <input
                      type="text"
                      value={data.phone || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, phone: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Email')}</label>
                    <input
                      type="email"
                      value={data.email || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, email: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">
                      {t('Credit Limit')} ({currency})
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={data.creditLimitDisplay !== undefined && !Number.isNaN(Number(data.creditLimitDisplay)) ? String(data.creditLimitDisplay) : '0'}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, creditLimitDisplay: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">
                      {t('Current Balance')} ({currency})
                    </label>
                    <input
                      type="number"
                      step="any"
                      value={data.balanceDisplay !== undefined && !Number.isNaN(Number(data.balanceDisplay)) ? String(data.balanceDisplay) : '0'}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, balanceDisplay: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Assigned Store')}</label>
                    <select
                      value={data.storeId != null && !Number.isNaN(data.storeId as any) ? data.storeId : ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, storeId: e.target.value ? (/^\d+$/.test(e.target.value) ? Number(e.target.value) : e.target.value) : null } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white font-semibold focus:border-brand"
                    >
                      <option value="">{t('All Stores')}</option>
                      {stores.map(st => (
                        <option key={st.id} value={st.id}>{st.name}</option>
                      ))}
                    </select>
                  </div>
                </>
              )}

              {type === 'supplier' && (
                <>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Company Name')} *</label>
                    <input
                      type="text"
                      required
                      value={data.name || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, name: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Contact Person')}</label>
                    <input
                      type="text"
                      value={data.contact || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, contact: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Phone')}</label>
                    <input
                      type="text"
                      value={data.phone || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, phone: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Email')}</label>
                    <input
                      type="email"
                      value={data.email || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, email: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Assigned Store')}</label>
                    <select
                      value={data.storeId != null && !Number.isNaN(data.storeId as any) ? data.storeId : ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, storeId: e.target.value ? (/^\d+$/.test(e.target.value) ? Number(e.target.value) : e.target.value) : null } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white font-semibold focus:border-brand"
                    >
                      <option value="">{t('All Stores')}</option>
                      {stores.map(st => (
                        <option key={st.id} value={st.id}>{st.name}</option>
                      ))}
                    </select>
                  </div>
                </>
              )}

              {type === 'category' && (
                <div className="space-y-4">
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Category Name')} *</label>
                    <input
                      type="text"
                      required
                      placeholder={t('e.g. Beverages, Building Materials, Dairy...')}
                      value={data.name || ''}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, name: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand font-semibold"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Assigned Store')}</label>
                    <select
                      value={data.storeId !== undefined ? data.storeId : (categoryFilterStore || '')}
                      onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, storeId: e.target.value } })}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white font-semibold focus:border-brand cursor-pointer"
                    >
                      <option value="">{t('All Stores (Company Wide)')}</option>
                      {activeCompanyStores
                        .filter(st => !userAllowedStoreIds || userAllowedStoreIds.includes(sv(st.id)))
                        .map(st => (
                          <option key={st.id} value={st.id}>{st.name}</option>
                        ))}
                    </select>
                    <p className="text-[11px] text-gray-500 mt-1">
                      {t('Assign to a specific store so this category is only available in that store.')}
                    </p>
                  </div>
                </div>
              )}

              {type === 'tax' && (() => {
                const isGlobalMode = (settings?.taxPolicyMode || 'global') === 'global';
                const effectiveCoId = data.companyId || (taxCompanyFilter !== 'all' ? taxCompanyFilter : null) || currentCompanyId || currentUser?.companyId || (companies[0]?.id || null);
                const assignedCompany = companies.find(c => sameId(c.id, effectiveCoId));

                return (
                  <>
                    <div className="p-3 rounded-lg border bg-slate-50 border-slate-200">
                      <div className="flex items-center gap-2">
                        {isGlobalMode ? (
                          <>
                            <Globe className="w-4 h-4 text-amber-500" />
                            <span className="text-xs font-bold text-slate-800">{t('Global Tax Policy Scope')}</span>
                          </>
                        ) : (
                          <>
                            <Building2 className="w-4 h-4 text-blue-600" />
                            <span className="text-xs font-bold text-slate-800">{t('Individual Company Tax Scope')}</span>
                          </>
                        )}
                      </div>
                      <p className="text-[11px] text-slate-500 mt-1">
                        {isGlobalMode
                          ? t('This tax rate will apply universally to all companies and stores across the system.')
                          : `${t('This tax rate will apply specifically to')}: ${assignedCompany?.name || t('Selected Company')}`}
                      </p>
                    </div>

                    {!isGlobalMode && isSuperAdmin && (
                      <div>
                        <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Assign to Company')} *</label>
                        <select
                          value={data.companyId || effectiveCoId || ''}
                          onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, companyId: e.target.value } })}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white font-semibold focus:border-brand"
                        >
                          {companies.map(c => (
                            <option key={c.id} value={c.id}>{c.name}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    <div>
                      <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Tax Name')} *</label>
                      <input
                        type="text"
                        required
                        placeholder={t('e.g. VAT (18%), Withholding, Service Levy')}
                        value={data.name || ''}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, name: e.target.value } })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Rate (%)')} *</label>
                      <input
                        type="number"
                        step="any"
                        min="0"
                        max="100"
                        required
                        value={data.rate !== undefined && !Number.isNaN(Number(data.rate)) ? String(data.rate) : '0'}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, rate: e.target.value } })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none focus:border-brand"
                      />
                    </div>

                    <div>
                      <label className="text-xs font-bold text-gray-600 mb-1.5 block uppercase tracking-wider">{t('Assigned Store (Optional)')}</label>
                      <select
                        value={data.storeId != null && !Number.isNaN(data.storeId as any) ? data.storeId : ''}
                        onChange={(e) => setEditingItem({ ...editingItem, data: { ...data, storeId: e.target.value ? (/^\d+$/.test(e.target.value) ? Number(e.target.value) : e.target.value) : null } })}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm outline-none bg-white font-semibold focus:border-brand"
                      >
                        <option value="">{t('All Stores')}</option>
                        {stores
                          .filter(st => isGlobalMode || !effectiveCoId || sameId(st.companyId, effectiveCoId))
                          .map(st => (
                            <option key={st.id} value={st.id}>{st.name}</option>
                          ))}
                      </select>
                      <p className="text-[11px] text-gray-400 mt-1">
                        {t('Leave as "All Stores" to apply across all retail and wholesale locations of this scope.')}
                      </p>
                    </div>
                  </>
                );
              })()}
            </div>

            <div className="flex justify-end gap-2 p-4 border-t bg-gray-50">
              <button
                type="button"
                onClick={() => setEditingItem(null)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-xs font-bold hover:bg-gray-100 text-gray-700 transition"
              >
                {t('Cancel')}
              </button>
              <button
                type="button"
                onClick={(e) => { (e as any).preventDefault?.(); void handleSave(e as any); }}
                className="px-4 py-2 bg-brand text-white rounded-lg text-xs font-bold hover:bg-brand-hover transition"
              >
                {t('Save')}
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'companies', label: t('Companies'), icon: '🏢', visible: isSuperAdmin },
    { id: 'branches', label: t('Branches'), icon: '🌿', visible: isSuperAdmin || isAdmin },
    { id: 'stores', label: t('Store Management'), icon: '🏪', visible: true },
    { id: 'customers', label: t('Customers'), icon: '👥', visible: true },
    { id: 'suppliers', label: t('Suppliers'), icon: '🤝', visible: true },
    { id: 'categories', label: t('Stock Categories'), icon: '📁', visible: true },
    { id: 'taxes', label: t('Manage Taxes'), icon: '📊', visible: true },
    { id: 'data-recovery', label: t('Data Recovery'), icon: '♻️', visible: isSuperAdmin },
    { id: 'exchange-rate', label: t('Exchange Rates'), icon: '🌐', visible: isSuperAdmin || isAdmin },
  ].filter(tab => tab.visible);

  return (
    <div className="space-y-6">
      {/* Horizontal Tab Navigation Bar inside Master Data */}
      <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-2 max-w-4xl mx-auto overflow-x-auto scrollbar-none no-print">
        <div className="flex items-center gap-1 min-w-max">
          {tabs.map((tab) => {
            const isActive = currentPage === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => onNavigate && onNavigate(tab.id)}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-brand text-white shadow-xs'
                    : 'text-gray-500 hover:text-gray-900 hover:bg-gray-100/80'
                }`}
              >
                <span>{tab.icon}</span>
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {content}

      <AccountStatementModal
        isOpen={statementModal.isOpen}
        onClose={() => setStatementModal(prev => ({ ...prev, isOpen: false }))}
        entityType={statementModal.entityType}
        entityId={statementModal.entityId}
        entityName={statementModal.name}
        salesOrders={salesOrders}
        purchaseOrders={purchaseOrders}
        customers={customers}
        suppliers={suppliers}
        currencySymbol={currency === 'TZS' ? 'TZS ' : '$'}
      />

      <SmartMessagingModal
        isOpen={messagingModal.isOpen}
        onClose={() => setMessagingModal(prev => ({ ...prev, isOpen: false }))}
        recipientName={messagingModal.recipientName}
        recipientPhone={messagingModal.recipientPhone}
        outstandingBalance={messagingModal.outstandingBalance}
        currencySymbol={currency === 'TZS' ? 'TZS ' : '$'}
      />

      <ConfirmActionModal
        isOpen={confirmModal.isOpen}
        onClose={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
        onConfirm={confirmModal.onConfirm}
        title={confirmModal.title}
        description={confirmModal.description}
      />
    </div>
  );
}
