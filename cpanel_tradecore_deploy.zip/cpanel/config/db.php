<?php
/**
 * Database configuration — loaded by api.php and api_backup_500.php.
 * In production this file sits OUTSIDE public_html (e.g. /home/tanzatrade/config/db.php)
 * and is symlinked or included via absolute path. For cPanel shared hosting where
 * absolute paths outside public_html are not possible, place this file in
 * public_html/cpanel/config/db.php and block access via .htaccess (already done).
 */
return [
    'host' => 'localhost',
    'name' => 'tanzatrade_tradecore_erp',
    'user' => 'tanzatrade_tanzatrade',
    'pass' => '123456789@Tanzatrade',
];
